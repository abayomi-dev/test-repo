
#ifndef _APPDOWNLOAD_H
#define _APPDOWNLOAD_H


#ifdef __cplusplus
extern "C" {
#endif 

void checkForNewApp();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

// end of file
