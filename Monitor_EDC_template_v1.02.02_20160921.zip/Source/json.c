#include "global.h"

int chkBiller = 0;

static int jsoneq(const char *json, jsmntok_t *tok, const char *s) {
	if (tok->type == JSMN_STRING && (int) strlen(s) == tok->end - tok->start &&
			strncmp(json + tok->start, s, tok->end - tok->start) == 0) {
		return 0;
	}
	return -1;
}

//Use configinitapplicationversion to check for new updates
int parseProfile(char *data) {
	int i;
	int r;
	jsmn_parser p;
	jsmntok_t t[300]; /* We expect no more than 128 tokens */
	char storeData[100 * 1024] = {0};
	char chckpin[10] = {0};

	ShowLogs(1, "1. Length of Data: %d", strlen(data));

	jsmn_init(&p);
	r = jsmn_parse(&p, data, strlen(data), t, sizeof(t)/sizeof(t[0]));
	if (r < 0) {
		if(checkNew)
		{
			remove("profile.txt");
			//Monitor this
		}
		//printf("Failed to parse JSON: %d\n", r);
		ShowLogs(1, "Failed to parse JSON: %d", r);
		ShowLogs(1, "2. Length of Data: %d", strlen(data));
		return 1;
	}

	ShowLogs(1, "Data Gotten: %d", strlen(data));

	//ShowLogs(1, "R returned: %d, Type: %d", r, t[0].type);

	/* Assume the top-level element is an object */
	if (r < 1 || t[0].type != JSMN_OBJECT) {
		//printf("Object expected\n");
		ShowLogs(1, "Object expected.");
		return 1;
	}

	memset(&profileTag, 0, sizeof(PROFILETAG));
	//sprintf((char *)profileTag.vervehost, "%s", "0200");
	/* Loop over all keys of the root object */
	for (i = 1; i < r; i++) {
		if (jsoneq(data, &t[i], "timestamp") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("tmDt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("cid", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configtid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("tid", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("mid", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configadminpin") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("adminpin", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configchangepin") == 0) {
			//Change merchant pin
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("changepin", storeData);
			strcpy(chckpin, storeData);
			ShowLogs(1, "Change Pin Value: %s", chckpin);
			i++;
		} else if (jsoneq(data, &t[i], "configmerchantpinreset") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configmerchantpinreset", storeData);
			ShowLogs(1, "Pin reset value: %s", storeData);
			ShowLogs(1, "2. Change Pin Value: %s", chckpin);
			if(strstr(chckpin, "true") != NULL)
		 	{
		 		if(fexist("merchantpin.txt") >= 0)
				{
		 			CreateWrite("merchantpin.txt", storeData);
		 			UtilPutEnv("changepin", "false");
		 		}
		 	}
			i++;
		} else if (jsoneq(data, &t[i], "configenabletidpin") == 0) {
			memset(storeData, '\0', strlen(storeData));
			memset(tidIso.enabletid, '\0', strlen(tidIso.enabletid));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configenabletidpin", storeData);
			strcpy(tidIso.enabletid, storeData);
			ShowLogs(1, "Enable Tid: %s", tidIso.enabletid);
			i++;
		} else if (jsoneq(data, &t[i], "configtidpin") == 0) {
			memset(storeData, '\0', strlen(storeData));
			memset(tidIso.tidpin, '\0', strlen(tidIso.tidpin));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configtidpin", storeData);
			strcpy(tidIso.tidpin, storeData);
			ShowLogs(1, "Tid Pin: %s", tidIso.tidpin);
			i++;
		} else if (jsoneq(data, &t[i], "configserialnumber") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("serNum", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configterminalmanufacturer") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("manufac", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configterminalmodel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("model", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configinitapplicationversion") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appVer", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmerchantname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("merName", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmerchantaddress") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("merAddr", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("conRem", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("conRem", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configcontactname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configcontactname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configcontactphone") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configcontactphone", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configemail") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configemail", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configphysicaladdress") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configphysicaladdress", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmerchantcatcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configmerchantcatcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configstatecode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configstatecode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configptsp") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configptsp", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmechantaccountname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configmechantaccountname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configbankcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configbankcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configslipfoot") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configslipfoot", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configterminalownercode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configterminalownercode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "bankname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("bankname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "bankcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("bankcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "bankremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("bankremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commscommstype") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("cotype", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commssubnet") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("cosubnet", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsgateway") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("cogateway", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsip") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coip", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsport") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coport", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsipmode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coipmode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsapn") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coapn", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commspassword") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("copwd", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "mdbname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("mdbname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "mdbcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("mdbcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "mdbremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("mdbremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "ecrname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			if(strstr(storeData, "null") == NULL)
				UtilPutEnv("ecrname", storeData);
			else
				UtilPutEnv("ecrname", "0");
			i++;
		} else if (jsoneq(data, &t[i], "ecrsetmode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ecrmode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "ecrprintreceipt") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ecrreceipt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "ecrremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ecrremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilename") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("proName", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ctmkhostb", storeData);
			CreateWrite("hosb.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileclearmasterkey") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ctmkhosta", storeData);
			CreateWrite("hosa.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileprotectlist") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profileprotectlist", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilecardschemekeytypes") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilecardschemekeytypes", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profiletransactiontypesarray") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profiletransactiontypesarray", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilemastercard") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilemastercard", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilevisa") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilevisa", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilepayattitude") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilepayattitude", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileverve") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profileverve", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilecup") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilecup", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileamex") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profileamex", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilefreedomcard") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilefreedomcard", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileothersscheme") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			sprintf((char *)profileTag.vervehost, "%s", storeData);
			ShowLogs(1, "Verve Host: %s", profileTag.vervehost);
			i++;
		} else if (jsoneq(data, &t[i], "profilehostarray") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilehostarray", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "verveid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("verveid", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chremotedlt") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rmDwnTime", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chinterval") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chinterval", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chip") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chip", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chport") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chport", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptfootertext") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptfootertext", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptcustomercopylabel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptcclabel", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptmerchantcopylabel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptmclabel", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptfootnotelabel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptfnlabel", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptshowlogo") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptshowlogo", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptnormalfontsize") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptnfsize", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptheaderfontsize") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rpthfsize", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptamountfontsize") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptamtsize", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptshowbarcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptsbarcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptprintmerchantcopynumber") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptpmcn", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptprintclientcopynumber") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptpccn", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptsaveforreceipt") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptsfrpnt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptheadervalue") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptheadervalue", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostip") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostip", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostport") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostport", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostssl") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostssl", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostfriendlyname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostfname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostmestype") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostmestype", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2name") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2name", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2ip") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2ip", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2port") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2port", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2ssl") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2ssl", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2friendlyname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2fname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2mestype") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2mestype", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2remarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2remarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appversion") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appversion", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appbrand") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appbrand", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appdescription") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appdesc", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appmodel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appmodel", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appfix") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appfix", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appupdated") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appupdated", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkupdated") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkupdated", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkcomp1") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkcomp1", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkcomp2") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkcomp2", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkswitchkey") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkswitchkey", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfupdated") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfupdated", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfcomp1") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfcomp1", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfcomp2") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfcomp2", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfswitchkey") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfswitchkey", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curabbr") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curabbr", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curminorunit") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curminorunit", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logoversion") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logoversion", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logofilename") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logofilename", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logodescription") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logodesc", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobankcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobankcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobankname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobankname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logoremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logoremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobversion") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobversion", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobfilename") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobfilename", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobdescription") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobdesc", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobbankcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobbankcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobbankname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobbankname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "paymentdetails") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("payment.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "paymentvendorid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("pvenid.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "paymentconveniencefee") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("pconfee.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "paymentremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("paymentremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "transactions") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("menus.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostarray") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("host.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "protectlist") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("protectlist.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "superbiller") == 0) {
			int val = 0;
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("superbiller", storeData);
			chkBiller = 0;
			val = atoi(storeData);
			if(val)
			{
				chkBiller = val;
			}
		 	else
		 	{
		 		remove("bMenu.txt");
		 	}
			i++;
		} else {
			//ShowLogs(1, "Unexpected key: %.*s\n", t[i].end-t[i].start, data + t[i].start);
		}
	}
	//UtilPutEnv("tid", "2UP10255 ");//Delete.
	return 0;
}

int parseProfileOld(char *data) {
	int i;
	int r;
	jsmn_parser p;
	jsmntok_t t[300]; /* We expect no more than 128 tokens */
	char storeData[10 * 1024] = {0};

	jsmn_init(&p);
	r = jsmn_parse(&p, data, strlen(data), t, sizeof(t)/sizeof(t[0]));
	if (r < 0) {
		//printf("Failed to parse JSON: %d\n", r);
		//ShowLogs(1, "Failed to parse JSON: %d", r);
		return 1;
	}

	//ShowLogs(1, "R returned: %d, Type: %d", r, t[0].type);

	/* Assume the top-level element is an object */
	if (r < 1 || t[0].type != JSMN_OBJECT) {
		//printf("Object expected\n");
		//ShowLogs(1, "Object expected.");
		return 1;
	}
	memset(&profileTag, 0, sizeof(PROFILETAG));
	/* Loop over all keys of the root object */
	for (i = 1; i < r; i++) {
		if (jsoneq(data, &t[i], "timestamp") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			//UtilPutEnv("tmDt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("cid", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configtid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("tid", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("mid", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configadminpin") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("adminpin", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configchangepin") == 0) {
			//Change merchant pin
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			//UtilPutEnv("changepin", storeData);
			//strcpy(chckpin, storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmerchantpinreset") == 0) {
			//memset(chckpin, '\0', strlen(chckpin));
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			//UtilPutEnv("configmerchantpinreset", storeData);
			//if(strstr(chckpin, "true") != NULL)
		 	//{
		 		//CreateWrite("merchantpin.txt", storeData);
		 		//UtilPutEnv("changepin", "false");
		 	//}
			i++;
		} else if (jsoneq(data, &t[i], "configenabletidpin") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			//UtilPutEnv("configenabletidpin", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configtidpin") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			//UtilPutEnv("configtidpin", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configserialnumber") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("serNum", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configterminalmanufacturer") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("manufac", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configterminalmodel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("model", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configinitapplicationversion") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appVer", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmerchantname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("merName", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmerchantaddress") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("merAddr", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("conRem", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("conRem", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configcontactname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configcontactname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configcontactphone") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configcontactphone", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configemail") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configemail", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configphysicaladdress") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configphysicaladdress", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmerchantcatcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configmerchantcatcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configstatecode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configstatecode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configptsp") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configptsp", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configmechantaccountname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configmechantaccountname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configbankcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configbankcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configslipfoot") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configslipfoot", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "configterminalownercode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("configterminalownercode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "bankname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("bankname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "bankcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("bankcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "bankremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("bankremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commscommstype") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("cotype", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commssubnet") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("cosubnet", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsgateway") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("cogateway", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsip") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coip", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsport") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coport", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsipmode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coipmode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsapn") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coapn", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commspassword") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("copwd", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "commsremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("coremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "mdbname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("mdbname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "mdbcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("mdbcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "mdbremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("mdbremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "ecrname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			if(strstr(storeData, "null") == NULL)
				UtilPutEnv("ecrname", storeData);
			else
				UtilPutEnv("ecrname", "0");
			i++;
		} else if (jsoneq(data, &t[i], "ecrsetmode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ecrmode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "ecrprintreceipt") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ecrreceipt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "ecrremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ecrremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilename") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("proName", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ctmkhostb", storeData);
			CreateWrite("hosb.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileclearmasterkey") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("ctmkhosta", storeData);
			CreateWrite("hosa.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileprotectlist") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profileprotectlist", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilecardschemekeytypes") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilecardschemekeytypes", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profiletransactiontypesarray") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profiletransactiontypesarray", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilemastercard") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilemastercard", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilevisa") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilevisa", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilepayattitude") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilepayattitude", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileverve") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profileverve", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilecup") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilecup", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileamex") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profileamex", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profilefreedomcard") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilefreedomcard", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "profileothersscheme") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			sprintf((char *)profileTag.vervehost, "%s", storeData);
			ShowLogs(1, "Verve Host: %s", profileTag.vervehost);
			i++;
		} else if (jsoneq(data, &t[i], "profilehostarray") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("profilehostarray", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "verveid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("verveid", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chremotedlt") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rmDwnTime", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chinterval") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chinterval", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chip") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chip", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chport") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chport", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "chremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("chremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptfootertext") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptfootertext", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptcustomercopylabel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptcclabel", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptmerchantcopylabel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptmclabel", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptfootnotelabel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptfnlabel", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptshowlogo") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptshowlogo", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptnormalfontsize") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptnfsize", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptheaderfontsize") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rpthfsize", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptamountfontsize") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptamtsize", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptshowbarcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptsbarcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptprintmerchantcopynumber") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptpmcn", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptprintclientcopynumber") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptpccn", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptsaveforreceipt") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptsfrpnt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "rptheadervalue") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("rptheadervalue", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostip") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostip", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostport") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostport", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostssl") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostssl", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostfriendlyname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostfname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostmestype") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostmestype", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("hostremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2name") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2name", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2ip") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2ip", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2port") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2port", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2ssl") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2ssl", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2friendlyname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2fname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2mestype") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2mestype", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "host2remarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("host2remarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appversion") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appversion", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appbrand") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appbrand", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appdescription") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appdesc", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appmodel") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appmodel", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appfix") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appfix", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appupdated") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appupdated", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "appremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("appremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkupdated") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkupdated", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkcomp1") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkcomp1", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkcomp2") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkcomp2", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkswitchkey") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkswitchkey", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfupdated") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfupdated", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfcomp1") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfcomp1", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfcomp2") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfcomp2", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfswitchkey") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfswitchkey", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "swkfremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("swkfremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curabbr") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curabbr", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curminorunit") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curminorunit", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "curremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("curremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logoversion") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logoversion", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logofilename") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logofilename", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logodescription") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logodesc", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobankcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobankcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobankname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobankname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logoremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logoremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobversion") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobversion", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobfilename") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobfilename", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobdescription") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobdesc", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobbankcode") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobbankcode", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobbankname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobbankname", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "logobremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("logobremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "paymentdetails") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("payment.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "paymentvendorid") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("pvenid.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "paymentconveniencefee") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("pconfee.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "paymentremarks") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("paymentremarks", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "transactions") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("menus.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "hostarray") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("host.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "protectlist") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			CreateWrite("protectlist.txt", storeData);
			i++;
		} else if (jsoneq(data, &t[i], "superbiller") == 0) {
			int val = 0;
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, data + t[i+1].start);
			UtilPutEnv("superbiller", storeData);
			chkBiller = 0;
			val = atoi(storeData);
			if(val)
			{
				chkBiller = val;
			}
		 	else
		 	{
		 		remove("bMenu.txt");
		 	}
			i++;
		} else {
			//ShowLogs(1, "Unexpected key: %.*s\n", t[i].end-t[i].start, data + t[i].start);
		}
	}
	//UtilPutEnv("tid", "2UP10255 ");//Delete.
	return 0;
}
