
#ifndef _ECR_H
#define _ECR_H


#ifdef __cplusplus
extern "C" {
#endif 

void ecrEntrance();
extern char ucRet2;
extern int cecr;
extern int checkEcr;
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
