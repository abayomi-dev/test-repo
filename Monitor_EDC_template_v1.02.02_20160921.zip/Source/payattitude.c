#include "global.h"

int payAtt = 0;

int PackGetDataPayAttitude(char *ip, int port, char *data, char *outData, char *url)
{
	int uiLen = 0;
	char szBuff[MAX_DATA_LEN] = {0};
	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff, "GET %s%s HTTP/1.1\r\nAccept: */*\r\nAccept-Encoding: gzip, deflate\r\nCache-Control: no-cache\r\nProxy-Connection: Keep-Alive\r\nHost: %s:%d\r\n\r\n",
		url, data, ip, port);
	uiLen = strlen(szBuff);
	ShowLogs(1, "%s", szBuff);
	strcpy(outData, szBuff);
	return uiLen;
}


int httpGetDataPayAttitude(char *ip, int port, char *url, char *in, char *fromServer)
{
	char output[MAX_DATA_LEN];
	char output2[MAX_DATA_LEN];
	char tempUrl[1024];
	int iLen, iRet;
	char temp[128] = {0};
	
	memset(tempUrl, 0, sizeof(tempUrl));
	strcpy(tempUrl, url);

	memset(output, 0, sizeof(output));

	//ShowLogs(1, "Form Url: %s", tempUrl);

	iLen = PackGetDataPayAttitude(ip, port, in, output, tempUrl);
	//ShowLogs(1, "2. Packed Data: %s\n\nLength: %d", output, iLen);
	//Setting Parameter
	EmvUnsetSSLFlag();

	glSysParam.stTxnCommCfg.ucCommType = 5;
	memset(temp, '\0', strlen(temp));
	strcpy(temp, "web.gprs.mtnnigeria.net");
	memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
	memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, "web", 3);
	memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, "web", 3);
	memset(temp, '\0', strlen(temp));
	strcpy(temp, ip);
	memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
	memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
	memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
	memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
	memset(temp, '\0', strlen(temp));
	sprintf(temp, "%d", port);
	memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
	memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
	memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
	memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));


	DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	ShowLogs(1, "CommsInitialization Response: %d", iRet);
	if (iRet != 0)
	{
		ShowLogs(1, "Comms Initialization failed.");
		DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
		CommOnHook(TRUE);
	}
	iRet = CommDial(DM_DIAL);
	ShowLogs(1, "CommsDial Response: %d", iRet);
	if (iRet != 0)
	{
		ShowLogs(1, "Comms Dial failed.");
		DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
		CommOnHook(TRUE);
		return -1;
	}
	DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	iRet = CommTxd(output, strlen(output), 60);
	ShowLogs(1, "CommTxd Response: %d", iRet);
	if (iRet != 0)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
		ShowLogs(1, "CommTxd failed.");
		CommOnHook(TRUE);
		return -1;
	}
	DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	iRet = CommRxd(output, 10 * 1024, 60, &iLen);
	ShowLogs(1, "CommRxd Response: %d. Length: %d", iRet, iLen);
	if (iRet != 0)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
		ShowLogs(1, "CommRxd failed.");
		CommOnHook(TRUE);
		return -1;
	}

	CommOnHook(TRUE);

 	if(strstr(output, "HTTP/1.1 500") != NULL)
 	{
 		//ShowLogs(1, "Response not Successful");
 		DisplayInfoNone("UNIFIED PAYMENTS", "NOT RESPONDING", 0);
		return HTTP_RESP_ERR;
 	}else if(strstr(output, "HTTP/1.1 200 OK") == NULL)
 	{
 		//ShowLogs(1, "Response not Successful");
 		DisplayInfoNone("UNIFIED PAYMENTS", "NOT SUCCESSFUL", 0);
		return HTTP_RESP_ERR;
 	}

 	DisplayInfoNone("UNIFIED PAYMENTS", "RESPONSE RECEIVED", 0);
 	ShowLogs(1, "Data gotten: %s", output);
 	memset(output2, '\0', strlen(output2));
 	ParseGetData(output, output2, "\r\n\r\n");
 	strcpy(fromServer, output2);
	return HTTP_OK;
}

void formateMNL(char *in, char *out)
{
	int i = 0, j = 0;
	for(i = 0, j = 0; i < strlen(in); i++, j++)
	{
		if(in[i] == ' ')
			out[j] = '_';
		else
			out[j] = in[i];
	}
}

int SendEmvPayAttitude(char *data, int *reversal)
{
	char hexData[5 * 1024] = { 0 };
	char output[5 * 1024] = { 0 };
	DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	char dt[5] = {0};
	char tm[7] = {0};
	int iRet, iLen = 0;
	char temp[128] = {0};
	char temp2[128] = {0};
	char keyStore[128] = {0};
	char keyFin[33] = {0};
	char tempStore[128] = {0};
	char resp[3] = {0};
	char SN[33] = {0};
	char theUHI[33] = {0};
	char theUHISend[33] = {0};
	context_sha256_t ctx;
	char tempOut[100] = { '\0' };
	char boutHash[100] = { 0x0 };
	char outHash[100] = { 0x0 };
	char dataStore[254] = {0};
	uchar	szLocalTime[14+1];
	uchar outputData[10240] = {0};
	char parseTrack2[40] = {0};
	char lasthost[128] = {0};
	DL_UINT8 	packBuf[5 * 1024] = { 0x0 };

	memset(packBuf, 0x0, sizeof(packBuf));
	SysGetTimeIso(timeGotten);
	strncpy(datetime, timeGotten + 2, 10);
	sprintf((char *)glSendPack.szLocalDateTime, "%.*s", LEN_LOCAL_DATE_TIME, datetime);
	strncpy(dt, timeGotten + 2, 4);
	sprintf((char *)glSendPack.szLocalDate, "%.*s", LEN_LOCAL_DATE, dt);
	strncpy(tm, timeGotten + 6, 6);
	sprintf((char *)glSendPack.szLocalTime, "%.*s", LEN_LOCAL_TIME, tm);

	memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
	memset(glRecvPack.szLocalDateTime, '\0', strlen(glRecvPack.szLocalDateTime));
	memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
	memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
	memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
	memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
	memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
	memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
	memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
	memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));

	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);

	/* set ISO message fields */
	if(strlen(glSendPack.szMsgCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(0, glSendPack.szMsgCode, &isoMsg);
	}
	if(strlen(glSendPack.szPan) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(2, glSendPack.szPan, &isoMsg);
	}
	if(strlen(glSendPack.szProcCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(3, glSendPack.szProcCode, &isoMsg);
	}
	if(strlen(glSendPack.szTranAmt) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(4, glSendPack.szTranAmt, &isoMsg);
	}
	if(strlen(glSendPack.szLocalDateTime) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(7, glSendPack.szLocalDateTime, &isoMsg);
	}
	if(strlen(glSendPack.szSTAN) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(11, glSendPack.szSTAN, &isoMsg);
	}
	GetStan();
	if(strlen(glSendPack.szLocalTime) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(12, glSendPack.szLocalTime, &isoMsg);
	}
	if(strlen(glSendPack.szLocalDate) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(13, glSendPack.szLocalDate, &isoMsg);
	}
	if(strlen(glSendPack.szExpDate) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(14, glSendPack.szExpDate, &isoMsg);
	}
	if(strlen(glSendPack.szMerchantType) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(18, glSendPack.szMerchantType, &isoMsg);
	}
	if(strlen(glSendPack.szEntryMode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(22, glSendPack.szEntryMode + 1, &isoMsg);
	}
	if(strlen(glSendPack.szPanSeqNo) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(23, glSendPack.szPanSeqNo, &isoMsg);
	}
	if(strlen(glSendPack.szCondCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(25, glSendPack.szCondCode, &isoMsg);
	}
	if(strlen(glSendPack.szPoscCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(26, glSendPack.szPoscCode, &isoMsg);
	}
	if(strlen(glSendPack.szTransFee) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(28, glSendPack.szTransFee, &isoMsg);
	}
	if(strlen(glSendPack.szAqurId) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(32, glSendPack.szAqurId, &isoMsg);
	}
	if(strlen(glSendPack.szTrack2) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(35, glSendPack.szTrack2, &isoMsg);
	}
	if(strlen(glSendPack.szRRN) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(37, glSendPack.szRRN, &isoMsg);
	}
	if(strlen(glSendPack.szServResCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(40, glSendPack.szServResCode, &isoMsg);
	}
	if(strlen(glSendPack.szTermID) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(41, glSendPack.szTermID, &isoMsg);
	}
	if(strlen(glSendPack.szMerchantID) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(42, glSendPack.szMerchantID, &isoMsg);
	}
	if(strlen(glSendPack.szMNL) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(43, glSendPack.szMNL, &isoMsg);
	}
	if(strlen(glSendPack.szTranCurcyCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(49, glSendPack.szTranCurcyCode, &isoMsg);
	}
	if(data != NULL)
	{
		(void)DL_ISO8583_MSG_SetField_Str(62, data, &isoMsg);
	}
	if(strlen(glSendPack.szPosDataCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(123, glSendPack.szPosDataCode, &isoMsg);
	}
	(void) DL_ISO8583_MSG_SetField_Str(128, 0x0, &isoMsg);
	sha256_starts(&ctx);
	(void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, packBuf, &packedSize);
	HexEnCodeMethod((DL_UINT8*) packBuf, packedSize, hexData);
	ShowLogs(1, "Packed size %d", packedSize);
	
	memset(lasthost, '\0', strlen(lasthost));
	UtilGetEnvEx("lhost", lasthost);
	ShowLogs(1, "1. Lasthost: %s", lasthost);
	if(strstr(lasthost, "host2") != NULL)
	{
		memset(temp, '\0', strlen(temp));
		ReadAllData("isosesskeyb.txt", temp);
		ShowLogs(1, "Session key used for Hashing: %s", temp);
	}else
	{
		memset(temp, '\0', strlen(temp));
		ReadAllData("isosesskey.txt", temp);
		ShowLogs(1, "Session key used for Hashing: %s", temp);
	}
	
	if (packedSize >= 64) 
	{
		packBuf[packedSize - 64] = '\0';
		ShowLogs(1, "Packed ISO before hashing : %s", packBuf);
		memset(temp, '\0', strlen(temp));
		ReadAllData("isosesskey.txt", temp);
		ShowLogs(1, "Session key used for Hashing: %s", temp);
		memset(tempOut, 0x0, sizeof(tempOut));
		HexDecodeMethod((unsigned char*)temp, strlen(temp), (unsigned char*) tempOut);
		sha256_update(&ctx, (uint8_ts*) tempOut, 16);
		sha256_update(&ctx, (uint8_ts*) packBuf, (uint32_ts) strlen(packBuf));
		sha256_finish(&ctx, (uint8_ts*) boutHash);
		HexEnCodeMethod((unsigned char*) boutHash, 32, (unsigned char*) outHash);
		(void) DL_ISO8583_MSG_SetField_Str(128, outHash, &isoMsg);
		memset(packBuf, 0x0, sizeof(packBuf));
		(void) DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
		packBuf[0] = packedSize >> 8;
		packBuf[1] = packedSize;
		DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
		DL_ISO8583_MSG_Free(&isoMsg);
	}
	//For Gprs
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("cotype", temp);
	if(strstr(temp, "GPRS") != NULL)
 	{
 		glSysParam.stTxnCommCfg.ucCommType = 5;
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("coapn", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("cosubnet", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("copwd", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}
	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				*reversal = 1;
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 80, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				*reversal = 1;
				ShowLogs(1, "Ima Mmi: %d", reversal);
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				*reversal = 1;
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				*reversal = 1;
				return -1;
			}
			CommOnHook(TRUE);
 		}
 	}else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
 	ShowLogs(1, "Done With Nibss");
	ScrBackLight(1);
 	memset(hexData, '\0', strlen(hexData));
	HexEnCodeMethod(output, strlen(output) + 2, hexData);
	ShowLogs(1, "Received From Nibss: %s", hexData);
	
	unsigned char ucByte = 0;
	ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	(void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
	
	
	int i = 0;

	for(i = 0; i < 129; i++)
	{
		if( NULL != isoMsg.field[i].ptr ) 
		{
			memset(dataStore, '\0', strlen(dataStore));
			DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
			sprintf(dataStore, "%s", isoMsg.field[i].ptr);
			switch(i)
			{
				case 0:
					memset(glRecvPack.szMsgCode, '\0', strlen(glRecvPack.szMsgCode));
					sprintf((char *)glRecvPack.szMsgCode, "%.*s", LEN_MSG_CODE, dataStore);
					continue;
				case 1:
					memset(glRecvPack.sBitMap, '\0', strlen(glRecvPack.sBitMap));
					sprintf((char *)glRecvPack.sBitMap, "%.*s", 2*LEN_BITMAP, dataStore);
					continue;
				case 2:
					memset(glRecvPack.szPan, '\0', strlen(glRecvPack.szPan));
					sprintf((char *)glRecvPack.szPan, "%.*s", LEN_PAN, dataStore);
					continue;
				case 3:
					memset(glRecvPack.szProcCode, '\0', strlen(glRecvPack.szProcCode));
					sprintf((char *)glRecvPack.szProcCode, "%.*s", LEN_PROC_CODE, dataStore);
					continue;
				case 4:
					memset(glRecvPack.szTranAmt, '\0', strlen(glRecvPack.szTranAmt));
					sprintf((char *)glRecvPack.szTranAmt, "%.*s", LEN_TRAN_AMT, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTranAmt);
					continue;
				case 7:
					memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
					sprintf((char *)glRecvPack.szFrnAmt, "%.*s", LEN_FRN_AMT, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szFrnAmt);
					continue;
				case 11:
					memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
					sprintf((char *)glRecvPack.szSTAN, "%.*s", LEN_STAN, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szSTAN);
					continue;
				case 12:
					memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
					sprintf((char *)glRecvPack.szLocalTime, "%.*s", LEN_LOCAL_TIME, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szLocalTime);
					continue;
				case 13:
					memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
					sprintf((char *)glRecvPack.szLocalDate, "%.*s", LEN_LOCAL_DATE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szLocalDate);
					continue;
				case 14:
					memset(glRecvPack.szExpDate, '\0', strlen(glRecvPack.szExpDate));
					sprintf((char *)glRecvPack.szExpDate, "%.*s", LEN_EXP_DATE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szExpDate);
					continue;
				case 15:
					memset(glRecvPack.szSetlDate, '\0', strlen(glRecvPack.szSetlDate));
					sprintf((char *)glRecvPack.szSetlDate, "%.*s", LEN_LOCAL_DATE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szSetlDate);
					continue;
				case 18:
					memset(glRecvPack.szMerchantType, '\0', strlen(glRecvPack.szMerchantType));
					sprintf((char *)glRecvPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szMerchantType);
					continue;
				case 22:
					memset(glRecvPack.szEntryMode, '\0', strlen(glRecvPack.szEntryMode));
					sprintf((char *)glRecvPack.szEntryMode, "%.*s", LEN_ENTRY_MODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szEntryMode);
					continue;
				case 23:
					memset(glRecvPack.szPanSeqNo, '\0', strlen(glRecvPack.szPanSeqNo));
					sprintf((char *)glRecvPack.szPanSeqNo, "%.*s", LEN_PAN_SEQ_NO, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPanSeqNo);
					continue;
				case 25:
					memset(glRecvPack.szCondCode, '\0', strlen(glRecvPack.szCondCode));
					sprintf((char *)glRecvPack.szCondCode, "%.*s", LEN_COND_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szCondCode);
					continue;
				case 28:
					memset(glRecvPack.szTransFee, '\0', strlen(glRecvPack.szTransFee));
					sprintf((char *)glRecvPack.szTransFee, "%.*s", LEN_TRANS_FEE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTransFee);
					continue;
				case 30:
					memset(glRecvPack.szTransFee, '\0', strlen(glRecvPack.szTransFee));
					sprintf((char *)glRecvPack.szTransFee, "%.*s", LEN_TRANS_FEE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTransFee);
					continue;
				case 32:
					memset(glRecvPack.szAqurId, '\0', strlen(glRecvPack.szAqurId));
					sprintf((char *)glRecvPack.szAqurId, "%.*s", LEN_AQUR_ID, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szAqurId);
					continue;
				case 33:
					memset(glRecvPack.szFwdInstId, '\0', strlen(glRecvPack.szFwdInstId));
					sprintf((char *)glRecvPack.szFwdInstId, "%.*s", LEN_AQUR_ID, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szFwdInstId);
					continue;
				case 35:
					memset(glRecvPack.szTrack2, '\0', strlen(glRecvPack.szTrack2));
					sprintf((char *)glRecvPack.szTrack2, "%.*s", LEN_TRACK2, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTrack2);
					continue;
				case 37:
					memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
					sprintf((char *)glRecvPack.szRRN, "%.*s", LEN_RRN, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szRRN);
					continue;
				case 38:
					memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
					sprintf((char *)glRecvPack.szAuthCode, "%.*s", LEN_AUTH_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szAuthCode);
					continue;
				case 39:
					memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
					sprintf((char *)glRecvPack.szRspCode, "%.*s", LEN_RSP_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szRspCode);
					continue;
				case 40:
					memset(glRecvPack.szServResCode, '\0', strlen(glRecvPack.szServResCode));
					sprintf((char *)glRecvPack.szServResCode, "%.*s", LEN_SRES_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szServResCode);
					continue;
				case 41:
					memset(glRecvPack.szTermID, '\0', strlen(glRecvPack.szTermID));
					sprintf((char *)glRecvPack.szTermID, "%.*s", LEN_TERM_ID, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTermID);
					continue;
				case 42:
					memset(glRecvPack.szMerchantID, '\0', strlen(glRecvPack.szMerchantID));
					sprintf((char *)glRecvPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szMerchantID);
					continue;
				case 43:
					memset(glRecvPack.szMNL, '\0', strlen(glRecvPack.szMNL));
					sprintf((char *)glRecvPack.szMNL, "%.*s", LEN_MNL, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szMNL);
					continue;
				case 49:
					memset(glRecvPack.szTranCurcyCode, '\0', strlen(glRecvPack.szTranCurcyCode));
					sprintf((char *)glRecvPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTranCurcyCode);
					continue;
				case 54:
					memset(glRecvPack.szAddtAmount, '\0', strlen(glRecvPack.szAddtAmount));
					sprintf((char *)glRecvPack.szAddtAmount, "%.*s", LEN_ADDT_AMT, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szAddtAmount);
					continue;
				case 55:
					memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
					sprintf((char *)glRecvPack.sICCData, "%.*s", LEN_ICC_DATA, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.sICCData);
					continue;
				case 59:
					memset(glRecvPack.szTEchoData, '\0', strlen(glRecvPack.szTEchoData));
					sprintf((char *)glRecvPack.szTEchoData, "%.*s", LEN_TRANSECHO_DATA, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTEchoData);
					continue;
				case 60:
					memset(glRecvPack.szPayMentInfo, '\0', strlen(glRecvPack.szPayMentInfo));
					sprintf((char *)glRecvPack.szPayMentInfo, "%.*s", LEN_PAYMENT_INFO, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPayMentInfo);
					continue;
				case 102:
					memset(glRecvPack.szActIdent1, '\0', strlen(glRecvPack.szActIdent1));
					sprintf((char *)glRecvPack.szActIdent1, "%.*s", LEN_ACT_IDTF, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szActIdent1);
					continue;
				case 103:
					memset(glRecvPack.szActIdent2, '\0', strlen(glRecvPack.szActIdent2));
					sprintf((char *)glRecvPack.szActIdent2, "%.*s", LEN_ACT_IDTF, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szActIdent2);
					continue;
				case 123:
					memset(glRecvPack.szPosDataCode, '\0', strlen(glRecvPack.szPosDataCode));
					sprintf((char *)glRecvPack.szPosDataCode, "%.*s", LEN_POS_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPosDataCode);
					continue;
				case 124:
					memset(glRecvPack.szPayMentInfo, '\0', strlen(glRecvPack.szPayMentInfo));
					sprintf((char *)glRecvPack.szPayMentInfo, "%.*s", LEN_PAYMENT_INFO, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPayMentInfo);
					continue;
				case 128:
					memset(glRecvPack.szNFC, '\0', strlen(glRecvPack.szNFC));
					sprintf((char *)glRecvPack.szNFC, "%.*s", LEN_NEARFIELD, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szNFC);
					continue;
				default:
					continue;
			}
		}
	}

	sprintf((char *)glProcInfo.stTranLog.szRspCode, "%.2s", glRecvPack.szRspCode);
	UpdateLocalTime(NULL, glRecvPack.szLocalDate, glRecvPack.szLocalTime);
	GetDateTime(szLocalTime);
	sprintf((char *)glProcInfo.stTranLog.szDateTime, "%.14s", szLocalTime);
	sprintf((char *)glProcInfo.stTranLog.szAuthCode, "%.6s", glRecvPack.szAuthCode);
	sprintf((char *)glProcInfo.stTranLog.szRRN, "%.12s", glRecvPack.szRRN);
	sprintf((char *)glProcInfo.stTranLog.szCondCode,  "%.2s",  glSendPack.szCondCode);
	sprintf((char *)glProcInfo.stTranLog.szFrnAmount, "%.12s", glRecvPack.szFrnAmt);
	FindCurrency(glRecvPack.szHolderCurcyCode, &glProcInfo.stTranLog.stHolderCurrency);

	ShowLogs(1, "Commencing Storage.");
	if((txnType != 5) && (iLen != 36) && (strlen(glRecvPack.szRspCode) == 2))
    {
    	ShowLogs(1, "About Storing Transaction.");
    	storeTxn();
    	ShowLogs(1, "About Storing Eod.");
		storeEod();
		ShowLogs(1, "About printing.");
		storeprint();
    }
    ShowLogs(1, "Done with Storing.");

	ShowLogs(1, "Response Code: %s", glRecvPack.szRspCode);
	if(strstr(glRecvPack.szRspCode, "00") != NULL)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "APPROVED", 1);
	}else
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "DECLINED", 1);
	}
	
	if((strstr(glRecvPack.szRspCode, "06") != NULL)
		|| (strstr(glRecvPack.szRspCode, "20") != NULL)
		|| (strstr(glRecvPack.szRspCode, "21") != NULL)
		|| (strstr(glRecvPack.szRspCode, "22") != NULL)
		|| (strstr(glRecvPack.szRspCode, "68") != NULL)
		|| (strstr(glRecvPack.szRspCode, "90") != NULL)
		|| (strstr(glRecvPack.szRspCode, "94") != NULL))
	{
		//switchHostManual++;
		//if(switchHostManual < 2)
		//	DisplayInfoNone("UNIFIED PAYMENTS", "PLEASE ATTEMPT AGAIN", 0);
		switchHostManual = 2;
	}else
	{
		//if(switchHostManual)
		//	switchHostManual--;
	}
	
	//switchHostManual
	//Check for Key outta sync and do key exchange
	if(iLen == 36 || strlen(glRecvPack.szRspCode) != 2)
	{
		char lasthost[128] = {0};
		if(txnType == 7)
			revFlag = 1;
		ScrBackLight(1);
		Beep();
		memset(lasthost, '\0', strlen(lasthost));
		UtilGetEnvEx("lhost", lasthost);
		ShowLogs(1, "1. Lasthost: %s", lasthost);
		if(strstr(lasthost, "host2") != NULL)
		{
			if(GetMasterKeyB())
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "MASTER KEY LOADED", 0);
				if(GetSessionKeyB())
				{
					DisplayInfoNone("UNIFIED PAYMENTS", "SESSION KEY LOADED", 0);
					if(GetPinKeyB())
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PIN KEY LOADED", 0);
						if(GetParaMetersB())
						{
							DisplayInfoNone("UNIFIED PAYMENTS", "PARAM LOADED", 0);
						}else
						{
							DisplayInfoNone("UNIFIED PAYMENTS", "PARAM FAILED", 0);
							memset(outputData, '\0', strlen(outputData));
							iRet = ReadAllData("paramb.txt", outputData);
							if(iRet == 0)
							{
								if(parseParametersOldB(outputData))
								{
									ShowLogs(1, "Parameters Parse successful");
								}
							}
						}
					}else
						DisplayInfoNone("UNIFIED PAYMENTS", "PINKEY FAILED", 0);
				}else
					DisplayInfoNone("UNIFIED PAYMENTS", "SESSIONKEY FAILED", 0);
			}else
				DisplayInfoNone("UNIFIED PAYMENTS", "MASTERKEY FAILED", 0);
		}else
		{
			if(GetMasterKey())
			{
				if(GetSessionKey())
				{
					if(GetPinKey())
					{
						if(GetParaMeters())
						{
							DisplayInfoNone("UNIFIED PAYMENTS", "PLEASE ATTEMPT AGAIN", 0);
						}else
						{
							DisplayInfoNone("UNIFIED PAYMENTS", "PARAM FAILED", 0);
							memset(outputData, '\0', strlen(outputData));
							iRet = ReadAllData("param.txt", outputData);
							if(iRet == 0)
							{
								if(parseParametersOld(outputData))
								{
									ShowLogs(1, "Parameters Parse successful");
								}
							}
						}
					}else
						DisplayInfoNone("UNIFIED PAYMENTS", "PINKEY FAILED", 0);
				}else
					DisplayInfoNone("UNIFIED PAYMENTS", "SESSIONKEY FAILED", 0);
			}else
				DisplayInfoNone("UNIFIED PAYMENTS", "MASTERKEY FAILED", 0);
		}
		ScrBackLight(1);
		Beep();
	}
	
	DL_ISO8583_MSG_Free(&isoMsg);
	return 0;
}

void formIsoSend(char *phone)
{
	int iRet, iRev, iTemp;
	char temp[128] = {0};
	char data[1024] = {0};
	char SN[33] = {0};
	char theUHI[33] = {0};
	char theUHISend[33] = {0};
	char billerinfo[128] = {0};
	char paymentcode[1024] = {0};
	char paymentfin[1024] = {0};
	sprintf((char *)glSendPack.szMsgCode, "%s", "0200");
	//strcpy(glSendPack.szPan, "950100");
	//strcat(glSendPack.szPan, phone + 1);
	strcpy(glSendPack.szPan, "9501000000000001");//Olubayo
	strcpy(glSendPack.szProcCode, "000000");
	strcpy(glSendPack.szExpDate, "3012");
	strcpy(glSendPack.szEntryMode, "0051");
	strcpy(glSendPack.szPanSeqNo, "000");
	strcpy(glSendPack.szCondCode, "00");
	strcpy(glSendPack.szTrack2, glSendPack.szPan);
	strcat(glSendPack.szTrack2, "D3012");
	strcpy(glSendPack.szServResCode, "221");
	sprintf((char *)glSendPack.szTransFee, "%.*s", LEN_TRANS_FEE, "C00000000");
	sprintf((char *)glSendPack.szAqurId, "%.*s", LEN_AQUR_ID, "111129");
	sprintf((char *)glSendPack.szPoscCode, "%.*s", LEN_POSC_CODE, "06");
	sprintf((char *)glSendPack.szPosDataCode, "%.*s", LEN_POS_CODE, "510101513344101");
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("tid", temp);
	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMid", temp);
	sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("curcode", temp);
	sprintf((char *)glSendPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMNL", temp);
	sprintf((char *)glSendPack.szMNL, "%.*s", LEN_MNL, temp);
	glSysCtrl.ulSTAN = useStan;
	sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN); 
	glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;
	sprintf((char *)glSendPack.szRRN, "000000%s", glSendPack.szSTAN);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("tid", temp);
	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
	//Form data here
	memset(SN, '\0', strlen(SN)); 
	ReadSN(SN);
	if ('\0' == SN[0]) {
		//No serial
		strcpy(theUHI, "000000009");
	}
	strcpy(theUHI, SN);
	sprintf(theUHISend, "01%03d%s", strlen(theUHI), theUHI);
	strcpy(billerinfo, "410155V0100030000004");
	strcpy(paymentcode, "PHONE NUMBER=");
	strcat(paymentcode, phone);
	strcat(paymentcode, ".9501000000000001.");
	//strcpy(glProcInfo.stTranLog.szPan, "9501000000000001");
	memset(glProcInfo.stTranLog.szPan, '\0', strlen(glProcInfo.stTranLog.szPan));
	stpcpy(glProcInfo.stTranLog.szPan, glSendPack.szPan);
	strcpy(glRecvPack.szTranAmt, glSendPack.szTranAmt);
	strcat(paymentcode, glSendPack.szTranAmt);
	strcat(paymentcode, ".1911.051.001.00.06.C00000000.9501000000000001D19112261719659000000.226.");
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMid", temp);
	strcpy(glSendPack.szMerchantID, temp);
	strcat(paymentcode, temp);
	strcat(paymentcode, ".");
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMNL", temp);
	strcat(paymentcode, temp);
	strcat(paymentcode, ".");
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("curcode", temp);
	strcat(paymentcode, temp);
	strcat(paymentcode, ".510101511344101");
	//sprintf(data, "%s%s48%03d%s",theUHISend, billerinfo, strlen(paymentcode), paymentcode);
	memset(data, '\0', strlen(data));
	sprintf(data, "%s%s", "00698MP0101333", phone);
	iRet = SendEmvPayAttitude(data, &iRev);
	if(iRet != 0)
	{
		ShowLogs(1, "Failed. SendEmvData Returned: %d", iRet);
		DisplayInfoNone("UNIFIED PAYMENTS", "NOT SUCCESSFUL", 3);
	}else
	{
		ShowLogs(1, "Response came from host");
		if(revFlag == 0)
		{
			if( memcmp(glRecvPack.szRspCode, "00", LEN_RSP_CODE)!=0 )
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "DECLINED", 0);
			}else
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "APPROVED", 0);
			}
			strcpy(glSendPack.szFwdInstId, phone);
			PrintAllReceipt(PRN_NORMAL);
		}	
		else
		{
			DisplayInfoNone("UNIFIED PAYMENTS", "NOT SUCCESSFUL", 3);
		}
		revFlag = 0;
	} 
	GetTxnCount();
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("chremarks", temp);
	iTemp = atol(temp);
	ShowLogs(1, "Check Value: %d. Current Count: %d.", iTemp, txnCount);
	if(txnCount >= iTemp)
	{
		PackCallHomeData();
	}
}


int payAttitude()
{
	int iRet = 0, iRev = 0, iTemp = 0;
	char number[12] = {0};
	char temp[5] = {0};
	char store[100] = {0};
	char name[50] = {0};
	char fMNL[50] = {0};
	char data[512] = {0};
	char fromServer[10 * 1024] = {0};
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	unsigned char szDispBuff[200];
	unsigned char sBuff[200];
	char vasip[128] = {0};
	char vasport[128] = {0};
	char *ret;
	char rspcode[3] = {0};
	char tempp[128] = {0};
	payAtt = 1;
	txnType = 11;

	if(checkEcr)
		txnType = 13;

	glProcInfo.stTranLog.ucTranType = SALE;
	displayName(name);
	SetCurrTitle(_T(name));

	memset(&glSendPack, 0, sizeof(STISO8583));
	amtCount = 0;
	memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
	memset(glRecvPack.szLocalDateTime, '\0', strlen(glRecvPack.szLocalDateTime));
	memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
	memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
	memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
	memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
	memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
	memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
	memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
	memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));

	if(checkEcr)
	{
		strcpy(glProcInfo.stTranLog.szAmount, ecrModeData.sAmount);
		ShowLogs(1, "2. Amount: %s", glProcInfo.stTranLog.szAmount);
		sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, glProcInfo.stTranLog.szAmount);
		GetDispAmount(glSendPack.szTranAmt, szDispBuff);
	}else
	{
		iRet = GetAmount();
		if( iRet!=0 )
		{
			return ERR_USERCANCEL;
		}
		ShowLogs(1, "2. Amount: %s", glProcInfo.stTranLog.szAmount);
		sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, glProcInfo.stTranLog.szAmount);
		GetDispAmount(glSendPack.szTranAmt, szDispBuff);
	}
	
	iRet = DisplayMsg("Phone Number", szDispBuff, "", number, 11, 11);
	ShowLogs(1, "Phone Number: %s", number);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 0);
		return 0;
	}
	if(strlen(number) < 11)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "PHONE NUMBER TOO SHORT", 0);
		return 0;
	}


	memset(tempp, '\0', strlen(tempp));
	UtilGetEnvEx("uhostmestype", tempp);
	ShowLogs(1, "Message Type of host: %s", tempp);
	if(strstr(tempp, "iso") != NULL)
	{
		formIsoSend(number);
		return 0;
	}

	memset(data, '\0', strlen(data));
	memset(fromServer, '\0', strlen(fromServer));

	strcpy(data, "/");
	strcat(data, glSendPack.szTranAmt);
	strcat(data, "/");
	strcat(data, number);
	strcat(data, "/");
	memset(store, '\0', strlen(store));
	UtilGetEnvEx("txnMid", store);
	
	strcpy(glProcInfo.stTranLog.szPan, "9501000000000001");
	strcpy(glRecvPack.szTranAmt, glSendPack.szTranAmt);
	strcpy(glSendPack.szMerchantID, store);

	strcat(data, store);
	strcat(data, "/");
	memset(store, '\0', strlen(store));
	UtilGetEnvEx("txnMNL", store);
	memset(fMNL, '\0', strlen(fMNL));
	formateMNL(store, fMNL);
	strcat(data, fMNL);
	strcat(data, "/");
	memset(store, '\0', strlen(store));
	UtilGetEnv("tid", store);
	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, store);
	strcat(data, store);
	strcat(data, "/");
	memset(store, '\0', strlen(store));
	UtilGetEnv("curcode", store);
	strcat(data, store);
	strcat(data, "/");
	SysGetTimeIso(timeGotten);
	strncpy(datetime, timeGotten + 2, 10);
	strcat(data, datetime);

	memset(vasip, '\0', strlen(vasip));
	UtilGetEnvEx("uhostip", vasip);

	memset(vasport, '\0', strlen(vasport));
	UtilGetEnvEx("uhostport", vasport);

	if(httpGetDataPayAttitude(vasip, atoi(vasport), "/UPVAS_SERVICES.svc/paywithphone", data, fromServer) == 0)
	{
		//DisplayInfoNone("PAYATTITUDE", "Successful", 0);
		ShowLogs(1, "Response: %s", fromServer);
	}else
	{
		DisplayInfoNone("UNIFIED PAYMENT", "NOT SUCCESSFUL", 0);
		ShowLogs(1, "Response: %s", fromServer);
	}


	payAtt = 0;
	strcpy(glSendPack.szFwdInstId, number);
	memset(glProcInfo.stTranLog.szRspCode, '\0', strlen(glProcInfo.stTranLog.szRspCode));
	if(strlen(fromServer) > 10)
	{
		ret = strstr(fromServer, "RespCode=");
		ShowLogs(1, "1. %s", ret);
		strncpy(rspcode, ret + 9, 2);
		ShowLogs(1, "2. %s", rspcode);
		if(strstr(rspcode, "00"))
		{
			DisplayInfoNone("UNIFIED PAYMENTS", "SUCCESSFUL", 0);
		}
		strcpy(glProcInfo.stTranLog.szRspCode, rspcode);
		sprintf((char *)glRecvPack.szRspCode, "%.*s", LEN_RSP_CODE, rspcode);
		ShowLogs(1, "3. %s", glProcInfo.stTranLog.szRspCode);
	}

	PrintAllReceipt(PRN_NORMAL);

	GetTxnCount();
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("chremarks", temp);
	iTemp = atol(temp);
	ShowLogs(1, "Check Value: %d. Current Count: %d.", iTemp, txnCount);
	if(txnCount >= iTemp)
	{
		PackCallHomeData();
	}

	//For end of day
	storeTxn();
	storeEod();
	//storeEodDuplicate();


	return 0;
}