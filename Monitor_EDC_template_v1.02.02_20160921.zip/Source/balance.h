
#ifndef _BALANCE_H
#define _BALANCE_H


#ifdef __cplusplus
extern "C" {
#endif 

int balanceEnquiry();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
