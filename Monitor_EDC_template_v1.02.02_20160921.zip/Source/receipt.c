#include "global.h"

void formatAmount(char *initAmt, char *finalAmt)
{
	int i, j, k;
	char temp[20] = {0};
	ShowLogs(1, "Init Amount: %s", initAmt);
	for(i = 0, j = 0; i < strlen(initAmt); i++)
	{
		if(initAmt[i] != '0')
		{
			//j = i + 1;
			j = i;
			break;
		}
	}
	strncpy(temp, initAmt + j, strlen(initAmt) - j);
	ShowLogs(1, "Init Amount Temp: %s", temp);
	switch(strlen(temp))
	{
		case 10:
			finalAmt[0] = temp[0];
			finalAmt[1] = ',';
			finalAmt[2] = temp[1];
			finalAmt[3] = temp[2];
			finalAmt[4] = temp[3];
			finalAmt[5] = ',';
			finalAmt[6] = temp[4];
			finalAmt[7] = temp[5];
			finalAmt[8] = temp[6];
			finalAmt[9] = ',';
			finalAmt[10] = temp[7];
			finalAmt[11] = temp[8];
			finalAmt[12] = temp[9];
			finalAmt[13] = '\0';
			break;
		case 9:
			finalAmt[0] = temp[0];
			finalAmt[1] = temp[1];
			finalAmt[2] = temp[2];
			finalAmt[3] = ',';
			finalAmt[4] = temp[3];
			finalAmt[5] = temp[4];
			finalAmt[6] = temp[5];
			finalAmt[7] = ',';
			finalAmt[8] = temp[6];
			finalAmt[9] = temp[7];
			finalAmt[10] = temp[8];
			finalAmt[11] = '\0';
			break;
		case 8:
			finalAmt[0] = temp[0];
			finalAmt[1] = temp[1];
			finalAmt[2] = ',';
			finalAmt[3] = temp[2];
			finalAmt[4] = temp[3];
			finalAmt[5] = temp[4];
			finalAmt[6] = ',';
			finalAmt[7] = temp[5];
			finalAmt[8] = temp[6];
			finalAmt[9] = temp[7];
			finalAmt[10] = '\0';
			break;
		case 7:
			finalAmt[0] = temp[0];
			finalAmt[1] = ',';
			finalAmt[2] = temp[1];
			finalAmt[3] = temp[2];
			finalAmt[4] = temp[3];
			finalAmt[5] = ',';
			finalAmt[6] = temp[4];
			finalAmt[7] = temp[5];
			finalAmt[8] = temp[6];
			finalAmt[9] = '\0';
			break;
		case 6:
			finalAmt[0] = temp[0];
			finalAmt[1] = temp[1];
			finalAmt[2] = temp[2];
			finalAmt[3] = ',';
			finalAmt[4] = temp[3];
			finalAmt[5] = temp[4];
			finalAmt[6] = temp[5];
			finalAmt[7] = '\0';
			break;
		case 5:
			finalAmt[0] = temp[0];
			finalAmt[1] = temp[1];
			finalAmt[2] = ',';
			finalAmt[3] = temp[2];
			finalAmt[4] = temp[3];
			finalAmt[5] = temp[4];
			finalAmt[6] = '\0';
			break;
		case 4:
			finalAmt[0] = temp[0];
			finalAmt[1] = ',';
			finalAmt[2] = temp[1];
			finalAmt[3] = temp[2];
			finalAmt[4] = temp[3];
			finalAmt[5] = '\0';
			break;
		case 3:
		case 2:
		case 1:
		default:
			strcpy(finalAmt, temp);
			break;
	}
	ShowLogs(1, "Amount Formatted: %s", finalAmt);
}

void getBalanceFB(char *data, char *output)
{
	char cCode[4] = {0};
	char decimal[4] = {0};
	char parseAmt[25] = {0};
	char amount[20] = {0};

	strncpy(cCode, data+4, 3);
	strncpy(decimal, data+18, 2);
	strncpy(parseAmt, data+8, 10);

	formatAmount(parseAmt, amount);
	strcpy(output, amount); //Test data
	strcat(output, ".");
	strcat(output, decimal);
	ShowLogs(1, "Balance Leaving: %s", output);
}

void ParseBalance(char *avaAmt, char *legAmt)
{
	char mainData[100] = {0};
	char parseData[500] = { 0 };
	char storeData[500] = { 0 };

	strcpy(mainData, glRecvPack.szAddtAmount);
	ShowLogs(1, "Field 54: %s", mainData);
	memset(parseData, 0x0, sizeof(parseData));
	memset(storeData, 0x0, sizeof(storeData));
	strncpy(parseData, mainData, 20);
	if(strlen(parseData) > 19)
	{
		getBalanceFB(parseData, storeData);
	}

	ShowLogs(1, "Available Balance: %s", storeData);
	strcpy(avaAmt, storeData);


	memset(parseData, 0x0, sizeof(parseData));
	memset(storeData, 0x0, sizeof(storeData));
	strncpy(parseData, mainData + 20, 20);
	if(strlen(parseData) > 19)
	{
		getBalanceFB(parseData, storeData);
	}

	ShowLogs(1, "Ledger Balance: %s", storeData);
	strcpy(legAmt, storeData);
}

// Modified by Kim_LinHB 2014-6-8
int DispPrnReceiptError(int iErrCode)
{
	unsigned char szBuff[100];
	Gui_ClearScr();
	PubBeepErr();
	switch( iErrCode )
	{
	case ERR_PRN_BUSY:
		strcpy(szBuff, _T("PRINTER BUSY"));
		break;

	case ERR_PRN_PAPEROUT:
		strcpy(szBuff, _T("OUT OF PAPER"));
		return Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
		break;

	case ERR_PRN_WRONG_PACKAGE:
		strcpy(szBuff, _T("PRN DATA ERROR"));
		break;

	case ERR_PRN_OVERHEAT:
		strcpy(szBuff, _T("PRINTER OVERHEAT"));
		break;

	case ERR_PRN_OUTOFMEMORY:
		strcpy(szBuff, _T("PRN OVERFLOW"));
		break;

	default:
		strcpy(szBuff, _T("PRINT FAILED"));
		break;
	}
	return Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
}


int PrnCustomLogoReceipt_T(void)
{
	uchar	*psLogoData;
	int		iWidth, iHeigh;

	psLogoData = NULL;
	GetNowPrnLogo(&psLogoData);
	if (psLogoData!=NULL)
	{
		iWidth = 0;
		iHeigh = 0;
		GetLogoWidthHeigh(psLogoData, &iWidth, &iHeigh);
		if (iWidth<384)
		{
			iWidth = (384-iWidth)/2;	// let logo be printed at center
		}
		else
		{
			iWidth = 0;
		}
		//Commented out by Wisdom
		//PrnLeftIndent(100);
		//PrnSetNormal();
		PrnLogo(psLogoData);
		PrnLeftIndent(0);
		PrnStr("\n");
		return 0;
	}

	return -1;
}

void PrnAmountPayArenaReceipt(const uchar *pszIndent, uchar ucNeedSepLine, char *temp, int print)
{
	uchar	szBuff[50], szTotalAmt[12+1], szTotalAmt1[12+1], szTotalAmt2[12+1], stro[13], stro2[13];
	uchar   szTempBuff[100];

	ShowLogs(1, "Inside PayArena Amount 1");
	App_ConvAmountTran(glSendPack.szTranAmt, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);
	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("AMOUNT PAID:    "), szBuff);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Inside PayArena Amount 2");
	
	memset(stro, 0, sizeof(stro));
	strcpy(stro, "0000");
	strcat(stro, glSendPack.szTransFee + 1);
	ShowLogs(1, "Formatted Convenience Fee: %s", stro);
	memset(stro2, 0, sizeof(stro2));
	strncpy(stro2, stro, 12);
	App_ConvAmountTran(stro, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);
	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("CONVENIENCE FEE:"), szBuff);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Inside PayArena Amount 3");
	ShowLogs(1, "2. Formatted: %s", szTempBuff);

	ShowLogs(1, "2. Formatted Convenience Fee: %s", stro);

	PubAscAdd(glSendPack.szTranAmt, stro2, 12, szTotalAmt1);
	ShowLogs(1, "Inside PayArena Amount 3a");
	App_ConvAmountTran(szTotalAmt1, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	ShowLogs(1, "Inside PayArena Amount 3b");
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);
	ShowLogs(1, "Inside PayArena Amount 8");
	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("TOTAL AMOUNT:    "), szBuff);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Inside PayArena Amount 3c");
}

void PrnAmountCashBackReceipt(const uchar *pszIndent, uchar ucNeedSepLine, char *temp, int print)
{
	uchar	szBuff[50], szTotalAmt[12+1], szTotalAmt1[12+1], szTotalAmt2[12+1];
	uchar   szTempBuff[100];

	ShowLogs(1, "Inside Cashback Amount 1");
	App_ConvAmountTran(glProcInfo.stTranLog.szAmount, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);

	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("AMOUNT PAID:    "), szBuff);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Inside Cashback Amount 2");
	

	App_ConvAmountTran(glProcInfo.stTranLog.szTipAmount, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);
	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("CASHBACK AMT:  "), szBuff);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Inside Cashback Amount 3");
	

	App_ConvAmountTran("000000010000", szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);
	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("CHARGE:        "), szBuff);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Inside Cashback Amount 4");

	PubAscAdd(glSendPack.szTranAmt, "000000010000", 12, szTotalAmt1);
	ShowLogs(1, "Inside Cashback Amount 5: %s", szTotalAmt1);
	ShowLogs(1, "Inside Cashback Amount 6");
	ShowLogs(1, "Inside Cashback Amount 7");

    App_ConvAmountTran(szTotalAmt1, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);
	ShowLogs(1, "Inside Cashback Amount 8");
	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("TOTAL AMOUNT:    "), szBuff);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
}

void PrnAmountReceipt(const uchar *pszIndent, uchar ucNeedSepLine, char *temp, int print)
{
	uchar	szBuff[50], szTotalAmt[12+1];
	uchar   szTempBuff[100];
    App_ConvAmountTran(glProcInfo.stTranLog.szAmount, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);
	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("AMOUNT PAID:    "), szBuff);
	//DisplayInfoNone("UNIFIED PAYMENTS", szTempBuff, 3);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
}

void PrnAmountBalanceReceipt(const uchar *pszIndent, uchar ucNeedSepLine, char *temp, int print)
{
	uchar   szTempBuff[100];
	char avaAmt[100] = {0};
	char legAmt[100] = {0};

	ParseBalance(avaAmt, legAmt);

    memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, "NGN 0.00");
	sprintf((char *)szTempBuff, "%s  NGN %12.12s\n",  _T("AVAL. BAL.:    "), avaAmt);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
	
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, "NGN 0.00");
	sprintf((char *)szTempBuff, "%s  NGN %12.12s\n",  _T("LEDG. BAL.:    "), avaAmt);
	
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
}

int StartPrinterReceipt(void)
{
	uchar	ucRet;

	if (!ChkIfIrDAPrinter())
	{
		int iRet;
		while( 1 )
		{
			//Commented out by Wisdom
			//DispPrinting();
			//PrintOne();
			ucRet = PrnStart();
			if( ucRet==PRN_OK )
			{
				return 0;	// print success!
			}

			iRet = DispPrnReceiptError(ucRet);
			if( ucRet!=ERR_PRN_PAPEROUT )
			{
				break;
			}

			if( GUI_ERR_USERCANCELLED == iRet||
				GUI_ERR_TIMEOUT == iRet)
			{
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLEASE REPRINT"), gl_stCenterAttr, GUI_BUTTON_OK, 2, NULL);
				break;
			}
		}
	}
	else
	{
		int iRet;
		SetOffBase(OffBaseCheckPrint);	//????

		//DispPrinting();
		PrnStart();
		//PrintOne();
		while( 1 )
		{
			ucRet = PrnStatus();
			if( ucRet==PRN_OK)
			{
				return PRN_OK;
			}
			else if( ucRet==PRN_BUSY )
			{
				DelayMs(500);
				continue;
			}
			
			iRet = DispPrnReceiptError(ucRet);
			if( ucRet!=ERR_PRN_PAPEROUT )
			{
				break;
			}

			if( GUI_OK != iRet)
			{
				break;
			}
			//DispPrinting();
			PrnStart();
			//PrintOne();
		}
	}

	return ERR_NO_DISP;
}

void MultiLngPrnReceiptStr(const uchar *str, uchar mode)
{
	PrnStr((uchar *)str);
}

void TC(char *s, char *out)
{
    sprintf(out, "   %*s%*s   \n", 12 + strlen(s) / 2, s, 12 - strlen(s) / 2, "");
}

void C(char *s, char *out)
{
    sprintf(out, "%*s%*s\n", 16 + strlen(s) / 2, s, 16 - strlen(s) / 2, "");
}

void MaskAllPan(char *pan, char *mskPan)
{
	int iLen, iRet, i = 0, j = 0;
	iLen = strlen(pan);
	iRet = iLen - 4;
	for(i = 0; i < iLen; i++)
	{
		if(i < 6)
		{
			mskPan[j] = pan[i];
			j++;
		}else if(i >= iRet)
		{
			mskPan[j] = pan[i];
			j++;
		}else
		{
			mskPan[j] = '*';
			j++;
		}
	}
}

void PrnAmountReceiptMan(const uchar *pszIndent, uchar ucNeedSepLine, char *temp, int print)
{
	uchar	szBuff[50], szTotalAmt[12+1];
	uchar   szTempBuff[100];
    App_ConvAmountTran(glProcInfo.stTranLog.szAmount, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	memset(szTempBuff, 0, sizeof(szTempBuff));
	strcpy(temp, szBuff);
	sprintf((char *)szTempBuff, "%s   %12.12s\n",  _T("AMOUNT PAID:    "), szBuff);
	if(print == 1)
		MultiLngPrnReceiptStr(szTempBuff, GUI_ALIGN_LEFT);
}

int PrintReceiptIcc_TMan(uchar ucPrnFlag, char *txn, char *store, char *tType)
{	
	uchar	ucNum;
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1];
	uchar	temp[100] = {0};

	ST_FONT font1,font2;
	font1.CharSet = CHARSET_WEST;
	font1.Width   = 8;
	font1.Height  = 24;
	font1.Bold    = 0;
	font1.Italic  = 0;
	font2.CharSet = CHARSET_WEST;
	font2.Width   = 12;
	font2.Height  = 24;
	font2.Bold    = 0;
	font2.Italic  = 0;

	for(ucNum=0; ucNum<2; ucNum++)
	{
		if(ucNum == 1)
		{
			if( memcmp(glProcInfo.stTranLog.szRspCode, "00", LEN_RSP_CODE) != 0 )
			{
				return 0;
			}
		}
		
		//ShowLogs(1, "James Printing 2");
		PrnInit();
		memset(temp, 0, sizeof(temp));
		UtilGetEnvEx("rptshowlogo", temp);
		if(strstr(temp, "true") != NULL)
		{
			//PrnSetNormal();//For font size
			PrnCustomLogoReceipt_T();//For Logo
			PrnStep(10);//Set Space after printing logo
		}
		PrnSelectFont(&font2,NULL);
		//ShowLogs(1, "James Printing 3");
		if( ucNum==0 )
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptcclabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		else
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptmclabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		//ShowLogs(1, "James Printing 4");
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("bankname", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		//ShowLogs(1, "James Printing 5");
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("merName", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		//ShowLogs(1, "James Printing 6");
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("merAddr", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		//ShowLogs(1, "James Printing 7");
		PrnStep(5);
		PrnStr("\n");
		//if( ucNum==0 )
		//	GetReceiptNumber();
		MultiLngPrnReceiptStr(_T("RECEIPT NO:     "), GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 8");
		memset(temp, 0, sizeof(temp));
		sprintf((char *)temp, "%lu", RctNum);
		strcpy(store, temp);//Receipt Number
		strcat(store, "|");
		memset(szBuff, 0, sizeof(szBuff));
		sprintf(szBuff,"%15.8s\n", temp);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 9");
		memset(szBuff, 0, sizeof(szBuff));
		TC(txn, szBuff);
		strcat(store, txn);//Transaction Type
		strcat(store, "|");
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		//ShowLogs(1, "James Printing 10");
		PrnStep(5);
		MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 11");
		PrnStep(5);
		MultiLngPrnReceiptStr(_T("TERMINAL:       "), GUI_ALIGN_LEFT);
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnvEx("tid", temp);
		sprintf(szBuff,"%15.8s\n", temp);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 12");
		sprintf((char *)szBuff, "%s", _T("DATE:              "));
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		Conv2EngTime2(glProcInfo.stTranLog.szDateTime, szBuff);
		strcat(store, szBuff);//Txn Date
		strcat(store, "|");
		memset(szBuf1, 0, sizeof(szBuf1));
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		PrnStr("\n");
		//ShowLogs(1, "James Printing 13");
		sprintf((char *)szBuff, "%s", _T("TIME:                  "));
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		ShowLogs(1, "Local Time: %s", glSendPack.szLocalTime);
		memset(szBuff, 0, sizeof(szBuff));
		ConvTime(glSendPack.szLocalTime, szBuff);//Time
		//ShowLogs(1, "James Printing 14: %s", szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		strcat(store, szBuff);
		strcat(store, "|");
		PrnStr("\n");
		memset(szBuf1, 0, sizeof(szBuf1));
		strcat(store, "");
		strcat(store, "|");
		sprintf((char *)szBuf1, "CARD:              %.12s\n", glProcInfo.stTranLog.szAppLabel);
		//MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 16");
		if(txnType == 11)
		{
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%s", _T("PHONE NUMBER:       "));
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			sprintf(szBuff,"%s", glSendPack.szFwdInstId);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			strcat(store, glSendPack.szFwdInstId);//Phone Number as Pan
			strcat(store, "|");
			PrnStr("\n");
			memset(szBuff, 0, sizeof(szBuff));
			//MaskAllPan("9501000000000001", szBuff);
			MaskAllPan(glSendPack.szPan, szBuff);
			sprintf((char *)szBuf1, "PAN:    %23.23s", szBuff);
			strcat(store, szBuf1);//Masked Pan
			strcat(store, "|");
			MultiLngPrnReceiptStr(szBuf1,GUI_ALIGN_LEFT);
			PrnStr("\n");
			strcat(store, szBuff);//Pan
			strcat(store, "|");
			//strcat(store, "");//Card Holder Name
			//strcat(store, "|");
		}else
		{
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "EXPIRY DATE:              %2.2s/%2.2s", &glProcInfo.stTranLog.szExpDate[2], glProcInfo.stTranLog.szExpDate);
			strcat(store, szBuff);//Card Expiry Date
			strcat(store, "|");
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			//ShowLogs(1, "James Printing 17");
			PrnStr("\n");
			memset(szBuff, 0, sizeof(szBuff));
			MaskAllPan(glProcInfo.stTranLog.szPan, szBuff);
			sprintf((char *)szBuf1, "PAN:    %23.23s", szBuff);
			//ShowLogs(1, "James Printing 18");
			strcat(store, szBuf1);//Masked Pan
			strcat(store, "|");
			MultiLngPrnReceiptStr(szBuf1,GUI_ALIGN_LEFT);
			//ShowLogs(1, "James Printing 19");
			PrnStr("\n");
		}
		

		if(txnType != 7)
		{
			sprintf((char *)szBuff, "%s       ", _T("CLIENT:  "));
			//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			strcat(store, "");//Card Holder Name
			strcat(store, "|");
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%15.15s\n", glProcInfo.stTranLog.szHolderName);
			//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}else
		{
			strcat(store, "|");
		}
		//ShowLogs(1, "James Printing 20");
		memset(szBuff, 0, sizeof(szBuff));
		strcpy(szBuff, glProcInfo.stTranLog.sAID);
		PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
		PubTrimTailChars(szBuff, 'F');
		memset(szBuf1, 0, sizeof(szBuf1));
		strcat(store, "");
		strcat(store, "|");
		sprintf((char *)szBuf1, "AID:             %.18s\n", szBuff);
		//MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 21");
		

		memset(temp, 0, sizeof(temp));
		PrnSelectFont(&font1, NULL);
		if(manflag == 4 || magflag == 4)
			PrnAmountCashBackReceipt((uchar *)"", TRUE, temp, 1); 
		else
			PrnAmountReceiptMan((uchar *)"", TRUE, temp, 1); 
		strcat(store, temp);//Amt
		strcat(store, "|");
		strcat(store, "|");
		strcat(store, "|");
		//strcat(store, "\n");



		//ShowLogs(1, "James Printing 22");
		PrnStep(5);
		MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
		PrnStep(5);
		memset(temp, 0, sizeof(temp));
		getResponse(glProcInfo.stTranLog.szRspCode, temp);
		PubStrUpper(temp);
		memset(szBuff, 0, sizeof(szBuff));
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		PrnStep(5);
		MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
		PrnStep(10);
		memset(szBuff, 0, sizeof(szBuff));
		MultiLngPrnReceiptStr(_T("RESPONSE CODE: "), GUI_ALIGN_LEFT);
		strcat(store, glProcInfo.stTranLog.szRspCode);//Response Code
		strcat(store, "|");
		sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szRspCode);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//if(txnType == 11)//Business needs
		if(0)
		{
			strcat(store, "NA");//Auth Code
			strcat(store, "|");
			strcat(store, "NA");//Stan
			strcat(store, "|");
			strcat(store, "NA");//RRN
			strcat(store, "|");
			strcat(store, "\n");
		}else
		{
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("AUTHCODE:      "), GUI_ALIGN_LEFT);
			strcat(store, glProcInfo.stTranLog.szAuthCode);//Auth Code
			strcat(store, "|");
			sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szAuthCode);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			//ShowLogs(1, "James Printing 25");
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("STAN:          "), GUI_ALIGN_LEFT);
			strcat(store, glRecvPack.szSTAN);
			strcat(store, "|");
			sprintf(szBuff,"%16.16s\n", glRecvPack.szSTAN);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			//ShowLogs(1, "James Printing 26");
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("RRN:           "), GUI_ALIGN_LEFT);
			strcat(store, glProcInfo.stTranLog.szRRN);//Rrn
			strcat(store, "|");
			strcat(store, "\n");
			sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szRRN);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			//ShowLogs(1, "James Printing 27");
			PrnStr("\n");
		}
		if( ucNum==0 )
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfootertext", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfnlabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		else
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfootertext", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfnlabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		//ShowLogs(1, "James Printing 28");
		if( ucNum==1)
		{
			//Comment back for mtip and advt
			/*
			PrnStr("\n\n");
			sprintf((char *)szBuff, "%s\n", _T("CARDHOLDER SIGNATURE"));
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			PrnStr("\n\n");
			PrnStr("-----------------------------\n");
			MultiLngPrnReceiptStr("I ACKNOWLEDGE SATISFACTORY RECEIPT \nOF RELATIVE  GOODS/SERVICE\n", GUI_ALIGN_LEFT);
			*/
		}
		PrnStr("\n\n");
		MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
		PrnStr("\n\n\n\n\n\n\n\n");

		memset(temp, 0, sizeof(temp));
		UtilGetEnvEx("rptsbarcode", temp);
		if(strstr(temp, "true") != NULL)
		{
			//Print Barcode here
			PrnStep(10);//Set Space after printing logo
		}
		//ShowLogs(1, "James Printing 29");
		if(!checkEcr)
		{
			StartPrinterReceipt();
			if(txnType == 5)
    			return 0;

			if( ucNum==0)
			{
				if( memcmp(glProcInfo.stTranLog.szRspCode, "00", LEN_RSP_CODE) != 0 )
					return 0;
	            kbflush();
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PRESS ANY KEY"), gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, NULL);
			}
		}
		//ShowLogs(1, "James Printing 30");
	}
	return 0;
}

void Conv2EngTime2(const uchar *pszDateTime, uchar *pszEngTime)
{
    uchar   Month[12][5] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
    uchar	ucMonth;

	ucMonth = (uchar)((PubAsc2Long(&pszDateTime[4], 2)-1) % 12);
	sprintf((char *)pszEngTime, "%s %2.2s, %4.4s", Month[ucMonth],
			pszDateTime+6, pszDateTime);
}

void ConvTime(const uchar *pszDateTime, uchar *pszEngTime)
{
	pszEngTime[0] = pszDateTime[0];
    pszEngTime[1] = pszDateTime[1];
    pszEngTime[2] = ':';
    pszEngTime[3] = pszDateTime[2];
    pszEngTime[4] = pszDateTime[3];
    pszEngTime[5] = ':';
    pszEngTime[6] = pszDateTime[4];
    pszEngTime[7] = pszDateTime[5];
    ShowLogs(1, "Final Time: %s", pszEngTime);
}

int PrintReceiptIcc_T(uchar ucPrnFlag, char *txn, char *store, char *tType)
{	
	uchar	ucNum;
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1];
	uchar	temp[100] = {0};

	if(txnType == 9 || txnType == 10 || txnType == 11)
	{
		PrintReceiptIcc_TMan(ucPrnFlag, txn, store, tType);
		return 0;
	}

	ST_FONT font1,font2;
	font1.CharSet = CHARSET_WEST;
	font1.Width   = 8;
	font1.Height  = 24;
	font1.Bold    = 0;
	font1.Italic  = 0;
	font2.CharSet = CHARSET_WEST;
	font2.Width   = 12;
	font2.Height  = 24;
	font2.Bold    = 0;
	font2.Italic  = 0;

	for(ucNum=0; ucNum<2; ucNum++)
	{
		//ShowLogs(1, "James Printing 1");
		if(ucNum == 1)
		{
			if( memcmp(glProcInfo.stTranLog.szRspCode, "00", LEN_RSP_CODE) != 0 )
			{
				return 0;
			}
		}
		//ShowLogs(1, "James Printing 2");
		PrnInit();
		memset(temp, 0, sizeof(temp));
		UtilGetEnvEx("rptshowlogo", temp);
		if(strstr(temp, "true") != NULL)
		{
			//PrnSetNormal();//For font size
			PrnCustomLogoReceipt_T();//For Logo
			PrnStep(10);//Set Space after printing logo
		}
		PrnSelectFont(&font2,NULL);
		//ShowLogs(1, "James Printing 3");
		if( ucNum==0 )
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptcclabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		else
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptmclabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		//ShowLogs(1, "James Printing 4");
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("bankname", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		//ShowLogs(1, "James Printing 5");
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("merName", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		//ShowLogs(1, "James Printing 6");
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("merAddr", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		//ShowLogs(1, "James Printing 7");
		PrnStep(5);
		PrnStr("\n");
		//if( ucNum==0 )
		//	GetReceiptNumber();
		MultiLngPrnReceiptStr(_T("RECEIPT NO:     "), GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 8");
		memset(temp, 0, sizeof(temp));
		sprintf((char *)temp, "%lu", RctNum);
		strcpy(store, temp);//Receipt Number
		strcat(store, "|");
		memset(szBuff, 0, sizeof(szBuff));
		sprintf(szBuff,"%15.8s\n", temp);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 9");
		memset(szBuff, 0, sizeof(szBuff));
		TC(txn, szBuff);
		strcat(store, txn);//Transaction Type
		strcat(store, "|");
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		//ShowLogs(1, "James Printing 10");
		PrnStep(5);
		MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 11");
		PrnStep(5);
		MultiLngPrnReceiptStr(_T("TERMINAL:       "), GUI_ALIGN_LEFT);
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnvEx("tid", temp);
		sprintf(szBuff,"%15.8s\n", temp);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 12");
		sprintf((char *)szBuff, "%s", _T("DATE:              "));
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		Conv2EngTime2(glProcInfo.stTranLog.szDateTime, szBuff);
		strcat(store, szBuff);//Txn Date
		strcat(store, "|");
		memset(szBuf1, 0, sizeof(szBuf1));
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		PrnStr("\n");
		//ShowLogs(1, "James Printing 13");
		sprintf((char *)szBuff, "%s", _T("TIME:                  "));
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		ShowLogs(1, "Local Time: %s", glSendPack.szLocalTime);
		memset(szBuff, 0, sizeof(szBuff));
		ConvTime(glSendPack.szLocalTime, szBuff);//Time
		//ShowLogs(1, "James Printing 14: %s", szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		strcat(store, szBuff);
		strcat(store, "|");
		PrnStr("\n");
		memset(szBuf1, 0, sizeof(szBuf1));
		strcat(store, glProcInfo.stTranLog.szAppLabel);//App Name
		strcat(store, "|");
		sprintf((char *)szBuf1, "CARD:              %.12s\n", glProcInfo.stTranLog.szAppLabel);
		MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 16");
		memset(szBuff, 0, sizeof(szBuff));
		sprintf((char *)szBuff, "EXPIRY DATE:              %2.2s/%2.2s", &glProcInfo.stTranLog.szExpDate[2], glProcInfo.stTranLog.szExpDate);
		strcat(store, szBuff);//Card Expiry Date
		strcat(store, "|");
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 17");
		PrnStr("\n");
		memset(szBuff, 0, sizeof(szBuff));
		MaskAllPan(glProcInfo.stTranLog.szPan, szBuff);
		sprintf((char *)szBuf1, "PAN:    %23.23s", szBuff);
		//ShowLogs(1, "James Printing 18");
		strcat(store, szBuf1);//Masked Pan
		strcat(store, "|");
		MultiLngPrnReceiptStr(szBuf1,GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 19");
		PrnStr("\n");
		if(txnType != 7)
		{
			sprintf((char *)szBuff, "%s       ", _T("CLIENT:  "));
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			strcat(store, glProcInfo.stTranLog.szHolderName);//Card Holder Name
			strcat(store, "|");
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%15.15s\n", glProcInfo.stTranLog.szHolderName);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}else
		{
			strcat(store, "|");
		}
		//ShowLogs(1, "James Printing 20");
		memset(szBuff, 0, sizeof(szBuff));
		strcpy(szBuff, glProcInfo.stTranLog.sAID);
		PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
		PubTrimTailChars(szBuff, 'F');
		memset(szBuf1, 0, sizeof(szBuf1));
		strcat(store, szBuff);
		strcat(store, "|");
		sprintf((char *)szBuf1, "AID:             %.18s\n", szBuff);
		MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);

		//ShowLogs(1, "James Printing 21");
		switch(txnType)
		{
			case 1:
			case 2:
			case 3:
			case 4:
			case 6:
			case 7:
			case 12:
			case 13:
				memset(temp, 0, sizeof(temp));
				PrnSelectFont(&font1, NULL);
				PrnAmountReceipt((uchar *)"", TRUE, temp, 1); 
				strcat(store, temp);//Amt
				strcat(store, "|");
				strcat(store, "|");
				strcat(store, "|");
				//strcat(store, "\n");
				break;
			case 5:
				memset(temp, 0, sizeof(temp));
				PrnSelectFont(&font1, NULL);
				PrnAmountBalanceReceipt((uchar *)"", TRUE, temp, 1); 
				strcat(store, temp);//Amt
				strcat(store, "|");
				strcat(store, "|");
				strcat(store, "|");
				//strcat(store, "\n");
				break;
			case 8:
				ShowLogs(1, "Inside Case 8");
				memset(temp, 0, sizeof(temp));
				PrnSelectFont(&font1, NULL);
				PrnAmountCashBackReceipt((uchar *)"", TRUE, temp, 1); 
				strcat(store, temp);
				strcat(store, "|");
				strcat(store, "|");
				strcat(store, "|");
				//strcat(store, "\n");
				break;
			case 14:
				ShowLogs(1, "Inside Payments");
				memset(temp, 0, sizeof(temp));
				PrnSelectFont(&font1, NULL);
				PrnAmountPayArenaReceipt((uchar *)"", TRUE, temp, 1); 
				strcat(store, temp);
				strcat(store, "|");
				strcat(store, "|");
				strcat(store, "|");
				//strcat(store, "\n");
				break;
			case 15:
				ShowLogs(1, "Inside PayAreana");
				memset(temp, 0, sizeof(temp));
				PrnSelectFont(&font1, NULL);
				PrnAmountPayArenaReceipt((uchar *)"", TRUE, temp, 1); 
				strcat(store, temp);
				strcat(store, "|");
				strcat(store, "|");
				strcat(store, "|");
				//strcat(store, "\n");
				break;
			default:
				break;
		}
		//ShowLogs(1, "James Printing 22");
		PrnStep(5);
		MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
		PrnStep(5);
		memset(temp, 0, sizeof(temp));
		getResponse(glProcInfo.stTranLog.szRspCode, temp);
		PubStrUpper(temp);
		memset(szBuff, 0, sizeof(szBuff));
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		PrnStep(5);
		MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
		PrnStep(10);
		memset(szBuff, 0, sizeof(szBuff));
		MultiLngPrnReceiptStr(_T("RESPONSE CODE: "), GUI_ALIGN_LEFT);
		strcat(store, glProcInfo.stTranLog.szRspCode);//Response Code
		strcat(store, "|");
		sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szRspCode);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		memset(szBuff, 0, sizeof(szBuff));
		MultiLngPrnReceiptStr(_T("AUTHCODE:      "), GUI_ALIGN_LEFT);
		strcat(store, glProcInfo.stTranLog.szAuthCode);//Auth Code
		strcat(store, "|");
		sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szAuthCode);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 25");
		memset(szBuff, 0, sizeof(szBuff));
		MultiLngPrnReceiptStr(_T("STAN:          "), GUI_ALIGN_LEFT);
		strcat(store, glRecvPack.szSTAN);
		strcat(store, "|");
		sprintf(szBuff,"%16.16s\n", glRecvPack.szSTAN);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 26");
		memset(szBuff, 0, sizeof(szBuff));
		MultiLngPrnReceiptStr(_T("RRN:           "), GUI_ALIGN_LEFT);
		strcat(store, glProcInfo.stTranLog.szRRN);//Rrn
		strcat(store, "|");
		strcat(store, "\n");
		sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szRRN);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 27");
		PrnStr("\n\n");

		if( glProcInfo.stTranLog.uiEntryMode & MODE_OFF_PIN )
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			C("PIN VERIFIED", szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		}
		else
		{
			//Do nothing about it
		}
		PrnStr("\n\n");

		if(txnType == 15 || txnType == 14)
		{
			int j = 0;
			PrnStep(5);
			MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
			PrnStep(5);
			memset(szBuff, 0, sizeof(szBuff));
			TC("PAYMENT DETAILS", szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
			PrnStep(5);
			MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
			PrnStep(5);
			for(j = 0; j < printVas.count; j++)
			{
				memset(szBuff, 0, sizeof(szBuff));
				strcpy(szBuff, printVas.name[j]);
				strcat(szBuff, ":  ");
				strcat(szBuff, printVas.value[j]);
				strcat(szBuff, "\n");
				MultiLngPrnReceiptStr(_T(szBuff), GUI_ALIGN_LEFT);
			}
			if(txnType == 15)
				MultiLngPrnReceiptStr(_T(glRecvPack.szBillers), GUI_ALIGN_LEFT);
			PrnStr("\n");
			//Parse Response Field 62 in addition here
			PrnStep(5);
			MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
			PrnStep(10);
		}
		PrnStr("\n\n");

		if( ucNum==0 )
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfootertext", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfnlabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		else
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfootertext", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfnlabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		//ShowLogs(1, "James Printing 28");
		if( ucNum==1)
		{
			//Comment back for mtip and advt
			/*
			PrnStr("\n\n");
			sprintf((char *)szBuff, "%s\n", _T("CARDHOLDER SIGNATURE"));
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			PrnStr("\n\n");
			PrnStr("-----------------------------\n");
			MultiLngPrnReceiptStr("I ACKNOWLEDGE SATISFACTORY RECEIPT \nOF RELATIVE  GOODS/SERVICE\n", GUI_ALIGN_LEFT);
			*/
		}
		PrnStr("\n\n");
		MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
		PrnStr("\n\n\n\n\n\n\n\n");

		memset(temp, 0, sizeof(temp));
		UtilGetEnvEx("rptsbarcode", temp);
		if(strstr(temp, "true") != NULL)
		{
			//Print Barcode here
			PrnStep(10);//Set Space after printing logo
		}
		//ShowLogs(1, "James Printing 29");
		if(!checkEcr)
		{
			StartPrinterReceipt();
			if(txnType == 5)
    			return 0;

			if( ucNum==0)
			{
				if( memcmp(glProcInfo.stTranLog.szRspCode, "00", LEN_RSP_CODE) != 0 )
					return 0;
	            kbflush();
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PRESS ANY KEY"), gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, NULL);
			}
		}
		//ShowLogs(1, "James Printing 30");
	}
	return 0;
}

int ext = 0;
int PrintTxn(uchar ucPrnFlag, char* txn, char *store, char *tType)
{
	//ShowLogs(1, "James Printing Inside 1");
	ext = 0;
	if(!checkEcr)	
		DisplayInfoNone("UNIFIED PAYMENTS", "PRINTING...", 0);
	else
	{
		char ecrcheck[128] = {0};
		memset(ecrcheck, '\0', strlen(ecrcheck));
		UtilGetEnv("ecrreceipt", ecrcheck);
		if(strncmp(ecrcheck, "true", 4) == 0)
		{
    		checkEcr = 0;
    		DisplayInfoNone("UNIFIED PAYMENTS", "PRINTING...", 0);
    		ext = 1;
		}
	}
	PrintReceiptIcc_T(ucPrnFlag, txn, store, tType);
	if(ext == 1)
	{
		checkEcr = 1;//Return the settings
		ext = 0;
	}
	return 0;
}

void PrintAllReceipt(uchar ucPrnFlag)
{
	char store[2 * 1024] = {0};
	memset(store, '\0', strlen(store));
	if(revSend)
	{
		ShowLogs(1, "Came from Reversal, No Printing");
		//If from a reversed txn dont print
		//Print now
		revSend = 0;
		//return;
	}
	switch(txnType)
	{
		case 1:
			PrintTxn(ucPrnFlag, "PURCHASE", store, "CHIP");
			//ShowLogs(1, "Chip Purchase: %s", store);
			//storeReprint(store);
			break;
		case 2:
			PrintTxn(ucPrnFlag, "CASH ADVANCE", store, "CHIP");
			//storeReprint(store);
			break;
		case 3:
			ShowLogs(1, "Trying to print PREAUTH");
			PrintTxn(ucPrnFlag, "PREAUTH", store, "CHIP");
			//storeReprint(store);
			break;
		case 4:
			PrintTxn(ucPrnFlag, "REFUND", store, "CHIP");
			//storeReprint(store);
			break;
		case 5:
			PrintTxn(ucPrnFlag, "BALANCE ENQUIRY", store, "CHIP");
			break;
		case 6:
			PrintTxn(ucPrnFlag, "SALES COMPLETION", store, "CHIP");
			//storeReprint(store);
			break;
		case 7:
			PrintTxn(ucPrnFlag, "REVERSAL", store, "MANUAL");
			//storeReprint(store);
			break;
		case 8:
			PrintTxn(ucPrnFlag, "CASHBACK", store, "CHIP");
			//storeReprint(store);
			break;
		case 9:
			//ShowLogs(1, "Yeah it is man entry");
			if(manflag == 1)
				PrintTxn(ucPrnFlag, "PURCHASE", store, "MANUAL ENTRY");
			else if(manflag == 2)
				PrintTxn(ucPrnFlag, "PRE AUTH", store, "MANUAL ENTRY");
			else if(manflag == 3)
				PrintTxn(ucPrnFlag, "REFUND", store, "MANUAL ENTRY");
			else if(manflag == 4)
				PrintTxn(ucPrnFlag, "CASHBACK", store, "MANUAL ENTRY");
			else if(manflag == 5)
				PrintTxn(ucPrnFlag, "COMPLETION", store, "MANUAL ENTRY");
			//storeReprint(store);
			break;
		case 10:
			ShowLogs(1, "Yeah it is mag swipe");
			if(magflag == 1)
				PrintTxn(ucPrnFlag, "PURCHASE", store, "MAGNETIC SWIPE");
			else if(magflag == 2)
				PrintTxn(ucPrnFlag, "PRE AUTH", store, "MAGNETIC SWIPE");
			else if(magflag == 3)
				PrintTxn(ucPrnFlag, "REFUND", store, "MAGNETIC SWIPE");
			else if(magflag == 4)
				PrintTxn(ucPrnFlag, "CASHBACK", store, "MAGNETIC SWIPE");
			else if(magflag == 5)
				PrintTxn(ucPrnFlag, "COMPLETION", store, "MAGNETIC SWIPE");
			//storeReprint(store);
			break;
		case 11:
			PrintTxn(ucPrnFlag, "PAYATTITUDE", store, "CUSTOM");
			//storeReprint(store);
			break;
		case 12:
			PrintTxn(ucPrnFlag, "PURCHASE", store, "NFC");
			//storeReprint(store);
			break;
		case 13:
			PrintTxn(ucPrnFlag, "PURCHASE", store, "CHIP");
			//storeReprint(store);
			break;
		case 14:
			PrintTxn(ucPrnFlag, "PAYMENTS", store, "CHIP");
			txnType = 0;//Used to correct something
			//storeReprint(store);
			break;
		case 15:
			PrintTxn(ucPrnFlag, "PAYARENA", store, "CHIP");
			txnType = 0;//Used to correct something
			//storeReprint(store);
			break;
		default:
			break;
	}
}

//Start Store
int PrintReceiptStoreTMan(char *txn, char *store, char *tType)
{	
	uchar	ucNum;
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1];
	uchar	temp[100] = {0};

	//ShowLogs(1, "James Printing 2");
	//PrnInit();
	memset(temp, 0, sizeof(temp));
	UtilGetEnvEx("rptshowlogo", temp);
	if(strstr(temp, "true") != NULL)
	{
		//PrnSetNormal();//For font size
		//PrnCustomLogoReceipt_T();//For Logo
		//PrnStep(10);//Set Space after printing logo
	}
	//PrnSelectFont(&font2,NULL);
	//ShowLogs(1, "James Printing 3");
	
	//ShowLogs(1, "James Printing 4");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("bankname", temp);
	C(temp, szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 5");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("merName", temp);
	C(temp, szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 6");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("merAddr", temp);
	C(temp, szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 7");
	//PrnStep(5);
	//PrnStr("\n");
	//if( ucNum==0 )
	//	GetReceiptNumber();
	//MultiLngPrnReceiptStr(_T("RECEIPT NO:     "), GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 8");
	memset(temp, 0, sizeof(temp));
	sprintf((char *)temp, "%lu", RctNum);
	strcpy(store, temp);//Receipt Number
	strcat(store, "|");
	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff,"%15.8s\n", temp);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 9");
	memset(szBuff, 0, sizeof(szBuff));
	TC(txn, szBuff);
	strcat(store, txn);//Transaction Type
	strcat(store, "|");
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 10");
	//PrnStep(5);
	//MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 11");
	//PrnStep(5);
	//MultiLngPrnReceiptStr(_T("TERMINAL:       "), GUI_ALIGN_LEFT);
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnvEx("tid", temp);
	sprintf(szBuff,"%15.8s\n", temp);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 12");
	sprintf((char *)szBuff, "%s", _T("DATE:              "));
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	Conv2EngTime2(glProcInfo.stTranLog.szDateTime, szBuff);
	strcat(store, szBuff);//Txn Date
	strcat(store, "|");
	memset(szBuf1, 0, sizeof(szBuf1));
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//PrnStr("\n");
	//ShowLogs(1, "James Printing 13");
	sprintf((char *)szBuff, "%s", _T("TIME:                  "));
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Local Time: %s", glSendPack.szLocalTime);
	memset(szBuff, 0, sizeof(szBuff));
	ConvTime(glSendPack.szLocalTime, szBuff);//Time
	//ShowLogs(1, "James Printing 14: %s", szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	strcat(store, szBuff);
	strcat(store, "|");
	//PrnStr("\n");
	memset(szBuf1, 0, sizeof(szBuf1));
	strcat(store, "");
	strcat(store, "|");
	sprintf((char *)szBuf1, "CARD:              %.12s\n", glProcInfo.stTranLog.szAppLabel);
	//MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 16");
	if(txnType == 11)
	{
		memset(szBuff, 0, sizeof(szBuff));
		sprintf((char *)szBuff, "%s", _T("PHONE NUMBER:       "));
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		memset(szBuff, 0, sizeof(szBuff));
		sprintf(szBuff,"%s", glSendPack.szFwdInstId);
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		strcat(store, glSendPack.szFwdInstId);//Phone Number as Pan
		strcat(store, "|");
		//PrnStr("\n");
		memset(szBuff, 0, sizeof(szBuff));
		//MaskAllPan("9501000000000001", szBuff);
		MaskAllPan(glSendPack.szPan, szBuff);
		sprintf((char *)szBuf1, "PAN:    %23.23s", szBuff);
		strcat(store, szBuf1);//Masked Pan
		strcat(store, "|");
		//MultiLngPrnReceiptStr(szBuf1,GUI_ALIGN_LEFT);
		//PrnStr("\n");
		strcat(store, szBuff);//Pan
		strcat(store, "|");
		//strcat(store, "");//Card Holder Name
		//strcat(store, "|");
	}else
	{
		memset(szBuff, 0, sizeof(szBuff));
		sprintf((char *)szBuff, "EXPIRY DATE:              %2.2s/%2.2s", &glProcInfo.stTranLog.szExpDate[2], glProcInfo.stTranLog.szExpDate);
		strcat(store, szBuff);//Card Expiry Date
		strcat(store, "|");
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 17");
		//PrnStr("\n");
		memset(szBuff, 0, sizeof(szBuff));
		MaskAllPan(glProcInfo.stTranLog.szPan, szBuff);
		sprintf((char *)szBuf1, "PAN:    %23.23s", szBuff);
		//ShowLogs(1, "James Printing 18");
		strcat(store, szBuf1);//Masked Pan
		strcat(store, "|");
		//MultiLngPrnReceiptStr(szBuf1,GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 19");
		//PrnStr("\n");
	}
	

	if(txnType != 7)
	{
		sprintf((char *)szBuff, "%s       ", _T("CLIENT:  "));
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		strcat(store, "");//Card Holder Name
		strcat(store, "|");
		memset(szBuff, 0, sizeof(szBuff));
		sprintf((char *)szBuff, "%15.15s\n", glProcInfo.stTranLog.szHolderName);
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	}else
	{
		strcat(store, "|");
	}
	//ShowLogs(1, "James Printing 20");
	memset(szBuff, 0, sizeof(szBuff));
	strcpy(szBuff, glProcInfo.stTranLog.sAID);
	PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
	PubTrimTailChars(szBuff, 'F');
	memset(szBuf1, 0, sizeof(szBuf1));
	strcat(store, "");
	strcat(store, "|");
	sprintf((char *)szBuf1, "AID:             %.18s\n", szBuff);
	//MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 21");

	memset(temp, 0, sizeof(temp));
	//PrnSelectFont(&font1, NULL);
	if(manflag == 4 || magflag == 4)
		PrnAmountCashBackReceipt((uchar *)"", TRUE, temp, 1); 
	else
		PrnAmountReceiptMan((uchar *)"", TRUE, temp, 1); 
	strcat(store, temp);//Amt
	strcat(store, "|");
	strcat(store, "|");
	strcat(store, "|");
	//strcat(store, "\n");

	//ShowLogs(1, "James Printing 22");
	//PrnStep(5);
	//MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
	//PrnStep(5);
	memset(temp, 0, sizeof(temp));
	getResponse(glProcInfo.stTranLog.szRspCode, temp);
	PubStrUpper(temp);
	memset(szBuff, 0, sizeof(szBuff));
	C(temp, szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//PrnStep(5);
	//MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
	//PrnStep(10);
	memset(szBuff, 0, sizeof(szBuff));
	//MultiLngPrnReceiptStr(_T("RESPONSE CODE: "), GUI_ALIGN_LEFT);
	strcat(store, glProcInfo.stTranLog.szRspCode);//Response Code
	strcat(store, "|");
	sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szRspCode);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//if(txnType == 11)//Business needs
	if(0)
	{
		strcat(store, "NA");//Auth Code
		strcat(store, "|");
		strcat(store, "NA");//Stan
		strcat(store, "|");
		strcat(store, "NA");//RRN
		strcat(store, "|");
		strcat(store, "\n");
	}else
	{
		memset(szBuff, 0, sizeof(szBuff));
		//MultiLngPrnReceiptStr(_T("AUTHCODE:      "), GUI_ALIGN_LEFT);
		strcat(store, glProcInfo.stTranLog.szAuthCode);//Auth Code
		strcat(store, "|");
		sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szAuthCode);
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 25");
		memset(szBuff, 0, sizeof(szBuff));
		//MultiLngPrnReceiptStr(_T("STAN:          "), GUI_ALIGN_LEFT);
		strcat(store, glRecvPack.szSTAN);
		strcat(store, "|");
		sprintf(szBuff,"%16.16s\n", glRecvPack.szSTAN);
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 26");
		memset(szBuff, 0, sizeof(szBuff));
		//MultiLngPrnReceiptStr(_T("RRN:           "), GUI_ALIGN_LEFT);
		strcat(store, glProcInfo.stTranLog.szRRN);//Rrn
		strcat(store, "|");
		strcat(store, "\n");
		sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szRRN);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		//ShowLogs(1, "James Printing 27");
		//PrnStr("\n");
	}
	return 0;
}

int PrintReceiptStore(char *txn, char *store, char *tType)
{	
	uchar	ucNum;
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1];
	uchar	temp[100] = {0};

	if(txnType == 9 || txnType == 10 || txnType == 11)
	{
		PrintReceiptStoreTMan(txn, store, tType);
		return 0;
	}
	//ShowLogs(1, "James Printing 2");
	//PrnInit();
	memset(temp, 0, sizeof(temp));
	UtilGetEnvEx("rptshowlogo", temp);
	if(strstr(temp, "true") != NULL)
	{
		//PrnSetNormal();//For font size
		//PrnCustomLogoReceipt_T();//For Logo
		//PrnStep(10);//Set Space after printing logo
	}
	//PrnSelectFont(&font2,NULL);
	//ShowLogs(1, "James Printing 3");
	if( ucNum==0 )
	{
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("rptcclabel", temp);
		C(temp, szBuff);
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	}
	else
	{
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("rptmclabel", temp);
		C(temp, szBuff);
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	}
	//ShowLogs(1, "James Printing 4");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("bankname", temp);
	C(temp, szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 5");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("merName", temp);
	C(temp, szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 6");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("merAddr", temp);
	C(temp, szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 7");
	//PrnStep(5);
	//PrnStr("\n");
	//if( ucNum==0 )
	GetReceiptNumber();
	//MultiLngPrnReceiptStr(_T("RECEIPT NO:     "), GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 8");
	memset(temp, 0, sizeof(temp));
	sprintf((char *)temp, "%lu", RctNum);
	strcpy(store, temp);//Receipt Number
	strcat(store, "|");
	memset(szBuff, 0, sizeof(szBuff));
	sprintf(szBuff,"%15.8s\n", temp);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 9");
	memset(szBuff, 0, sizeof(szBuff));
	TC(txn, szBuff);
	strcat(store, txn);//Transaction Type
	strcat(store, "|");
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 10");
	//PrnStep(5);
	//MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 11");
	//PrnStep(5);
	//MultiLngPrnReceiptStr(_T("TERMINAL:       "), GUI_ALIGN_LEFT);
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnvEx("tid", temp);
	sprintf(szBuff,"%15.8s\n", temp);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 12");
	sprintf((char *)szBuff, "%s", _T("DATE:              "));
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	Conv2EngTime2(glProcInfo.stTranLog.szDateTime, szBuff);
	strcat(store, szBuff);//Txn Date
	strcat(store, "|");
	memset(szBuf1, 0, sizeof(szBuf1));
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//PrnStr("\n");
	//ShowLogs(1, "James Printing 13");
	sprintf((char *)szBuff, "%s", _T("TIME:                  "));
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Local Time: %s", glSendPack.szLocalTime);
	memset(szBuff, 0, sizeof(szBuff));
	ConvTime(glSendPack.szLocalTime, szBuff);//Time
	//ShowLogs(1, "James Printing 14: %s", szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	strcat(store, szBuff);
	strcat(store, "|");
	//PrnStr("\n");
	memset(szBuf1, 0, sizeof(szBuf1));
	strcat(store, glProcInfo.stTranLog.szAppLabel);//App Name
	strcat(store, "|");
	sprintf((char *)szBuf1, "CARD:              %.12s\n", glProcInfo.stTranLog.szAppLabel);
	//MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 16");
	memset(szBuff, 0, sizeof(szBuff));
	sprintf((char *)szBuff, "EXPIRY DATE:              %2.2s/%2.2s", &glProcInfo.stTranLog.szExpDate[2], glProcInfo.stTranLog.szExpDate);
	strcat(store, szBuff);//Card Expiry Date
	strcat(store, "|");
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 17");
	//PrnStr("\n");
	memset(szBuff, 0, sizeof(szBuff));
	MaskAllPan(glProcInfo.stTranLog.szPan, szBuff);
	sprintf((char *)szBuf1, "PAN:    %23.23s", szBuff);
	//ShowLogs(1, "James Printing 18");
	strcat(store, szBuf1);//Masked Pan
	strcat(store, "|");
	//MultiLngPrnReceiptStr(szBuf1,GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 19");
	//PrnStr("\n");
	if(txnType != 7)
	{
		sprintf((char *)szBuff, "%s       ", _T("CLIENT:  "));
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		strcat(store, glProcInfo.stTranLog.szHolderName);//Card Holder Name
		strcat(store, "|");
		memset(szBuff, 0, sizeof(szBuff));
		sprintf((char *)szBuff, "%15.15s\n", glProcInfo.stTranLog.szHolderName);
		//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	}else
	{
		strcat(store, "|");
	}
	//ShowLogs(1, "James Printing 20");
	memset(szBuff, 0, sizeof(szBuff));
	strcpy(szBuff, glProcInfo.stTranLog.sAID);
	PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
	PubTrimTailChars(szBuff, 'F');
	memset(szBuf1, 0, sizeof(szBuf1));
	strcat(store, szBuff);
	strcat(store, "|");
	sprintf((char *)szBuf1, "AID:             %.18s\n", szBuff);
	//MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 21");
	switch(txnType)
	{
		case 1:
		case 2:
		case 3:
		case 4:
		case 6:
		case 7:
		case 12:
		case 13:
			memset(temp, 0, sizeof(temp));
			//PrnSelectFont(&font1, NULL);
			PrnAmountReceipt((uchar *)"", TRUE, temp, 1); 
			strcat(store, temp);//Amt
			strcat(store, "|");
			strcat(store, "|");
			strcat(store, "|");
			//strcat(store, "\n");
			break;
		case 5:
			memset(temp, 0, sizeof(temp));
			//PrnSelectFont(&font1, NULL);
			PrnAmountBalanceReceipt((uchar *)"", TRUE, temp, 1); 
			strcat(store, temp);//Amt
			strcat(store, "|");
			strcat(store, "|");
			strcat(store, "|");
			//strcat(store, "\n");
			break;
		case 8:
			ShowLogs(1, "Inside Case 8");
			memset(temp, 0, sizeof(temp));
			//PrnSelectFont(&font1, NULL);
			PrnAmountCashBackReceipt((uchar *)"", TRUE, temp, 1); 
			strcat(store, temp);
			strcat(store, "|");
			strcat(store, "|");
			strcat(store, "|");
			//strcat(store, "\n");
			break;
		default:
			break;
	}
	//ShowLogs(1, "James Printing 22");
	//PrnStep(5);
	//MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
	//PrnStep(5);
	memset(temp, 0, sizeof(temp));
	getResponse(glProcInfo.stTranLog.szRspCode, temp);
	PubStrUpper(temp);
	memset(szBuff, 0, sizeof(szBuff));
	C(temp, szBuff);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//PrnStep(5);
	//MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
	//PrnStep(10);
	memset(szBuff, 0, sizeof(szBuff));
	//MultiLngPrnReceiptStr(_T("RESPONSE CODE: "), GUI_ALIGN_LEFT);
	strcat(store, glProcInfo.stTranLog.szRspCode);//Response Code
	strcat(store, "|");
	sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szRspCode);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	memset(szBuff, 0, sizeof(szBuff));
	//MultiLngPrnReceiptStr(_T("AUTHCODE:      "), GUI_ALIGN_LEFT);
	strcat(store, glProcInfo.stTranLog.szAuthCode);//Auth Code
	strcat(store, "|");
	sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szAuthCode);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 25");
	memset(szBuff, 0, sizeof(szBuff));
	//MultiLngPrnReceiptStr(_T("STAN:          "), GUI_ALIGN_LEFT);
	strcat(store, glRecvPack.szSTAN);
	strcat(store, "|");
	sprintf(szBuff,"%16.16s\n", glRecvPack.szSTAN);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 26");
	memset(szBuff, 0, sizeof(szBuff));
	//MultiLngPrnReceiptStr(_T("RRN:           "), GUI_ALIGN_LEFT);
	strcat(store, glProcInfo.stTranLog.szRRN);//Rrn
	strcat(store, "|");
	strcat(store, "\n");
	sprintf(szBuff,"%16.16s\n", glProcInfo.stTranLog.szRRN);
	//MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 27");
	//PrnStr("\n");
	return 0;
}

void storeprint()
{
	char store[2 * 1024] = {0};
	memset(store, '\0', strlen(store));
	switch(txnType)
	{
		case 1:
			PrintReceiptStore("PURCHASE", store, "CHIP");
			storeReprint(store);
			break;
		case 2:
			PrintReceiptStore("CASH ADVANCE", store, "CHIP");
			storeReprint(store);
			break;
		case 3:
			PrintReceiptStore("PREAUTH", store, "CHIP");
			storeReprint(store);
			break;
		case 4:
			PrintReceiptStore("REFUND", store, "CHIP");
			storeReprint(store);
			break;
		case 5:
			PrintReceiptStore("BALANCE ENQUIRY", store, "CHIP");
			break;
		case 6:
			PrintReceiptStore("SALES COMPLETION", store, "CHIP");
			storeReprint(store);
			break;
		case 7:
			PrintReceiptStore("REVERSAL", store, "MANUAL");
			storeReprint(store);
			break;
		case 8:
			PrintReceiptStore("CASHBACK", store, "CHIP");
			storeReprint(store);
			break;
		case 9:
			if(manflag == 1)
				PrintReceiptStore("PURCHASE", store, "MANUAL ENTRY");
			else if(manflag == 2)
				PrintReceiptStore("PRE AUTH", store, "MANUAL ENTRY");
			else if(manflag == 3)
				PrintReceiptStore("REFUND", store, "MANUAL ENTRY");
			else if(manflag == 4)
				PrintReceiptStore("CASHBACK", store, "MANUAL ENTRY");
			else if(manflag == 5)
				PrintReceiptStore("COMPLETION", store, "MANUAL ENTRY");
			storeReprint(store);
			break;
		case 10:
			if(magflag == 1)
				PrintReceiptStore("PURCHASE", store, "MAGNETIC SWIPE");
			else if(magflag == 2)
				PrintReceiptStore("PRE AUTH", store, "MAGNETIC SWIPE");
			else if(magflag == 3)
				PrintReceiptStore("REFUND", store, "MAGNETIC SWIPE");
			else if(magflag == 4)
				PrintReceiptStore("CASHBACK", store, "MAGNETIC SWIPE");
			else if(magflag == 5)
				PrintReceiptStore("COMPLETION", store, "MAGNETIC SWIPE");
			storeReprint(store);
			break;
		case 11:
			PrintReceiptStore("PAYATTITUDE", store, "CUSTOM");
			storeReprint(store);
			break;
		case 12:
			PrintReceiptStore("PURCHASE", store, "NFC");
			storeReprint(store);
			break;
		case 13:
			PrintReceiptStore("PURCHASE", store, "CHIP");
			storeReprint(store);
			break;
		case 14:
			PrintReceiptStore("PAYMENTS", store, "CHIP");
			storeReprint(store);
			break;
		case 15:
			PrintReceiptStore("PAYARENA", store, "CHIP");
			storeReprint(store);
			break;
		default:
			break;
	}
}
//End Store

//Print Validation
int PrintValidation(uchar ucPrnFlag, char *name)
{	
	uchar	ucNum;
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1];
	uchar	temp[100] = {0};

	ST_FONT font1,font2;
	font1.CharSet = CHARSET_WEST;
	font1.Width   = 8;
	font1.Height  = 24;
	font1.Bold    = 0;
	font1.Italic  = 0;
	font2.CharSet = CHARSET_WEST;
	font2.Width   = 12;
	font2.Height  = 24;
	font2.Bold    = 0;
	font2.Italic  = 0;

	
	PrnInit();
	memset(temp, 0, sizeof(temp));
	UtilGetEnvEx("rptshowlogo", temp);
	if(strstr(temp, "true") != NULL)
	{
		//PrnSetNormal();//For font size
		PrnCustomLogoReceipt_T();//For Logo
		PrnStep(10);//Set Space after printing logo
	}
	PrnSelectFont(&font2,NULL);
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("rptcclabel", temp);
	C(temp, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);

	//ShowLogs(1, "James Printing 4");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("bankname", temp);
	C(temp, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 5");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("merName", temp);
	C(temp, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 6");
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("merAddr", temp);
	C(temp, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 7");
	PrnStep(5);
	PrnStr("\n");
		
	//ShowLogs(1, "James Printing 9");
	memset(szBuff, 0, sizeof(szBuff));
	TC(name, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	//ShowLogs(1, "James Printing 10");
	PrnStep(5);
	MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
	//ShowLogs(1, "James Printing 11");
	PrnStep(5);
	MultiLngPrnReceiptStr(_T("TERMINAL:       "), GUI_ALIGN_LEFT);
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnvEx("tid", temp);
	sprintf(szBuff,"%15.8s\n", temp);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	PrnStr("\n");
	sprintf((char *)szBuff, "%s", _T("TIME:                  "));
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	ShowLogs(1, "Local Time: %s", glSendPack.szLocalTime);
	memset(szBuff, 0, sizeof(szBuff));
	ConvTime(glSendPack.szLocalTime, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);

	PrnStep(5);
	MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
	PrnStep(5);
	memset(temp, 0, sizeof(temp));
	if(strstr(glRecvPack.szRspCode, "00") != NULL)
	{
		strcpy(temp, "VALIDATION SUCCESSFUL");
	}else
	{
		strcpy(temp, "VALIDATION NOT SUCCESSFUL");
	}
	PubStrUpper(temp);
	memset(szBuff, 0, sizeof(szBuff));
	C(temp, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
	PrnStep(5);
	MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
	PrnStep(10);
	memset(szBuff, 0, sizeof(szBuff));
	MultiLngPrnReceiptStr(_T("RESPONSE CODE: "), GUI_ALIGN_LEFT);
	sprintf(szBuff,"%16.16s\n", glRecvPack.szRspCode);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	PrnStep(10);
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("rptfootertext", temp);
	C(temp, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	memset(temp, 0, sizeof(temp));
	memset(szBuff, 0, sizeof(szBuff));
	UtilGetEnv("rptfnlabel", temp);
	C(temp, szBuff);
	MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
	PrnStr("\n\n");
	MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
	PrnStr("\n\n\n\n\n\n\n\n");

	memset(temp, 0, sizeof(temp));
	UtilGetEnvEx("rptsbarcode", temp);
	if(strstr(temp, "true") != NULL)
	{
		//Print Barcode here
		PrnStep(10);//Set Space after printing logo
	}
	//ShowLogs(1, "James Printing 29");
	StartPrinterReceipt();
	return 0;
}

//recieptno|txntype|date|time|appname|expdate|maskedpan|holdername|aid|amount|cashback|total
//|paymentdetails|rspcode|authcode|stan|rrn

void reprintDataNormal(struct PRINTDATA *details)
{
	uchar	ucNum;
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1];
	uchar	temp[100] = {0};

	ST_FONT font1,font2;
	font1.CharSet = CHARSET_WEST;
	font1.Width   = 8;
	font1.Height  = 24;
	font1.Bold    = 0;
	font1.Italic  = 0;
	font2.CharSet = CHARSET_WEST;
	font2.Width   = 12;
	font2.Height  = 24;
	font2.Bold    = 0;
	font2.Italic  = 0;

	ShowLogs(1, "Printing");

	DispPrinting();

	for(ucNum=0; ucNum<2; ucNum++)
	{
		PrnInit();
		memset(temp, 0, sizeof(temp));
		UtilGetEnvEx("rptshowlogo", temp);
		if(strstr(temp, "true") != NULL)
		{
			PrnCustomLogoReceipt_T();//For Logo
			PrnStep(10);//Set Space after printing logo
		}
		PrnSelectFont(&font2,NULL);
		memset(temp, 0, sizeof(temp));
		C("DUPLICATE COPY", temp);
		MultiLngPrnReceiptStr(temp, GUI_ALIGN_LEFT);
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("bankname", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("merName", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnv("merAddr", temp);
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		PrnStep(5);
		PrnStr("\n");
		ShowLogs(1, "Confirm: %s", details->field0);
		MultiLngPrnReceiptStr(_T("RECEIPT NO:    "), GUI_ALIGN_LEFT);
		sprintf(szBuff,"%15.8s\n", details->field0);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		memset(szBuff, 0, sizeof(szBuff));
		TC(details->field1, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		PrnStep(5);
		MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
		PrnStep(5);
		MultiLngPrnReceiptStr(_T("TERMINAL:       "), GUI_ALIGN_LEFT);
		memset(temp, 0, sizeof(temp));
		memset(szBuff, 0, sizeof(szBuff));
		UtilGetEnvEx("tid", temp);
		sprintf(szBuff,"%15.8s\n", temp);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		sprintf((char *)szBuff, "%s", _T("DATE:              "));
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		memset(szBuff, 0, sizeof(szBuff));
		MultiLngPrnReceiptStr(details->field2, GUI_ALIGN_LEFT);
		PrnStr("\n");
		sprintf((char *)szBuff, "%s", _T("TIME:                  "));
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		memset(szBuff, 0, sizeof(szBuff));
		MultiLngPrnReceiptStr(details->field3, GUI_ALIGN_LEFT);
		PrnStr("\n");
		if(strncmp(details->field1, "PAYATTITUDE", 11) == 0)
		{
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%s", _T("PHONE NUMBER:       "));
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			sprintf(szBuff,"%s\n", details->field5);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			//MaskAllPan("9501000000000001", szBuff);
			MaskAllPan(glSendPack.szPan, szBuff);
			sprintf((char *)szBuf1, "PAN:    %23.23s", szBuff);
			MultiLngPrnReceiptStr(szBuf1,GUI_ALIGN_LEFT);
			PrnStr("\n");
		}else
		{
			memset(szBuf1, 0, sizeof(szBuf1));
			sprintf((char *)szBuf1, "CARD:              %.12s\n", details->field4);
			MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
			MultiLngPrnReceiptStr(details->field5, GUI_ALIGN_LEFT);
			PrnStr("\n");
			MultiLngPrnReceiptStr(details->field6, GUI_ALIGN_LEFT);
			PrnStr("\n");
			sprintf((char *)szBuff, "%s       ", _T("CLIENT:  "));
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%15.15s\n", details->field7);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuf1, 0, sizeof(szBuf1));
			sprintf((char *)szBuf1, "AID:             %.18s\n", details->field8);
			MultiLngPrnReceiptStr(szBuf1, GUI_ALIGN_LEFT);
		}
		
		if(strncmp(details->field1, "PAYATTITUDE", 11) == 0)
		{
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%s   %12.12s\n", _T("AMOUNT PAID:    "), details->field10);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}else if(strncmp(details->field1, "CASHBACK", 8) == 0)
		{
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%s   %12.12s\n", _T("AMOUNT PAID:    "), details->field9);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%s   %12.12s\n", _T("CASHBACK:       "), details->field10);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%s   %12.12s\n", _T("CHARGE:         "), "NGN 100.00");
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%s   %12.12s\n", _T("TOTAL AMOUNT:   "), details->field11);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}else
		{
			memset(szBuff, 0, sizeof(szBuff));
			sprintf((char *)szBuff, "%s   %12.12s\n", _T("AMOUNT PAID:    "), details->field9);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		PrnStep(5);
		MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
		PrnStep(5);
		memset(temp, 0, sizeof(temp));
		if(strncmp(details->field1, "PAYATTITUDE", 11) == 0)
		{
			getResponse(details->field13, temp);
		}else
		{
			getResponse(details->field12, temp);
		}
		PubStrUpper(temp);
		memset(szBuff, 0, sizeof(szBuff));
		C(temp, szBuff);
		MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_CENTER);
		PrnStep(5);
		MultiLngPrnReceiptStr("===============================\n", GUI_ALIGN_LEFT);
		PrnStep(10);
		if(strncmp(details->field1, "PAYATTITUDE", 11) == 0)
		{
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("RESPONSE CODE: "), GUI_ALIGN_LEFT);
			sprintf(szBuff,"%16.16s\n", details->field13);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("AUTHCODE:      "), GUI_ALIGN_LEFT);
			sprintf(szBuff,"%16.16s\n", details->field14);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("STAN:          "), GUI_ALIGN_LEFT);
			sprintf(szBuff,"%16.16s\n", details->field15);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("RRN:           "), GUI_ALIGN_LEFT);
			sprintf(szBuff,"%16.16s\n", details->field16);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}else
		{
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("RESPONSE CODE: "), GUI_ALIGN_LEFT);
			sprintf(szBuff,"%16.16s\n", details->field12);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("AUTHCODE:      "), GUI_ALIGN_LEFT);
			sprintf(szBuff,"%16.16s\n", details->field13);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("STAN:          "), GUI_ALIGN_LEFT);
			sprintf(szBuff,"%16.16s\n", details->field14);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(szBuff, 0, sizeof(szBuff));
			MultiLngPrnReceiptStr(_T("RRN:           "), GUI_ALIGN_LEFT);
			sprintf(szBuff,"%16.16s\n", details->field15);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		PrnStr("\n");
		if( ucNum==0 )
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfootertext", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfnlabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		else
		{
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfootertext", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			memset(temp, 0, sizeof(temp));
			memset(szBuff, 0, sizeof(szBuff));
			UtilGetEnv("rptfnlabel", temp);
			C(temp, szBuff);
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
		}
		//ShowLogs(1, "James Printing 28");
		if( ucNum==1)
		{
			//Comment back for mtip and advt
			/*
			PrnStr("\n\n");
			sprintf((char *)szBuff, "%s\n", _T("CARDHOLDER SIGNATURE"));
			MultiLngPrnReceiptStr(szBuff, GUI_ALIGN_LEFT);
			PrnStr("\n\n");
			PrnStr("-----------------------------\n");
			MultiLngPrnReceiptStr("I ACKNOWLEDGE SATISFACTORY RECEIPT \nOF RELATIVE  GOODS/SERVICE\n", GUI_ALIGN_LEFT);
			*/
		}
		PrnStr("\n\n");
		MultiLngPrnReceiptStr("...............................\n", GUI_ALIGN_LEFT);
		PrnStr("\n\n\n\n\n\n\n\n");

		memset(temp, 0, sizeof(temp));
		UtilGetEnvEx("rptsbarcode", temp);
		if(strstr(temp, "true") != NULL)
		{
			//Print Barcode here
			PrnStep(10);//Set Space after printing logo
		}
		//ShowLogs(1, "James Printing 29");
		if(!checkEcr)
		{
			StartPrinterReceipt();
			return;//For printing receipt twice

			if(txnType == 5)
    			return 0;

			if( ucNum==0)
			{
				if( memcmp(glProcInfo.stTranLog.szRspCode, "00", LEN_RSP_CODE) != 0 )
					return 0;
	            kbflush();
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PRESS ANY KEY"), gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, NULL);
			}
		}
	}
}