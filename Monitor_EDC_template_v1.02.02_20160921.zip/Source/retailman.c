#include "global.h"


#define TIMER_TEMPORARYRET		4
#define TIMERCNT_MAXRET		48000

uchar ChkIdleTimerRet(int iSeconds)
{
	int	iCnt = TIMERCNT_MAXRET-TimerCheck(TIMER_TEMPORARYRET);
	return (iCnt >= iSeconds*10);
}

void SetIdleTimerRet(void)
{
	TimerSet(TIMER_TEMPORARYRET, TIMERCNT_MAXRET);
}

void OpenPortRet() 
{
	if (ucRet2 != 0x00) 
	{
		//ucRet2 = PortOpen(0, (unsigned char *)"115200,8,n,1");
		ucRet2 = PortOpen(0, (unsigned char *)"115200,8,n,1");
	}
}

int OpenRxdRet(uchar *psRxdData, ushort uiExpLen, ushort *puiOutLen)
{
	uchar   ucRet;
	ushort	uiReadCnt, uiTemp;
	uchar	szEngTime[16+1];
	uiReadCnt = uiTemp = 0;
	char store_env[120] = {0};
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;

	kbflush();

	while( uiReadCnt<uiExpLen )
	{
		ucRet = PortRecv(0, psRxdData, uiTemp);
		if( ucRet==0x00 )
		{	
			uiTemp = 80;
			psRxdData++;
			uiReadCnt++;
		}
		else if( ucRet==0xFF )
		{
			if( uiReadCnt>0 )
			{
				break;
			}
		}
		else
		{	
			break;
		}

		GetEngTime(szEngTime);
		Gui_DrawText(szEngTime, stTextAttr, 12, 75);
		DelayMs(10);

		memset(store_env, '\0', strlen(store_env));
        UtilGetEnv("chinterval", store_env);
        if (ChkIdleTimerRet(atoi(store_env)))
        {
        	DisplayInfoNone("UNIFIED PAYMENTS", "PERFORMING CALLHOME", 2);
			PackCallHomeData();
        	Gui_ClearScr();
        	TransOther();
        }

        if (kbhit()==0) 
		{ 
			if(getkey()==KEYCANCEL)
			{
				cecr = 1;
				Beep();
				return 1;
			}
		}
	}

	if( puiOutLen!=NULL )
	{
		*puiOutLen = uiReadCnt;
	}
	return 0;
}

void getConvertedAmount(char *confee, char *str)
{
	switch(strlen(str))
	{
		case 0:
			strcpy(confee, "000000000000");
			break;
		case 1:
			strcpy(confee, "00000000000");
			strcat(confee, str);
			break;
		case 2:
			strcpy(confee, "0000000000");
			strcat(confee, str);
			break;
		case 3:
			strcpy(confee, "000000000");
			strcat(confee, str);
			break;
		case 4:
			strcpy(confee, "00000000");
			strcat(confee, str);
			break;
		case 5:
			strcpy(confee, "0000000");
			strcat(confee, str);
			break;
		case 6:
			strcpy(confee, "000000");
			strcat(confee, str);
			break;
		case 7:
			strcpy(confee, "00000");
			strcat(confee, str);
			break;
		case 8:
			strcpy(confee, "0000");
			strcat(confee, str);
			break;
		case 9:
			strcpy(confee, "000");
			strcat(confee, str);
			break;
		case 10:
			strcpy(confee, "00");
			strcat(confee, str);
			break;
		case 11:
			strcpy(confee, "0");
			strcat(confee, str);
			break;
		case 12:
			strcpy(confee, str);
			break;
		default:
			strcpy(confee, "000000000000");
			break;
	}
}

void getPlainAmount(char *init, char *fin)
{
    int i, j = 0;
    for(i = 0; i < strlen(init); i++)
    {
        if(init[i] == '.')
            continue;
        else
        {
            fin[j] = init[i];
            j++;
        }
    }
}

int parseRetData(char* data)
{
	char temp[128] = {0};
	char str[13] = {0};
    int i = 0, j;
    char *ret;
    memset(temp, '\0', strlen(temp));

    ret = strstr(data, "<TransactionType>");
    i = 17;
    j = 0;
    while(1)
    {
        if(ret[i] == '<')
            break;
        else
            temp[j] = ret[i];
        i++;
        j++;
    }
    strncpy(ecrModeData.sMsgType, temp, strlen(temp));
    //DisplayInfoNone("UNIFIED PAYMENTS", ecrModeData.sMsgType, 3);
    memset(temp, '\0', strlen(temp));
    ret = strstr(data, "<Amount>");
    i = 8;
    j = 0;
    while(1)
    {
        if(ret[i] == '<')
            break;
        else
            temp[j] = ret[i];
        i++;
        j++;
    }
    getPlainAmount(temp, str);
    getConvertedAmount(ecrModeData.sAmount, str);
	//DisplayInfoNone("UNIFIED PAYMENTS", ecrModeData.sAmount, 3);
    memset(temp, '\0', strlen(temp));
    ret = strstr(data, "<ReferenceNumber>");
    //DisplayInfoNone("UNIFIED PAYMENTS", "Checking 1", 3);
    i = 17;
    j = 0;
    for( ;i<strlen(ret); )
    {
        if(ret[i] == '<')
            break;
        else
            temp[j] = ret[i];
        i++;
        j++;
    }
    //DisplayInfoNone("UNIFIED PAYMENTS", "Checking 2", 3);
    strncpy(ecrModeData.sTxnRrn, temp, strlen(temp));
	//DisplayInfoNone("UNIFIED PAYMENTS", ecrModeData.sTxnRrn, 3);
	return atoi(ecrModeData.sMsgType);
}

int retPurchase()
{
	int iRet = 0, iMenuNo, iRev = 0;
	ST_EVENT_MSG stEventMsg;
	uchar key = 0;
	int chk = 0;
	char pin[25] = {0};
	GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
	char txnName1[20][128];
	int iTemp = 0;
	char temp[5] = {0};
	char sStore[100] = {0};
	uchar k;

	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	int i;

	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	
	numLines = 6;

	sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "CARD");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "CARD", strlen("CARD"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "PAYATTITUDE");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "PAYATTITUDE", strlen("PAYATTITUDE"));

	for(i = 0; i < 2; ++i)
    {
        if(stDefTranMenuItem1[i].bVisible)
        {
        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
            ++iMenuItemNum;
        }
    }

    stTranMenuItem[iMenuItemNum].szText[0] = 0;

	Gui_BindMenu("UNIFIED PAYMENTS", gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
	
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
	if(GUI_OK == iRet)
	{
		checkBoard = 0;
		if(strncmp(txnName1[iMenuNo], "CARD", 4) == 0)
		{
			setHostDetails("PAY ALL CARDS");
			TransPurchase();
		}else if(strncmp(txnName1[iMenuNo], "PAYATTITUDE", 11) == 0)
		{
			setHostDetails("PAYATTITUDE");
			payAttitude();
		}
		Gui_ClearScr();
		return iRet;
	}else if(GUI_ERR_USERCANCELLED == iRet || GUI_ERR_TIMEOUT == iRet)
		return 1;
	return 0;
}

void retailmanEntrance()
{
	int iRet = 0, iLen;
	uchar key;
	int step = 0;
	int chk = 0;
	char ecr[256] = {0};
	char send[1024] = {0};
	char temp[128] = {0};
	char tem[128] = {0};
	char sBuf[128] = {0};

	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	DisplayInfoNone("UNIFIED PAYMENTS", "ECR MODE", 0);
	memset(&ecrModeData, 0, sizeof(ECRISO));
	checkEcr = 0;
	DisplayLogsCheck = 0; //Turn off logs
	txnType = 13;
	
	restart:
	OpenPortRet();
	SetIdleTimerRet();//For timer
	memset(ecr, '\0', strlen(ecr));
	iRet = OpenRxdRet(ecr, 250, &iLen);
	Beep();
	if(cecr)
	{
		ucRet2 = 0x03;
		PortClose(0);
	}else
	{
		ucRet2 = 0x03;
		PortClose(0);

		if(step == 0) 
		{
			Beep();
			OpenPortRet();
			PortSends(0, (unsigned char *)"\x6\r", strlen("\x6\r"));
			ucRet2 = 0x03; 
			PortClose(0);
			step = 1;
			goto restart;			
		}else
		{
			ScrBackLight(1);
			Beep();
			step = 0;
			iRet = parseRetData(ecr);
			if(iRet == 1)
			{
				//For Purchase
				checkEcr = 1;
				memset(send, '\0', strlen(send));
				DisplayInfoNone("UNIFIED PAYMENTS", "PROCESSING REQUEST", 1);
				if(retPurchase() == 1)
				{
					//User canceled
					strcpy(send, "\x3\r<?xml version=\"1.0\"?><Response><MaskedPan>");
					if(strlen(glSendPack.szFwdInstId))
					{
						strcat(send, glSendPack.szFwdInstId);
					}
					else
					{
						memset(sBuf, '\0', strlen(sBuf));
						MaskAllPan(glSendPack.szPan, sBuf);
						strcat(send, sBuf);
					}
					strcat(send, "</MaskedPan><ResponseCode>");
					if(strlen(glRecvPack.szRspCode))
						strcat(send, glRecvPack.szRspCode);
					else
						strcat(send, "99");
					strcat(send, "</ResponseCode><AuthorizationCode>");
					strcat(send, glProcInfo.stTranLog.szAuthCode);
					strcat(send, "</AuthorizationCode><RetrievalReferenceNumber>");
					strcat(send, glRecvPack.szRRN);
					strcat(send, "<RetrievalReferenceNumber></Response>\r");
				}else
				{
					if(revFlag)
					{
						//From key exchange
						strcpy(send, "\x3\r<?xml version=\"1.0\"?><Response><MaskedPan>");
						if(strlen(glSendPack.szFwdInstId))
						{
							strcat(send, glSendPack.szFwdInstId);
						}
						else
						{
							memset(sBuf, '\0', strlen(sBuf));
							MaskAllPan(glSendPack.szPan, sBuf);
							strcat(send, sBuf);
						}
						strcat(send, "</MaskedPan><ResponseCode>");
						if(strlen(glRecvPack.szRspCode))
							strcat(send, glRecvPack.szRspCode);
						else
							strcat(send, "06");
						strcat(send, "</ResponseCode><AuthorizationCode>");
						strcat(send, glProcInfo.stTranLog.szAuthCode);
						strcat(send, "</AuthorizationCode><RetrievalReferenceNumber>");
						strcat(send, glRecvPack.szRRN);
						strcat(send, "<RetrievalReferenceNumber></Response>\r");
					}else
					{
						//Response came
						strcpy(send, "\x3\r<?xml version=\"1.0\"?><Response><MaskedPan>");
						if(strlen(glSendPack.szFwdInstId))
						{
							strcat(send, glSendPack.szFwdInstId);
						}
						else
						{
							memset(sBuf, '\0', strlen(sBuf));
							MaskAllPan(glSendPack.szPan, sBuf);
							strcat(send, sBuf);
						}
						strcat(send, "</MaskedPan><ResponseCode>");
						if(strlen(glRecvPack.szRspCode))
							strcat(send, glRecvPack.szRspCode);
						else
							strcat(send, "06");
						strcat(send, "</ResponseCode><AuthorizationCode>");
						strcat(send, glProcInfo.stTranLog.szAuthCode);
						strcat(send, "</AuthorizationCode><RetrievalReferenceNumber>");
						strcat(send, glRecvPack.szRRN);
						strcat(send, "<RetrievalReferenceNumber></Response>\r");
					}
				}
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING BACK RESPONSE", 1);
				Beep();
				OpenPortRet();
				PortSends(0, (unsigned char *)send, strlen(send));
				ucRet2 = 0x03;
				PortClose(0);

				DelayMs(1000);
				//step = 1;
				//goto restart;
				retailmanEntrance();
			}
		}
	}	
}