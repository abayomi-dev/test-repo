
#ifndef _MAGSTRIPE_H
#define _MAGSTRIPE_H


#ifdef __cplusplus
extern "C" {
#endif 

int magneticStripe(void);
extern int magflag;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
