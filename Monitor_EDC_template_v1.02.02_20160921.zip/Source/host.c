#include "global.h"
int checkAutoHost = 0;
void switchAutomaticHost()
{
	char temp[128] = {0};
	char lasthost[128] = {0};
	char time[128] = {0};
	ShowLogs(1, "Host Switching Check: %d", switchHostManual);
	if(switchHostManual == 2)
	{
		checkAutoHost = 1;
		memset(time, '\0', strlen(time));
		GetEngTime(time);
		ShowLogs(1, "Time For Switching: %s", time);
		UtilPutEnv("tmHst", time);
		memset(lasthost, '\0', strlen(lasthost));
		UtilGetEnvEx("lhost", lasthost);
		if(strstr(lasthost, "host2") != NULL)
    	{
    		ShowLogs(1, "Switching to host 1");
    		memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostname", temp);
			UtilPutEnv("uhostname", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostip", temp);
			UtilPutEnv("uhostip", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostport", temp);
			UtilPutEnv("uhostport", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostssl", temp);
			UtilPutEnv("uhostssl", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostfname", temp);
			UtilPutEnv("uhostfname", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostmestype", temp);
			ShowLogs(1, "Message type: %s", temp);
			UtilPutEnv("uhostmestype", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostremarks", temp);
			UtilPutEnv("uhostremarks", temp);
			UtilPutEnv("lhost", "host1");
			memset(temp, '\0', strlen(temp));
			ReadAllData("hosa.txt", temp);
			ShowLogs(1, "1. Setting CTMK TO HOST 1: %s", temp);
			UtilPutEnv("proCtmk", temp);
    	}else
    	{
    		ShowLogs(1, "Switching to host 2");
    		memset(temp, '\0', strlen(temp));
			UtilGetEnv("host2name", temp);
			UtilPutEnv("uhostname", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("host2ip", temp);
			UtilPutEnv("uhostip", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("host2port", temp);
			UtilPutEnv("uhostport", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("host2ssl", temp);
			UtilPutEnv("uhostssl", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("host2fname", temp);
			UtilPutEnv("uhostfname", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("host2mestype", temp);
			ShowLogs(1, "Message type: %s", temp);
			UtilPutEnv("uhostmestype", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("host2remarks", temp);
			UtilPutEnv("uhostremarks", temp);
			UtilPutEnv("lhost", "host2");
			memset(temp, '\0', strlen(temp));
			ReadAllData("hosb.txt", temp);
			ShowLogs(1, "2. Setting CTMK TO HOST 2: %s", temp);
			UtilPutEnv("proCtmk", temp);
    	}
    	DisplayInfoNone("UNIFIED PAYMENTS", "SWITCHING HOST\nSUCCESSFUL", 2);
		Beep();
	}
}

void parseChar(char *time, char *hr, char *min)
{
    int len, i, j = 0, k = 0, loop = 0;
    len = strlen(time);
    i = len - 5;
    hr[0] = time[i];
    hr[1] = time[i + 1];
    min[0] = time[i + 3];
    min[1] = time[i + 4];
}

struct TIME
{
  int seconds;
  int minutes;
  int hours;
};

void differenceBetweenTimePeriod(struct TIME start, struct TIME stop, struct TIME *diff)
{
    if(stop.seconds > start.seconds){
        --start.minutes;
        start.seconds += 60;
    }
    diff->seconds = start.seconds - stop.seconds;
    if(stop.minutes > start.minutes){
        --start.hours;
        start.minutes += 60;
    }
    diff->minutes = start.minutes - stop.minutes;
    diff->hours = start.hours - stop.hours;
}

void returnAutomaticHostSwitch()
{
	char temp[128] = {0};
	char lasthost[128] = {0};
	char time[128] = {0};
	{
		memset(lasthost, '\0', strlen(lasthost));
		UtilGetEnvEx("lhost", lasthost);
		if(strstr(lasthost, "host2") != NULL)
    	{
    		ShowLogs(1, "Switching to priority host");
    		memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostname", temp);
			UtilPutEnv("uhostname", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostip", temp);
			UtilPutEnv("uhostip", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostport", temp);
			UtilPutEnv("uhostport", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostssl", temp);
			UtilPutEnv("uhostssl", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostfname", temp);
			UtilPutEnv("uhostfname", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostmestype", temp);
			ShowLogs(1, "Message type: %s", temp);
			UtilPutEnv("uhostmestype", temp);
			memset(temp, '\0', strlen(temp));
			UtilGetEnv("hostremarks", temp);
			UtilPutEnv("uhostremarks", temp);
			UtilPutEnv("lhost", "host1");
			memset(temp, '\0', strlen(temp));
			ReadAllData("hosa.txt", temp);
			ShowLogs(1, "1. Setting CTMK TO PRIORITY: %s", temp);
			UtilPutEnv("proCtmk", temp);
	    	DisplayInfoNone("UNIFIED PAYMENTS", "SWITCHING HOST\nSUCCESSFUL", 2);
			Beep();
		}
	}
}

void checkifAutoHost()
{
	char time[128] = {0};
	char ctime[128] = {0};
	struct TIME startTime, stopTime, diff;
    char hr[128] = {0};
    char min[128] = {0};
    char temp[128] = {0};

    memset(temp, '\0', strlen(temp));
    UtilGetEnvEx("tmHst", temp);
    ShowLogs(1, "Initial Time For Switching: %s", temp);
    parseChar(temp, hr, min);

    startTime.hours = atoi(hr);
    startTime.minutes = atoi(min);
    startTime.seconds = atoi("00");

    memset(hr, '\0', strlen(hr));
    memset(min, '\0', strlen(min));
    memset(ctime, '\0', strlen(ctime));
	GetEngTime(ctime);
	ShowLogs(1, "Current Time For Comparing: %s", ctime);
    parseChar(ctime, hr, min);
    stopTime.hours = atoi(hr);
    stopTime.minutes = atoi(min);
    stopTime.seconds = atoi("00");

	if(checkAutoHost)
	{
		differenceBetweenTimePeriod(stopTime, startTime, &diff);
		ShowLogs(1, "%d:%d:%d\n", diff.hours, diff.minutes, diff.seconds);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("host2remarks", temp);
		ShowLogs(1, "Host 2 fallback time: %s - Mins: %d", temp, diff.minutes);
		if(diff.minutes >= atoi(temp))
		{
			switchHostManual = 0;
			checkAutoHost = 0;
			returnAutomaticHostSwitch();
		}
	}
}