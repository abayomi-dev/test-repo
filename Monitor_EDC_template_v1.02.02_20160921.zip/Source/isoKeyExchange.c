#include "global.h"

DL_ISO8583_HANDLER isoHandler;
DL_ISO8583_MSG     isoMsg;
//DL_UINT8           packBuf[5 * 1024];
DL_UINT16          packedSize;

#define MASTERKEYINDEX 1
#define PINKEYINDEX 2
int revSend = 0;
int switchHostManual = 0;

void HexEnCodeMethod2(unsigned char *psIn, unsigned int uiLength, unsigned char *psOut) 
{
	static const unsigned char ucHexToChar[17] = { "0123456789ABCDEF" };
	unsigned int uiCnt;
	if ((psIn == NULL) || (psOut == NULL)) {
		return;
	}

	for (uiCnt = 0; uiCnt < uiLength; uiCnt++) {
		psOut[2 * uiCnt] = ucHexToChar[(psIn[uiCnt] >> 4)];
		psOut[2 * uiCnt + 1] = ucHexToChar[(psIn[uiCnt] & 0x0F)];
	}
}

void HexEnCodeMethod(char *psIn, unsigned int uiLength, char *pszOut) {
	HexEnCodeMethod2(psIn, uiLength, pszOut);
	pszOut[2 * uiLength] = 0;
}

int hexDecode(char *theHexStr, char *theBinBuffer, int theBufferLen, int *copiedLen) 
{
	*copiedLen = strlen(theHexStr) / 2;
	HexDecodeMethod2(theHexStr, *copiedLen * 2, theBinBuffer, theBufferLen);
	return 1;
}

int DecryptDES2ECBMode(char* theEncMsg, int theEncMsgLen,
		char* theUpperCaseHexKey32Len, char *theDecMsg, int theDecMsgLen) 
{
	char *TempKey = NULL;
	int iLen, i;
	memset(theDecMsg, 0x0, theDecMsgLen);
	TempKey = (char*)sysalloc_calloc(strlen(theUpperCaseHexKey32Len), sizeof(char));

	if (!TempKey) {
		sysalloc_free(TempKey);
		TempKey = NULL;
		return 0;
	}

	PubAsc2Bcd(theUpperCaseHexKey32Len, 32, TempKey);

	for (iLen = theEncMsgLen, i = 0; iLen > 0; iLen -= 8, i++) {
		PubDes(TRI_DECRYPT, theEncMsg + i * 8, TempKey, theDecMsg + i * 8);
	}
	sysalloc_free(TempKey);
	TempKey = NULL;
	return 1;
}

void DecryptDes2Hex(char *theEnc, char *theClkey, char *mskey)
{
	char decOutPut[1024] = { 0 };
	char temp[1024] = { 0 };
	int copiedLen;
	memset(temp, 0x0, sizeof(temp));
	hexDecode((char*)theEnc, temp, sizeof(temp), &copiedLen);
	memset(decOutPut, 0x0, sizeof(decOutPut));
	DecryptDES2ECBMode(temp, copiedLen, (char*)theClkey, decOutPut, sizeof(decOutPut));
	memset(temp, 0x0, sizeof(temp));
	HexEnCodeMethod((unsigned char*) decOutPut, 16, (unsigned char*) temp);
	strcpy(mskey, temp);
}

int EncodeDES2ECBMode(char* theInputData, int theInputDataLen, char* theUpperCaseHexKey32Len, char* theEncCipher, int theEncCipherBuLen) 
{
	unsigned char TempKey[32];
	unsigned char TempCipher[2048] = { 0 };
	int iLen, i;
	memset(TempCipher, 0x0, sizeof(TempCipher));
	if (!theUpperCaseHexKey32Len || !*theUpperCaseHexKey32Len || (theEncCipherBuLen < theInputDataLen)) 
	{
		return 0;
	}

	PubAsc2Bcd((unsigned char*) theUpperCaseHexKey32Len, strlen(theUpperCaseHexKey32Len), TempKey);

	for (iLen = theInputDataLen, i = 0; iLen > 0; iLen -= 8, i++) {
		PubDes(TRI_ENCRYPT, (unsigned char*) theInputData + i * 8, TempKey,
				(unsigned char*) theEncCipher + i * 8);
	}
	return 0;
}

void CalcChk(char *csk) 
{
	char outPut[1024] = { 0 };
	char hexoutput[1024] = { 0 };
	char rethexoutput[18];
	int datalen;
	char input[100];
	char tempKey[100] = { '\0' };
	char tempOut[100] = { '\0' };
	memset(input, 0x0, sizeof(input));
	memset(outPut, 0x0, sizeof(outPut));
	memset(hexoutput, 0x0, sizeof(hexoutput));
	strcpy(input, "0000000000000000");
	HexDecodeMethod((unsigned char*) input, 16, (unsigned char*) tempOut);
	EncodeDES2ECBMode(tempOut, 8, (char*) csk, outPut, sizeof(outPut));
	memset(hexoutput, 0x0, sizeof(hexoutput));
	HexEnCodeMethod((unsigned char*) outPut, 16, (unsigned char*) hexoutput);
	memset(rethexoutput, 0x0, sizeof(rethexoutput));
	strncpy(rethexoutput, hexoutput, 16);
}


int InjectMasterSessionKey(char *masterKey, char *pinKey, int keyLen) {
	ST_KEY_INFO keyInfo = {0};
	ST_KCV_INFO kcvInfo = {0};

	//inject masterkey
	keyInfo.ucSrcKeyType = -1;
	keyInfo.ucSrcKeyIdx = 0;
	keyInfo.ucDstKeyType = PED_TMK;
	keyInfo.ucDstKeyIdx = MASTERKEYINDEX;
	keyInfo.iDstKeyLen = 16;
	memcpy(keyInfo.aucDstKeyValue, masterKey, 16);

	kcvInfo.iCheckMode = 0;

	int ret;
	ret = PedWriteKey(&keyInfo, &kcvInfo);

	if(ret != PED_RET_OK){
		ShowLogs(1, "Masterkey injection failed. Returned %i", ret);
		Beep();
		DisplayInfoNone("ERROR", "PINKEY INJECTION", 0);
		return 0;
	}

	//inject pinKey
	keyInfo.ucSrcKeyType = PED_TMK;
	keyInfo.ucSrcKeyIdx = MASTERKEYINDEX;
	keyInfo.ucDstKeyType = PED_TPK;
	keyInfo.ucDstKeyIdx = PINKEYINDEX;
	keyInfo.iDstKeyLen = 16;
	memcpy(keyInfo.aucDstKeyValue, pinKey, 16);

	kcvInfo.iCheckMode = 0;

	ret = PedWriteKey(&keyInfo, &kcvInfo);

	ShowLogs(1, "Response from injecting pinkey into Pinpad: %i", ret);
	
	return ret == PED_RET_OK;
}


int InjectMSKey(char *theClkey, char *theEnc) 
{
	char masterKey[32] = { 0 }, sessionKey[32] = { 0 };
	HexDecodeMethod((unsigned char*) theEnc, strlen(theEnc), (unsigned char*) sessionKey);
	HexDecodeMethod((unsigned char*) theClkey, strlen(theClkey), (unsigned char*)masterKey);
	return InjectMasterSessionKey(masterKey, sessionKey, strlen(theEnc) / 2);
}

int GetMasterKey()
{
	char hexData[5 * 1024] = { 0 };
	char output[5 * 1024] = { 0 };
	DL_UINT8 	packBuf[5 * 1024] = { 0x0 };
	/* get ISO-8583 1987 handler */
	DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	char dt[5] = {0};
	char tm[7] = {0};
	int iRet, iLen = 0;
	char temp[128] = {0};
	char keyStore[128] = {0};
	char keyFin[33] = {0};
	char tempStore[128] = {0};
	char resp[3] = {0};
	char stan[7] = {0};

	memset(packBuf, 0x0, sizeof(packBuf));

	SysGetTimeIso(timeGotten);
	strncpy(datetime, timeGotten + 2, 10);
	strncpy(dt, timeGotten + 2, 4);
	strncpy(tm, timeGotten + 6, 6);

	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);

	/* set ISO message fields */
	(void)DL_ISO8583_MSG_SetField_Str(0, "0800", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(3, "9A0000", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(7, datetime, &isoMsg);
	sprintf((char *)stan, "%06lu", useStan);
	(void)DL_ISO8583_MSG_SetField_Str(11, stan, &isoMsg);
	GetStan();
	(void)DL_ISO8583_MSG_SetField_Str(12, tm, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(13, dt, &isoMsg);
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("tid", temp);
	(void)DL_ISO8583_MSG_SetField_Str(41, temp, &isoMsg);

	/* output ISO message content */
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);

	/* pack ISO message */
	(void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
		
	HexEnCodeMethod((DL_UINT8*)packBuf, packedSize + 2, hexData);
	//ShowLogs(1, "Iso Message Without Length: %s", hexData);
	packBuf[0] = packedSize >> 8;
	packBuf[1] = packedSize;
	HexEnCodeMethod((DL_UINT8*)packBuf, packedSize + 2, hexData);
	//ShowLogs(1, "Iso Message With Length: %s", hexData);
	
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);

	//For Gprs
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("cotype", temp);
	if(strstr(temp, "GPRS") != NULL)
 	{
 		glSysParam.stTxnCommCfg.ucCommType = 5;
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("coapn", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("cosubnet", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("copwd", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}
	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return 0;
			}
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return 0;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return 0;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return 0;
			}
			CommOnHook(TRUE);
 		}
 	}else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
 	ScrBackLight(1);
	//Start here
 	memset(hexData, '\0', strlen(hexData));
	//HexEnCodeMethod(output, strlen(output) + 2, hexData);
	unsigned char ucByte = 0;
	ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
	//HexEnCodeMethod(output, ucByte, hexData);
	//ShowLogs(1, "Response: %s\n", hexData);
	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	(void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
	//How to read data
	int i = 53;
	if ( NULL != isoMsg.field[i].ptr ) 
	{
		DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(39, &isoHandler);
		sprintf(resp, "%s", isoMsg.field[39].ptr);
		ShowLogs(1, "Response Code: %s", resp);
		if(strstr(resp, "00") != NULL)
		{
			DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
			//ShowLogs(1, "Field %03i, %s%s\n",(int)i, isoMsg.field[i].ptr, "");
			sprintf(keyStore, "%s", isoMsg.field[i].ptr);
			memset(temp, '\0', strlen(temp)); 
			UtilGetEnvEx("proCtmk", temp);
			ShowLogs(1, "Transport Key: %s", temp);
			memset(keyFin, '\0', strlen(keyFin)); 
			strncpy(keyFin, keyStore, 32);
			ShowLogs(1, "Encrypted MasterKey: %s", keyFin);
			memset(tempStore, '\0', strlen(tempStore)); 
			DecryptDes2Hex(keyFin, temp, tempStore);
			ShowLogs(1, "Clear Master Key: %s", tempStore);
			CreateWrite("isomastkey.txt", tempStore);
			return 1;
		}
		return 0;
	}else
		//printf("Field %d is not present in ISO\n", i);
		ShowLogs(1, "Field %d is not present in ISO\n", i);
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);
	return 0;
}

int GetSessionKey()
{
	char hexData[5 * 1024] = { 0 };
	char output[5 * 1024] = { 0 };
	DL_UINT8 	packBuf[5 * 1024] = { 0x0 };
	/* get ISO-8583 1987 handler */
	DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	char dt[5] = {0};
	char tm[7] = {0};
	int iRet, iLen = 0;
	char temp[128] = {0};
	char keyStore[128] = {0};
	char keyFin[33] = {0};
	char tempStore[128] = {0};
	char resp[3] = {0};
	char stan[7] = {0};

	memset(packBuf, 0x0, sizeof(packBuf));
	SysGetTimeIso(timeGotten);
	strncpy(datetime, timeGotten + 2, 10);
	strncpy(dt, timeGotten + 2, 4);
	strncpy(tm, timeGotten + 6, 6);

	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);

	/* set ISO message fields */
	(void)DL_ISO8583_MSG_SetField_Str(0, "0800", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(3, "9B0000", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(7, datetime, &isoMsg);
	sprintf((char *)stan, "%06lu", useStan);  //??
	(void)DL_ISO8583_MSG_SetField_Str(11, stan, &isoMsg);
	GetStan();
	(void)DL_ISO8583_MSG_SetField_Str(12, tm, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(13, dt, &isoMsg);
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("tid", temp);
	(void)DL_ISO8583_MSG_SetField_Str(41, temp, &isoMsg);
	/* output ISO message content */
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);

	/* pack ISO message */
	(void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
		
	HexEnCodeMethod((DL_UINT8*)packBuf, packedSize + 2, hexData);
	//ShowLogs(1, "Iso Message Without Length: %s", hexData);
	packBuf[0] = packedSize >> 8;
	packBuf[1] = packedSize;
	HexEnCodeMethod((DL_UINT8*)packBuf, packedSize + 2, hexData);
	//ShowLogs(1, "Iso Message With Length: %s", hexData);
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);
	//For Gprs
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("cotype", temp);
	if(strstr(temp, "GPRS") != NULL)
 	{
 		glSysParam.stTxnCommCfg.ucCommType = 5;
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("coapn", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("cosubnet", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("copwd", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}
	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return 0;
			}
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return 0;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return 0;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return 0;
			}
			CommOnHook(TRUE);
 		}
 	}else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
 	ScrBackLight(1);
	//Start here
 	memset(hexData, '\0', strlen(hexData));
	//HexEnCodeMethod(output, strlen(output) + 2, hexData);
	unsigned char ucByte = 0;
	ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
	//HexEnCodeMethod(output, ucByte, hexData);
	//ShowLogs(1, "Response: %s\n", hexData);
	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	(void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
	//How to read data
	int i = 53;
	if ( NULL != isoMsg.field[i].ptr ) 
	{
		DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(39, &isoHandler);
		sprintf(resp, "%s", isoMsg.field[39].ptr);
		ShowLogs(1, "Response Code: %s", resp);
		if(strstr(resp, "00") != NULL)
		{
			DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
			//ShowLogs(1, "Field %03i, %s%s\n",(int)i, isoMsg.field[i].ptr, "");
			sprintf(keyStore, "%s", isoMsg.field[i].ptr);
			memset(temp, '\0', strlen(temp));
			ReadAllData("isomastkey.txt", temp);
			ShowLogs(1, "Clear Masterkey: %s", temp);
			memset(keyFin, '\0', strlen(keyFin)); 
			strncpy(keyFin, keyStore, 32);
			ShowLogs(1, "Encrypted Sessionkey: %s", keyFin);
			memset(tempStore, '\0', strlen(tempStore)); 
			DecryptDes2Hex(keyFin, temp, tempStore);
			ShowLogs(1, "Clear Sessionkey: %s", tempStore);
			CreateWrite("isosesskey.txt", tempStore);
			CalcChk(tempStore);
			return 1;
		}
		return 0;
	}else
		//printf("Field %d is not present in ISO\n", i);
		ShowLogs(1, "Field %d is not present in ISO\n", i);
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);
	return 0;
}

int GetPinKey()
{
	char hexData[5 * 1024] = { 0 };
	char output[5 * 1024] = { 0 };
	DL_UINT8 	packBuf[5 * 1024] = { 0x0 };
	/* get ISO-8583 1987 handler */
	DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	char dt[5] = {0};
	char tm[7] = {0};
	int iRet, iLen = 0;
	char temp[128] = {0};
	char keyStore[128] = {0};
	char keyFin[33] = {0};
	char tempStore[128] = {0};
	char resp[3] = {0};
	char stan[7] = {0};

	memset(packBuf, 0x0, sizeof(packBuf));
	SysGetTimeIso(timeGotten);
	strncpy(datetime, timeGotten + 2, 10);
	strncpy(dt, timeGotten + 2, 4);
	strncpy(tm, timeGotten + 6, 6);
	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	/* set ISO message fields */
	(void)DL_ISO8583_MSG_SetField_Str(0, "0800", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(3, "9G0000", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(7, datetime, &isoMsg);
	sprintf((char *)stan, "%06lu", useStan);  //??
	(void)DL_ISO8583_MSG_SetField_Str(11, stan, &isoMsg);
	GetStan();
	(void)DL_ISO8583_MSG_SetField_Str(12, tm, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(13, dt, &isoMsg);
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("tid", temp);
	(void)DL_ISO8583_MSG_SetField_Str(41, temp, &isoMsg);

	/* output ISO message content */
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);

	/* pack ISO message */
	(void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
		
	HexEnCodeMethod((DL_UINT8*)packBuf, packedSize + 2, hexData);
	//ShowLogs(1, "Iso Message Without Length: %s", hexData);
	packBuf[0] = packedSize >> 8;
	packBuf[1] = packedSize;
	HexEnCodeMethod((DL_UINT8*)packBuf, packedSize + 2, hexData);
	//ShowLogs(1, "Iso Message With Length: %s", hexData);
	
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);

	//For Gprs
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("cotype", temp);
	if(strstr(temp, "GPRS") != NULL)
 	{
 		glSysParam.stTxnCommCfg.ucCommType = 5;
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("coapn", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("cosubnet", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("copwd", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}
	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return 0;
			}
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return 0;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return 0;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return 0;
			}
			CommOnHook(TRUE);
 		}
 	}else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
 	ScrBackLight(1);
	//Start here
 	memset(hexData, '\0', strlen(hexData));
	//HexEnCodeMethod(output, strlen(output) + 2, hexData);
	unsigned char ucByte = 0;
	ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
	//HexEnCodeMethod(output, ucByte, hexData);
	//ShowLogs(1, "Response: %s\n", hexData);
	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	(void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
	//How to read data
	int i = 53;
	if ( NULL != isoMsg.field[i].ptr ) 
	{
		DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(39, &isoHandler);
		sprintf(resp, "%s", isoMsg.field[39].ptr);
		ShowLogs(1, "Response Code: %s", resp);
		if(strstr(resp, "00") != NULL)
		{
			DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
			//ShowLogs(1, "Field %03i, %s%s\n",(int)i, isoMsg.field[i].ptr, "");
			sprintf(keyStore, "%s", isoMsg.field[i].ptr);
			memset(keyFin, '\0', strlen(keyFin)); 
			strncpy(keyFin, keyStore, 32);
			ShowLogs(1, "Encrypted Pinkey: %s", keyFin);
			memset(temp, '\0', strlen(temp));
			ReadAllData("isomastkey.txt", temp);
			ShowLogs(1, "Clear Masterkey: %s", temp);
			InjectMSKey(temp, keyFin);
			memset(keyFin, '\0', strlen(keyFin)); 
			strncpy(keyFin, keyStore, 32);
			memset(temp, '\0', strlen(temp));
			ReadAllData("isomastkey.txt", temp);
			memset(tempStore, '\0', strlen(tempStore)); 
			DecryptDes2Hex(keyFin, temp, tempStore);
			ShowLogs(1, "Clear Pin Key: %s", tempStore);
			CreateWrite("isopinkey.txt", tempStore);
			return 1;
		}
		return 0;
	}else
		//printf("Field %d is not present in ISO\n", i);
		ShowLogs(1, "Field %d is not present in ISO\n", i);
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);
	return 0;
}

int parseParametersOld(char *data)
{
	int iLen = 0;
	int i;
	int loop = 0, j = 0, k = 0, len = 0, p = 0;
	char temp[50] = {0};
	char tempStore[50] = {0};
	char store[50] = {0};
	iLen = strlen(data);
	for(i = 0; i < iLen; i++)
	{
		if(loop == 0)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				//UtilPutEnv("txnTime", store);
			}
		}
		else if(loop == 1)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnMid", store);
			}
		}else if(loop == 2)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnTimeOut", store);
			}
		}else if(loop == 3)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnCurCode", store);
			}
		}else if(loop == 4)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnConCode", store);
			}
		}else if(loop == 5)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnTimeOut", store);
			}
		}else if(loop == 6)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnMNL", store);
			}
		}else if(loop == 7)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnMCC", store);
			}
		}else
            break;
	}
	//DisplayInfoNone("SUCCESS", "Parameter Loaded", 0);
	return 1;
}

int parseParameters(char *data)
{
	int iLen = 0;
	int i;
	int loop = 0, j = 0, k = 0, len = 0, p = 0;
	char temp[50] = {0};
	char tempStore[50] = {0};
	char store[50] = {0};
	iLen = strlen(data);
	for(i = 0; i < iLen; i++)
	{
		if(loop == 0)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnTime", store);
			}
		}
		else if(loop == 1)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnMid", store);
			}
		}else if(loop == 2)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnTimeOut", store);
			}
		}else if(loop == 3)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnCurCode", store);
			}
		}else if(loop == 4)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnConCode", store);
			}
		}else if(loop == 5)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnTimeOut", store);
			}
		}else if(loop == 6)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnMNL", store);
			}
		}else if(loop == 7)
		{
			if(j < 2)
			{
				j++;
				memset(temp, '\0', strlen(temp));
				p = 0;
			}else if((j >= 2) && (j < 6))
			{
				temp[p] = data[i];
				p++;
				j++;
			}else
			{
				int m = 0;
				memset(tempStore, '\0', strlen(tempStore));
				if(temp[0] == '0' && temp[1] == '0')
					strncpy(tempStore, temp + 2, 1);
				else if(temp[0] == '0')
					strncpy(tempStore, temp + 1, 2);
				else
					strcpy(tempStore, temp);
				len = atoi(tempStore);
				j = 0;
				loop++;
				m = i - 1;
				memset(store, '\0', strlen(store));
				strncpy(store, data + m, len);
				i = i + len - 2;
				UtilPutEnv("txnMCC", store);
			}
		}else
            break;
	}
	DisplayInfoNone("SUCCESS", "PARAMETER LOADED", 0);
	return 1;
}

int GetParaMeters()
{
	char hexData[5 * 1024] = { 0 };
	char output[5 * 1024] = { 0 };
	DL_UINT8 	packBuf[5 * 1024] = { 0x0 };
	/* get ISO-8583 1987 handler */
	DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	char dt[5] = {0};
	char tm[7] = {0};
	int iRet, iLen = 0;
	char temp[128] = {0};
	char keyStore[128] = {0};
	char keyFin[33] = {0};
	char tempStore[128] = {0};
	char resp[3] = {0};
	char SN[33] = {0};
	char theUHI[33] = {0};
	char theUHISend[33] = {0};
	context_sha256_t ctx;
	char tempOut[100] = { '\0' };
	char boutHash[100] = { 0x0 };
	char outHash[100] = { 0x0 };
	char stan[7] = {0};

	memset(packBuf, 0x0, sizeof(packBuf));

	SysGetTimeIso(timeGotten);
	strncpy(datetime, timeGotten + 2, 10);
	strncpy(dt, timeGotten + 2, 4);
	strncpy(tm, timeGotten + 6, 6);

	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);

	/* set ISO message fields */
	(void)DL_ISO8583_MSG_SetField_Str(0, "0800", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(3, "9C0000", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(7, datetime, &isoMsg);
	sprintf((char *)stan, "%06lu", useStan);  
	(void)DL_ISO8583_MSG_SetField_Str(11, stan, &isoMsg);
	GetStan();
	(void)DL_ISO8583_MSG_SetField_Str(12, tm, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(13, dt, &isoMsg);
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("tid", temp);
	(void)DL_ISO8583_MSG_SetField_Str(41, temp, &isoMsg);
	memset(SN, '\0', strlen(SN)); 
	ReadSN(SN);
	if ('\0' == SN[0]) {
		//No serial
		strcpy(theUHI, "000000009");
	}
	strcpy(theUHI, SN);
	sprintf(theUHISend, "01%03d%s", strlen(theUHI), theUHI);
	(void)DL_ISO8583_MSG_SetField_Str(62, theUHISend, &isoMsg);
	(void) DL_ISO8583_MSG_SetField_Str(64, 0x0, &isoMsg);
	
	sha256_starts(&ctx);
	(void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, packBuf, &packedSize);
	HexEnCodeMethod((DL_UINT8*) packBuf, packedSize, hexData);
	ShowLogs(1, "Packed size %d", packedSize);

	if (packedSize >= 64) 
	{
		packBuf[packedSize - 64] = '\0';
		ShowLogs(1, "Packed ISO before hashing : %s", packBuf);
		memset(temp, '\0', strlen(temp));
		ReadAllData("isosesskey.txt", temp);
		ShowLogs(1, "Session key used for Hashing: %s", temp);
		memset(tempOut, 0x0, sizeof(tempOut));
		HexDecodeMethod((unsigned char*)temp, strlen(temp), (unsigned char*) tempOut);
		sha256_update(&ctx, (uint8_ts*) tempOut, 16);
		sha256_update(&ctx, (uint8_ts*) packBuf, (uint32_ts) strlen(packBuf));
		sha256_finish(&ctx, (uint8_ts*) boutHash);
		HexEnCodeMethod((unsigned char*) boutHash, 32, (unsigned char*) outHash);
		(void) DL_ISO8583_MSG_SetField_Str(64, outHash, &isoMsg);
		memset(packBuf, 0x0, sizeof(packBuf));
		(void) DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
		packBuf[0] = packedSize >> 8;
		packBuf[1] = packedSize;
		DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
		DL_ISO8583_MSG_Free(&isoMsg);
	}

	//For Gprs
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("cotype", temp);
	if(strstr(temp, "GPRS") != NULL)
 	{
 		glSysParam.stTxnCommCfg.ucCommType = 5;
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("coapn", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("cosubnet", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("copwd", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}
	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return 0;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return 0;
			}
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return 0;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return 0;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return 0;
			}
			CommOnHook(TRUE);
 		}
 	}else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
 	ScrBackLight(1);
	//Start here
 	memset(hexData, '\0', strlen(hexData));
	HexEnCodeMethod(output, strlen(output) + 2, hexData);
	ShowLogs(1, "Received From Nibss: %s", hexData);

	
	unsigned char ucByte = 0;
	ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
	//HexEnCodeMethod(output, ucByte, hexData);
	//ShowLogs(1, "Response: %s\n", hexData);
	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	(void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
	//How to read data
	int i = 62;
	if ( NULL != isoMsg.field[i].ptr ) 
	{
		DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(39, &isoHandler);
		sprintf(resp, "%s", isoMsg.field[39].ptr);
		ShowLogs(1, "Response Code: %s", resp);
		if(strstr(resp, "00") != NULL)
		{
			DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
			memset(keyStore, '\0', strlen(keyFin)); 
			sprintf(keyStore, "%s", isoMsg.field[i].ptr);
			//ShowLogs(1, "Field 62, %s", keyStore);
			CreateWrite("param.txt", keyStore);
			return parseParameters(keyStore);
		}
		return 0;
	}else
		//printf("Field %d is not present in ISO\n", i);
		ShowLogs(1, "Field %d is not present in ISO\n", i);
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);
	return 0;
}

int GetParaMetersTest(char *resCode)
{
    char hexData[5 * 1024] = { 0 };
    char output[5 * 1024] = { 0 };
    DL_UINT8 	packBuf[5 * 1024] = { 0x0 };
    /* get ISO-8583 1987 handler */
    DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
    char timeGotten[15] = {0};
    char datetime[11] = {0};
    char dt[5] = {0};
    char tm[7] = {0};
    int iRet, iLen = 0;
    char temp[128] = {0};
    char keyStore[128] = {0};
    char keyFin[33] = {0};
    char tempStore[128] = {0};
    char resp[3] = {0};
    char SN[33] = {0};
    char theUHI[33] = {0};
    char theUHISend[33] = {0};
    context_sha256_t ctx;
    char tempOut[100] = { '\0' };
    char boutHash[100] = { 0x0 };
    char outHash[100] = { 0x0 };
    char stan[7] = {0};

    memset(packBuf, 0x0, sizeof(packBuf));

    SysGetTimeIso(timeGotten);
    strncpy(datetime, timeGotten + 2, 10);
    strncpy(dt, timeGotten + 2, 4);
    strncpy(tm, timeGotten + 6, 6);

    /* initialise ISO message */
    DL_ISO8583_MSG_Init(NULL,0,&isoMsg);

    /* set ISO message fields */
    (void)DL_ISO8583_MSG_SetField_Str(0, "0800", &isoMsg);
    (void)DL_ISO8583_MSG_SetField_Str(3, "9C0000", &isoMsg);
    (void)DL_ISO8583_MSG_SetField_Str(7, datetime, &isoMsg);
    sprintf((char *)stan, "%06lu", useStan);  
    (void)DL_ISO8583_MSG_SetField_Str(11, stan, &isoMsg);
    GetStan();
    (void)DL_ISO8583_MSG_SetField_Str(12, tm, &isoMsg);
    (void)DL_ISO8583_MSG_SetField_Str(13, dt, &isoMsg);
    memset(temp, '\0', strlen(temp)); 
    UtilGetEnv("tid", temp);
    (void)DL_ISO8583_MSG_SetField_Str(41, temp, &isoMsg);
    memset(SN, '\0', strlen(SN)); 
    ReadSN(SN);
    if ('\0' == SN[0]) {
        //No serial
        strcpy(theUHI, "000000009");
    }
    strcpy(theUHI, SN);
    sprintf(theUHISend, "01%03d%s", strlen(theUHI), theUHI);
    (void)DL_ISO8583_MSG_SetField_Str(62, theUHISend, &isoMsg);
    (void) DL_ISO8583_MSG_SetField_Str(64, 0x0, &isoMsg);
    
    sha256_starts(&ctx);
    (void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, packBuf, &packedSize);
    HexEnCodeMethod((DL_UINT8*) packBuf, packedSize, hexData);
    ShowLogs(1, "Packed size %d", packedSize);

    if (packedSize >= 64) 
    {
        packBuf[packedSize - 64] = '\0';
        ShowLogs(1, "Packed ISO before hashing : %s", packBuf);
        memset(temp, '\0', strlen(temp));
        ReadAllData("isosesskey.txt", temp);
        ShowLogs(1, "Session key used for Hashing: %s", temp);
        memset(tempOut, 0x0, sizeof(tempOut));
        HexDecodeMethod((unsigned char*)temp, strlen(temp), (unsigned char*) tempOut);
        sha256_update(&ctx, (uint8_ts*) tempOut, 16);
        sha256_update(&ctx, (uint8_ts*) packBuf, (uint32_ts) strlen(packBuf));
        sha256_finish(&ctx, (uint8_ts*) boutHash);
        HexEnCodeMethod((unsigned char*) boutHash, 32, (unsigned char*) outHash);
        (void) DL_ISO8583_MSG_SetField_Str(64, outHash, &isoMsg);
        memset(packBuf, 0x0, sizeof(packBuf));
        (void) DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
        packBuf[0] = packedSize >> 8;
        packBuf[1] = packedSize;
        DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
        DL_ISO8583_MSG_Free(&isoMsg);
    }

    //For Gprs
    memset(temp, '\0', strlen(temp)); 
    UtilGetEnv("cotype", temp);
    if(strstr(temp, "GPRS") != NULL)
    {
        glSysParam.stTxnCommCfg.ucCommType = 5;
        memset(temp, '\0', strlen(temp));
        UtilGetEnv("coapn", temp);
        memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
        memset(temp, '\0', strlen(temp));
        UtilGetEnv("cosubnet", temp);
        memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
        memset(temp, '\0', strlen(temp));
        UtilGetEnv("copwd", temp);
        memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("uhostip", temp);
        memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
        memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
        memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
        memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("uhostport", temp);
        memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
        memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
        memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
        memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("uhostssl", temp);
        if(strstr(temp, "true") != NULL)
        {
            ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
            ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
            ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
            ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
            ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
            ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
            ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
            
            EmvSetSSLFlag();
            DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
            iRet = CommInitModule(&glSysParam.stTxnCommCfg);
            ShowLogs(1, "CommsInitialization Response: %d", iRet);
            if (iRet != 0)
            {
                ShowLogs(1, "Comms Initialization failed.");
                DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
                SxxSSLClose();
                return 0;
            }else
            {
                ShowLogs(1, "CommsInitialization Successful");
            }
            iRet = CommDial(DM_DIAL);
            ShowLogs(1, "CommsDial Response: %d", iRet);
            if (iRet != 0)
            {
                ShowLogs(1, "Comms Dial failed.");
                DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
                SxxSSLClose();
                return 0;
            }else
            {
                ShowLogs(1, "CommDial Successful");
            }
            DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
            iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
            ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
            if (iRet < 0)
            {
                DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
                ShowLogs(1, "SxxSSLTxd failed.");
                SxxSSLClose();
                return 0;
            }else
            {
                ShowLogs(1, "SxxSSLClose Successful");
            }
            DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
            iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
            ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
            ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
            if (iRet < 0)
            {
                DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
                ShowLogs(1, "SxxSSLRxd failed.");
                SxxSSLClose();
                return 0;
            }else
            {
                ShowLogs(1, "SxxSSLRxd Successful");
            }
            SxxSSLClose();
        }else
        {   
            //For non ssl
            EmvUnsetSSLFlag();
            ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
            ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
            ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
            ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
            ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
            ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
            ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

            DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
            iRet = CommInitModule(&glSysParam.stTxnCommCfg);
            //ShowLogs(1, "CommsInitialization Response: %d", iRet);
            if (iRet != 0)
            {
                ShowLogs(1, "Comms Initialization failed.");
                DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
                CommOnHook(TRUE);
                return 0;
            }
            iRet = CommDial(DM_DIAL);
            //ShowLogs(1, "CommsDial Response: %d", iRet);
            if (iRet != 0)
            {
                ShowLogs(1, "Comms Dial failed.");
                DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
                CommOnHook(TRUE);
                return 0;
            }
            DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
            iRet = CommTxd(packBuf, packedSize + 2, 60);
            //ShowLogs(1, "CommTxd Response: %d", iRet);
            if (iRet != 0)
            {
                DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
                ShowLogs(1, "CommTxd failed.");
                CommOnHook(TRUE);
                return 0;
            }
            DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
            iRet = CommRxd(output, 4 * 1024, 60, &iLen);
            //ShowLogs(1, "CommRxd Response: %d", iRet);
            if (iRet != 0)
            {
                DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
                ShowLogs(1, "CommRxd failed.");
                CommOnHook(TRUE);
                return 0;
            }
            CommOnHook(TRUE);
        }
    }else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
    ScrBackLight(1);
    //Start here
    memset(hexData, '\0', strlen(hexData));
    HexEnCodeMethod(output, strlen(output) + 2, hexData);
    ShowLogs(1, "Received From Nibss: %s", hexData);

    
    unsigned char ucByte = 0;
    ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
    //HexEnCodeMethod(output, ucByte, hexData);
    //ShowLogs(1, "Response: %s\n", hexData);
    /* initialise ISO message */
    DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
    (void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
    DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
    //How to read data
    int i = 62;
    if ( NULL != isoMsg.field[i].ptr ) 
    {
        DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(39, &isoHandler);
        sprintf(resp, "%s", isoMsg.field[39].ptr);
        strcpy(resCode, resp);
        ShowLogs(1, "Response Code: %s", resp);
        if(strstr(resp, "00") != NULL)
        {
            DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
            memset(keyStore, '\0', strlen(keyFin)); 
            sprintf(keyStore, "%s", isoMsg.field[i].ptr);
            //ShowLogs(1, "Field 62, %s", keyStore);
            CreateWrite("param.txt", keyStore);
            return parseParameters(keyStore);
        }
        return 0;
    }else
        //printf("Field %d is not present in ISO\n", i);
        ShowLogs(1, "Field %d is not present in ISO\n", i);
    /* free ISO message */
    DL_ISO8583_MSG_Free(&isoMsg);
    return 0;
}

void parsetrack2(char *track, char *parse)
{
	int i = 0, j = 0;
	for(i = 0; i < strlen(track); i++)
	{
		if(track[i] == '=')
		{
			parse[j] = 'D';
			j++;
		}else
		{
			parse[j] = track[i];
			j++;
		}
	}
}

int SendEmvData(char *icc, int *reversal)
{
	char hexData[5 * 1024] = { 0 };
	char output[5 * 1024] = { 0 };
	DL_UINT8 	packBuf[5 * 1024] = { 0x0 };
	/* get ISO-8583 1987 handler */
	DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	char dt[5] = {0};
	char tm[7] = {0};
	int iRet, iLen = 0;
	char temp[128] = {0};
	char temp2[128] = {0};
	char keyStore[128] = {0};
	char keyFin[33] = {0};
	char tempStore[128] = {0};
	char resp[3] = {0};
	char SN[33] = {0};
	char theUHI[33] = {0};
	char theUHISend[33] = {0};
	context_sha256_t ctx;
	char tempOut[100] = { '\0' };
	char boutHash[100] = { 0x0 };
	char outHash[100] = { 0x0 };
	char dataStore[254] = {0};
	uchar	szLocalTime[14+1];
	uchar outputData[10240] = {0};
	char parseTrack2[40] = {0};

	memset(packBuf, 0x0, sizeof(packBuf));
	//For sales completion
	if(txnType == 6 || manflag == 5 || magflag == 5)
	{
		if(parseEod(glSendPack.szRRN, glSendPack.szAuthCode) != 1)
		{
			sprintf((char *)glProcInfo.stTranLog.szRspCode, "%.2s", "");
			sprintf((char *)glProcInfo.stTranLog.szAuthCode, "%.6s", "");
			sprintf((char *)glProcInfo.stTranLog.szRRN, "%.12s", "");
			sprintf((char *)glProcInfo.stTranLog.szCondCode,  "%.2s",  "");
			sprintf((char *)glProcInfo.stTranLog.szFrnAmount, "%.12s", "");
			return -1;
		}
	}else
	{
		ShowLogs(1, "Not a sales completion txn");
	}

	SysGetTimeIso(timeGotten);
	strncpy(datetime, timeGotten + 2, 10);
	sprintf((char *)glSendPack.szLocalDateTime, "%.*s", LEN_LOCAL_DATE_TIME, datetime);
	strncpy(dt, timeGotten + 2, 4);
	sprintf((char *)glSendPack.szLocalDate, "%.*s", LEN_LOCAL_DATE, dt);
	strncpy(tm, timeGotten + 6, 6);
	sprintf((char *)glSendPack.szLocalTime, "%.*s", LEN_LOCAL_TIME, tm);

	memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
	memset(glRecvPack.szLocalDateTime, '\0', strlen(glRecvPack.szLocalDateTime));
	memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
	memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
	memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
	memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
	memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
	memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
	memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
	memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));

	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);

	/* set ISO message fields */
	if(strlen(glSendPack.szMsgCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(0, glSendPack.szMsgCode, &isoMsg);
	}
	if(strlen(glSendPack.szPan) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(2, glSendPack.szPan, &isoMsg);
	}
	if(strlen(glSendPack.szProcCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(3, glSendPack.szProcCode, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szProcCode), glSendPack.szProcCode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szTranAmt) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(4, glSendPack.szTranAmt, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szTranAmt), glSendPack.szTranAmt);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szLocalDateTime) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(7, glSendPack.szLocalDateTime, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szLocalDateTime), glSendPack.szLocalDateTime);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szSTAN) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(11, glSendPack.szSTAN, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szSTAN), glSendPack.szSTAN);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	GetStan();
	if(strlen(glSendPack.szLocalTime) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(12, glSendPack.szLocalTime, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szLocalTime), glSendPack.szLocalTime);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szLocalDate) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(13, glSendPack.szLocalDate, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szLocalDate), glSendPack.szLocalDate);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szExpDate) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(14, glSendPack.szExpDate, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szExpDate), glSendPack.szExpDate);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szMerchantType) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(18, glSendPack.szMerchantType, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szMerchantType), glSendPack.szMerchantType);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szEntryMode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(22, glSendPack.szEntryMode + 1, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szEntryMode), glSendPack.szEntryMode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szPanSeqNo) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(23, glSendPack.szPanSeqNo, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szPanSeqNo), glSendPack.szPanSeqNo);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szCondCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(25, glSendPack.szCondCode, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szCondCode), glSendPack.szCondCode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szPoscCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(26, glSendPack.szPoscCode, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szPoscCode), glSendPack.szPoscCode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szTransFee) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(28, glSendPack.szTransFee, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szTransFee), glSendPack.szTransFee);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szAqurId) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(32, glSendPack.szAqurId, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szAqurId), glSendPack.szAqurId);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szTrack2) > 0)
	{
		memset(parseTrack2, '\0', strlen(parseTrack2));
		parsetrack2(glSendPack.szTrack2, parseTrack2);
		(void)DL_ISO8583_MSG_SetField_Str(35, parseTrack2, &isoMsg);

		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(parseTrack2), parseTrack2);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szRRN) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(37, glSendPack.szRRN, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szRRN), glSendPack.szRRN);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szAuthCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(38, glSendPack.szAuthCode, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szAuthCode), glSendPack.szAuthCode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szServResCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(40, glSendPack.szServResCode, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szServResCode), glSendPack.szServResCode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szTermID) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(41, glSendPack.szTermID, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szTermID), glSendPack.szTermID);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szMerchantID) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(42, glSendPack.szMerchantID, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szMerchantID), glSendPack.szMerchantID);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szMNL) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(43, glSendPack.szMNL, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szMNL), glSendPack.szMNL);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szTranCurcyCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(49, glSendPack.szTranCurcyCode, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szTranCurcyCode), glSendPack.szTranCurcyCode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(pincheck == 1)
	{
		if(strlen(glSendPack.szPinBlock) > 0)
		{
			(void)DL_ISO8583_MSG_SetField_Str(52, glSendPack.szPinBlock, &isoMsg);
		}
		pincheck = 0;
	}
	if(strlen(glSendPack.testSICCData) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(55, glSendPack.testSICCData, &isoMsg);
	}
	
	/*if(icc != NULL)
	{
		(void)DL_ISO8583_MSG_SetField_Str(55, icc, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(icc), icc);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}*/
	if(strlen(glSendPack.szReasonCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(56, glSendPack.szReasonCode, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szReasonCode), glSendPack.szReasonCode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}

	if(strlen(glSendPack.szTEchoData) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(59, glSendPack.szTEchoData, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szTEchoData), glSendPack.szTEchoData);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	//Added for vas
	if(strlen(glSendPack.szBillers) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(62, glSendPack.szBillers, &isoMsg);
	}

	if(strlen(glSendPack.szOrigDataElement) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(90, glSendPack.szOrigDataElement, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szOrigDataElement), glSendPack.szOrigDataElement);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szReplAmount) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(95, glSendPack.szReplAmount, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szReplAmount), glSendPack.szReplAmount);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	if(strlen(glSendPack.szPosDataCode) > 0)
	{
		(void)DL_ISO8583_MSG_SetField_Str(123, glSendPack.szPosDataCode, &isoMsg);
		//memset(temp2, '\0', strlen(temp2));
		//sprintf(temp2, "%.2d - %s", strlen(glSendPack.szPosDataCode), glSendPack.szPosDataCode);
		//DisplayInfoNone("UNIFIED PAYMENTS", temp2, 3);
	}
	(void) DL_ISO8583_MSG_SetField_Str(128, 0x0, &isoMsg);

	sha256_starts(&ctx);
	(void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, packBuf, &packedSize);
	HexEnCodeMethod((DL_UINT8*) packBuf, packedSize, hexData);
	ShowLogs(1, "Packed size %d", packedSize);

	if (packedSize >= 64) 
	{
		packBuf[packedSize - 64] = '\0';
		ShowLogs(1, "Packed ISO before hashing : %s", packBuf);
		memset(temp, '\0', strlen(temp));
		ReadAllData("isosesskey.txt", temp);
		ShowLogs(1, "Session key used for Hashing: %s", temp);
		memset(tempOut, 0x0, sizeof(tempOut));
		HexDecodeMethod((unsigned char*)temp, strlen(temp), (unsigned char*) tempOut);
		sha256_update(&ctx, (uint8_ts*) tempOut, 16);
		sha256_update(&ctx, (uint8_ts*) packBuf, (uint32_ts) strlen(packBuf));
		sha256_finish(&ctx, (uint8_ts*) boutHash);
		HexEnCodeMethod((unsigned char*) boutHash, 32, (unsigned char*) outHash);
		(void) DL_ISO8583_MSG_SetField_Str(128, outHash, &isoMsg);
		memset(packBuf, 0x0, sizeof(packBuf));
		(void) DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
		packBuf[0] = packedSize >> 8;
		packBuf[1] = packedSize;
		DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
		DL_ISO8583_MSG_Free(&isoMsg);
	}
	//Fine till here

	//For Gprs
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("cotype", temp);
	if(strstr(temp, "GPRS") != NULL)
 	{
 		glSysParam.stTxnCommCfg.ucCommType = 5;
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("coapn", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("cosubnet", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("copwd", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}
			//Investigate from here tomorrow
	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				*reversal = 1;
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				*reversal = 1;
				ShowLogs(1, "Ima Mmi: %d", reversal);
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				*reversal = 1;
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				*reversal = 1;
				return -1;
			}
			CommOnHook(TRUE);
 		}
 	}else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
 	ShowLogs(1, "Done With Nibss");
	ScrBackLight(1);
 	memset(hexData, '\0', strlen(hexData));
	HexEnCodeMethod(output, strlen(output) + 2, hexData);
	ShowLogs(1, "Received From Nibss: %s", hexData);
	
	unsigned char ucByte = 0;
	ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	(void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
	
	
	int i = 0;

	//memset(&glRecvPack, 0, sizeof(STISO8583));//This is the problem
	
	//ShowLogs(1, "Commented out");
	for(i = 0; i < 129; i++)
	{
		if ( NULL != isoMsg.field[i].ptr ) 
		{
			memset(dataStore, '\0', strlen(dataStore));
			DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
			sprintf(dataStore, "%s", isoMsg.field[i].ptr);
			switch(i)
			{
				case 0:
					memset(glRecvPack.szMsgCode, '\0', strlen(glRecvPack.szMsgCode));
					sprintf((char *)glRecvPack.szMsgCode, "%.*s", LEN_MSG_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szMsgCode);
					continue;
				case 1:
					memset(glRecvPack.sBitMap, '\0', strlen(glRecvPack.sBitMap));
					sprintf((char *)glRecvPack.sBitMap, "%.*s", 2*LEN_BITMAP, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.sBitMap);
					continue;
				case 2:
					memset(glRecvPack.szPan, '\0', strlen(glRecvPack.szPan));
					sprintf((char *)glRecvPack.szPan, "%.*s", LEN_PAN, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPan);
					continue;
				case 3:
					memset(glRecvPack.szProcCode, '\0', strlen(glRecvPack.szProcCode));
					sprintf((char *)glRecvPack.szProcCode, "%.*s", LEN_PROC_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szProcCode);
					continue;
				case 4:
					memset(glRecvPack.szTranAmt, '\0', strlen(glRecvPack.szTranAmt));
					sprintf((char *)glRecvPack.szTranAmt, "%.*s", LEN_TRAN_AMT, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTranAmt);
					continue;
				case 7:
					memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
					sprintf((char *)glRecvPack.szFrnAmt, "%.*s", LEN_FRN_AMT, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szFrnAmt);
					continue;
				case 11:
					memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
					sprintf((char *)glRecvPack.szSTAN, "%.*s", LEN_STAN, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szSTAN);
					continue;
				case 12:
					memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
					sprintf((char *)glRecvPack.szLocalTime, "%.*s", LEN_LOCAL_TIME, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szLocalTime);
					continue;
				case 13:
					memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
					sprintf((char *)glRecvPack.szLocalDate, "%.*s", LEN_LOCAL_DATE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szLocalDate);
					continue;
				case 14:
					memset(glRecvPack.szExpDate, '\0', strlen(glRecvPack.szExpDate));
					sprintf((char *)glRecvPack.szExpDate, "%.*s", LEN_EXP_DATE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szExpDate);
					continue;
				case 15:
					memset(glRecvPack.szSetlDate, '\0', strlen(glRecvPack.szSetlDate));
					sprintf((char *)glRecvPack.szSetlDate, "%.*s", LEN_LOCAL_DATE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szSetlDate);
					continue;
				case 18:
					memset(glRecvPack.szMerchantType, '\0', strlen(glRecvPack.szMerchantType));
					sprintf((char *)glRecvPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szMerchantType);
					continue;
				case 22:
					memset(glRecvPack.szEntryMode, '\0', strlen(glRecvPack.szEntryMode));
					sprintf((char *)glRecvPack.szEntryMode, "%.*s", LEN_ENTRY_MODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szEntryMode);
					continue;
				case 23:
					memset(glRecvPack.szPanSeqNo, '\0', strlen(glRecvPack.szPanSeqNo));
					sprintf((char *)glRecvPack.szPanSeqNo, "%.*s", LEN_PAN_SEQ_NO, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPanSeqNo);
					continue;
				case 25:
					memset(glRecvPack.szCondCode, '\0', strlen(glRecvPack.szCondCode));
					sprintf((char *)glRecvPack.szCondCode, "%.*s", LEN_COND_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szCondCode);
					continue;
				case 28:
					memset(glRecvPack.szTransFee, '\0', strlen(glRecvPack.szTransFee));
					sprintf((char *)glRecvPack.szTransFee, "%.*s", LEN_TRANS_FEE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTransFee);
					continue;
				case 30:
					memset(glRecvPack.szTransFee, '\0', strlen(glRecvPack.szTransFee));
					sprintf((char *)glRecvPack.szTransFee, "%.*s", LEN_TRANS_FEE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTransFee);
					continue;
				case 32:
					memset(glRecvPack.szAqurId, '\0', strlen(glRecvPack.szAqurId));
					sprintf((char *)glRecvPack.szAqurId, "%.*s", LEN_AQUR_ID, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szAqurId);
					continue;
				case 33:
					memset(glRecvPack.szFwdInstId, '\0', strlen(glRecvPack.szFwdInstId));
					sprintf((char *)glRecvPack.szFwdInstId, "%.*s", LEN_AQUR_ID, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szFwdInstId);
					continue;
				case 35:
					memset(glRecvPack.szTrack2, '\0', strlen(glRecvPack.szTrack2));
					sprintf((char *)glRecvPack.szTrack2, "%.*s", LEN_TRACK2, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTrack2);
					continue;
				case 37:
					memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
					sprintf((char *)glRecvPack.szRRN, "%.*s", LEN_RRN, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szRRN);
					continue;
				case 38:
					memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
					sprintf((char *)glRecvPack.szAuthCode, "%.*s", LEN_AUTH_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szAuthCode);
					continue;
				case 39:
					memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
					sprintf((char *)glRecvPack.szRspCode, "%.*s", LEN_RSP_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szRspCode);
					continue;
				case 40:
					memset(glRecvPack.szServResCode, '\0', strlen(glRecvPack.szServResCode));
					sprintf((char *)glRecvPack.szServResCode, "%.*s", LEN_SRES_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szServResCode);
					continue;
				case 41:
					memset(glRecvPack.szTermID, '\0', strlen(glRecvPack.szTermID));
					sprintf((char *)glRecvPack.szTermID, "%.*s", LEN_TERM_ID, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTermID);
					continue;
				case 42:
					memset(glRecvPack.szMerchantID, '\0', strlen(glRecvPack.szMerchantID));
					sprintf((char *)glRecvPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szMerchantID);
					continue;
				case 43:
					memset(glRecvPack.szMNL, '\0', strlen(glRecvPack.szMNL));
					sprintf((char *)glRecvPack.szMNL, "%.*s", LEN_MNL, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szMNL);
					continue;
				case 49:
					memset(glRecvPack.szTranCurcyCode, '\0', strlen(glRecvPack.szTranCurcyCode));
					sprintf((char *)glRecvPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTranCurcyCode);
					continue;
				case 54:
					memset(glRecvPack.szAddtAmount, '\0', strlen(glRecvPack.szAddtAmount));
					sprintf((char *)glRecvPack.szAddtAmount, "%.*s", LEN_ADDT_AMT, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szAddtAmount);
					continue;
				case 55:
					memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
					sprintf((char *)glRecvPack.sICCData, "%.*s", LEN_ICC_DATA, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.sICCData);
					continue;
				case 59:
					memset(glRecvPack.szTEchoData, '\0', strlen(glRecvPack.szTEchoData));
					sprintf((char *)glRecvPack.szTEchoData, "%.*s", LEN_TRANSECHO_DATA, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szTEchoData);
					continue;
				case 60:
					memset(glRecvPack.szPayMentInfo, '\0', strlen(glRecvPack.szPayMentInfo));
					sprintf((char *)glRecvPack.szPayMentInfo, "%.*s", LEN_PAYMENT_INFO, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPayMentInfo);
					continue;
				case 62:
					memset(glRecvPack.szBillers, '\0', strlen(glRecvPack.szBillers));
					sprintf((char *)glRecvPack.szBillers, "%.*s", LEN_PAYMENT_INFO, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szBillers);
					continue;
				case 102:
					memset(glRecvPack.szActIdent1, '\0', strlen(glRecvPack.szActIdent1));
					sprintf((char *)glRecvPack.szActIdent1, "%.*s", LEN_ACT_IDTF, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szActIdent1);
					continue;
				case 103:
					memset(glRecvPack.szActIdent2, '\0', strlen(glRecvPack.szActIdent2));
					sprintf((char *)glRecvPack.szActIdent2, "%.*s", LEN_ACT_IDTF, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szActIdent2);
					continue;
				case 123:
					memset(glRecvPack.szPosDataCode, '\0', strlen(glRecvPack.szPosDataCode));
					sprintf((char *)glRecvPack.szPosDataCode, "%.*s", LEN_POS_CODE, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPosDataCode);
					continue;
				case 124:
					memset(glRecvPack.szPayMentInfo, '\0', strlen(glRecvPack.szPayMentInfo));
					sprintf((char *)glRecvPack.szPayMentInfo, "%.*s", LEN_PAYMENT_INFO, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szPayMentInfo);
					continue;
				case 128:
					memset(glRecvPack.szNFC, '\0', strlen(glRecvPack.szNFC));
					sprintf((char *)glRecvPack.szNFC, "%.*s", LEN_NEARFIELD, dataStore);
					//ShowLogs(1, "Field %d: %s", i, glRecvPack.szNFC);
					continue;
				default:
					continue;
			}
		}
	}
	ShowLogs(1, "Response Code: %s", glRecvPack.szRspCode);

	if(dispVal == 1)
	{
		dispVal = 0;
		return 0;
	}

	sprintf((char *)glProcInfo.stTranLog.szRspCode, "%.2s", glRecvPack.szRspCode);
	UpdateLocalTime(NULL, glRecvPack.szLocalDate, glRecvPack.szLocalTime);
	GetDateTime(szLocalTime);
	sprintf((char *)glProcInfo.stTranLog.szDateTime, "%.14s", szLocalTime);
	sprintf((char *)glProcInfo.stTranLog.szAuthCode, "%.6s", glRecvPack.szAuthCode);
	sprintf((char *)glProcInfo.stTranLog.szRRN, "%.12s", glRecvPack.szRRN);
	sprintf((char *)glProcInfo.stTranLog.szCondCode,  "%.2s",  glSendPack.szCondCode);
	sprintf((char *)glProcInfo.stTranLog.szFrnAmount, "%.12s", glRecvPack.szFrnAmt);
	FindCurrency(glRecvPack.szHolderCurcyCode, &glProcInfo.stTranLog.stHolderCurrency);

	ShowLogs(1, "Commencing Storage.");
	if((txnType != 5) && (iLen != 36) && (strlen(glRecvPack.szRspCode) == 2))
    {
    	ShowLogs(1, "About Storing Transaction.");
    	storeTxn();
    	ShowLogs(1, "About Storing Eod.");
		storeEod();
		ShowLogs(1, "About printing.");
		storeprint();
    }
    ShowLogs(1, "Done with Storing.");


	if(strstr(glRecvPack.szRspCode, "00") != NULL)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "APPROVED", 1);
	}else
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "DECLINED", 1);
	}

	if((strstr(glRecvPack.szRspCode, "06") != NULL)
		|| (strstr(glRecvPack.szRspCode, "20") != NULL)
		|| (strstr(glRecvPack.szRspCode, "21") != NULL)
		|| (strstr(glRecvPack.szRspCode, "22") != NULL)
		|| (strstr(glRecvPack.szRspCode, "68") != NULL)
		|| (strstr(glRecvPack.szRspCode, "90") != NULL)
		|| (strstr(glRecvPack.szRspCode, "94") != NULL))
	{
		//switchHostManual++;
		//if(switchHostManual < 2)
		//	DisplayInfoNone("UNIFIED PAYMENTS", "PLEASE ATTEMPT AGAIN", 0);
		switchHostManual = 2;
	}else
	{
		//if(switchHostManual)
		//	switchHostManual--;
	}
	//switchHostManual
	//Check for Key outta sync and do key exchange
	if(iLen == 36 || strlen(glRecvPack.szRspCode) != 2)
	{
		if(txnType == 7)
			revFlag = 1;
		ScrBackLight(1);
		Beep();
		//Reset here start
		memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
		memset(glRecvPack.szLocalDateTime, '\0', strlen(glRecvPack.szLocalDateTime));
		memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
		memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
		memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
		memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
		memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
		memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
		memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
		memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));
		memset(glProcInfo.stTranLog.szRspCode, '\0', strlen(glProcInfo.stTranLog.szRspCode));
		memset(glProcInfo.stTranLog.szDateTime, '\0', strlen(glProcInfo.stTranLog.szDateTime));
		memset(glProcInfo.stTranLog.szAuthCode, '\0', strlen(glProcInfo.stTranLog.szAuthCode));
		memset(glProcInfo.stTranLog.szRRN, '\0', strlen(glProcInfo.stTranLog.szRRN));
		memset(glProcInfo.stTranLog.szCondCode, '\0', strlen(glProcInfo.stTranLog.szCondCode));
		memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));
		memset(glProcInfo.stTranLog.szFrnAmount, '\0', strlen(glProcInfo.stTranLog.szFrnAmount));
		memset(szLocalTime, '\0', strlen(szLocalTime));
		GetDateTime(szLocalTime);
		sprintf((char *)glProcInfo.stTranLog.szDateTime, "%.14s", szLocalTime);
		memset(timeGotten, '\0', strlen(timeGotten));
		SysGetTimeIso(timeGotten);
		strncpy(datetime, timeGotten + 2, 10);
		sprintf((char *)glSendPack.szLocalDateTime, "%.*s", LEN_LOCAL_DATE_TIME, datetime);
		strncpy(dt, timeGotten + 2, 4);
		sprintf((char *)glSendPack.szLocalDate, "%.*s", LEN_LOCAL_DATE, dt);
		strncpy(tm, timeGotten + 6, 6);
		sprintf((char *)glSendPack.szLocalTime, "%.*s", LEN_LOCAL_TIME, tm);
		//Reset here stop
		if(GetMasterKey())
		{
			if(GetSessionKey())
			{
				if(GetPinKey())
				{
					if(GetParaMeters())
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PLEASE ATTEMPT AGAIN", 0);
					}else
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM FAILED", 0);
						memset(outputData, '\0', strlen(outputData));
						iRet = ReadAllData("param.txt", outputData);
						if(iRet == 0)
						{
							if(parseParametersOld(outputData))
							{
								ShowLogs(1, "Parameters Parse successful");
							}
						}
						//Reset here start
						memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
						memset(glRecvPack.szLocalDateTime, '\0', strlen(glRecvPack.szLocalDateTime));
						memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
						memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
						memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
						memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
						memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
						memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
						memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
						memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));
						memset(glProcInfo.stTranLog.szRspCode, '\0', strlen(glProcInfo.stTranLog.szRspCode));
						memset(glProcInfo.stTranLog.szDateTime, '\0', strlen(glProcInfo.stTranLog.szDateTime));
						memset(glProcInfo.stTranLog.szAuthCode, '\0', strlen(glProcInfo.stTranLog.szAuthCode));
						memset(glProcInfo.stTranLog.szRRN, '\0', strlen(glProcInfo.stTranLog.szRRN));
						memset(glProcInfo.stTranLog.szCondCode, '\0', strlen(glProcInfo.stTranLog.szCondCode));
						memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));
						memset(glProcInfo.stTranLog.szFrnAmount, '\0', strlen(glProcInfo.stTranLog.szFrnAmount));
						memset(szLocalTime, '\0', strlen(szLocalTime));
						GetDateTime(szLocalTime);
						sprintf((char *)glProcInfo.stTranLog.szDateTime, "%.14s", szLocalTime);
						memset(timeGotten, '\0', strlen(timeGotten));
						SysGetTimeIso(timeGotten);
						strncpy(datetime, timeGotten + 2, 10);
						sprintf((char *)glSendPack.szLocalDateTime, "%.*s", LEN_LOCAL_DATE_TIME, datetime);
						strncpy(dt, timeGotten + 2, 4);
						sprintf((char *)glSendPack.szLocalDate, "%.*s", LEN_LOCAL_DATE, dt);
						strncpy(tm, timeGotten + 6, 6);
						sprintf((char *)glSendPack.szLocalTime, "%.*s", LEN_LOCAL_TIME, tm);
						//Reset here stop
					}
				}else
					DisplayInfoNone("UNIFIED PAYMENTS", "PINKEY FAILED", 0);
			}else
				DisplayInfoNone("UNIFIED PAYMENTS", "SESSIONKEY FAILED", 0);
		}else
			DisplayInfoNone("UNIFIED PAYMENTS", "MASTERKEY FAILED", 0);

		ScrBackLight(1);
		Beep();
	}
    
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);
	return 0;
}

int SendReversal()
{
	char hexData[5 * 1024] = { 0 };
	char output[5 * 1024] = { 0 };
	DL_UINT8 	packBuf[5 * 1024] = { 0x0 };
	/* get ISO-8583 1987 handler */
	DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	char dt[5] = {0};
	char tm[7] = {0};
	int iRet, iLen = 0;
	char temp[128] = {0};
	char keyStore[128] = {0};
	char keyFin[33] = {0};
	char tempStore[128] = {0};
	char resp[3] = {0};
	char SN[33] = {0};
	char theUHI[33] = {0};
	char theUHISend[33] = {0};
	context_sha256_t ctx;
	char tempOut[100] = { '\0' };
	char boutHash[100] = { 0x0 };
	char outHash[100] = { 0x0 };
	char dataStore[254] = {0};
	uchar	szLocalTime[14+1];
	uchar	szSTAN[LEN_STAN+2];
	char field90[100];
	char field95[100];

	memset(packBuf, 0x0, sizeof(packBuf));
	revSend = 1;

	SysGetTimeIso(timeGotten);
	strncpy(datetime, timeGotten + 2, 10);
	strncpy(dt, timeGotten + 2, 4);
	strncpy(tm, timeGotten + 6, 6);

	memset(field90, '\0', strlen(field90));
	memset(field95, '\0', strlen(field95));
	memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
	memset(glRecvPack.szLocalDateTime, '\0', strlen(glRecvPack.szLocalDateTime));
	memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
	memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
	memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
	memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
	memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
	memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
	memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
	memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));

	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);

	/* set ISO message fields */
	(void)DL_ISO8583_MSG_SetField_Str(0, "0420", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(2, glSendPack.szPan, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(3, glSendPack.szProcCode, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(4, glSendPack.szTranAmt, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(7, datetime, &isoMsg);
	glSysCtrl.ulSTAN = useStan;
	sprintf((char *)szSTAN, "%06lu", glSysCtrl.ulSTAN);  //??
	glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;
	(void)DL_ISO8583_MSG_SetField_Str(11, szSTAN, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(12, tm, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(13, dt, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(14, glSendPack.szExpDate, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(18, glSendPack.szMerchantType, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(22, glSendPack.szEntryMode + 1, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(23, glSendPack.szPanSeqNo, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(25, glSendPack.szCondCode, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(26, glSendPack.szPoscCode, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(28, glSendPack.szTransFee, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(35, glSendPack.szTrack2, &isoMsg);
	sprintf((char *)glSendPack.szRRN, "000000%s", szSTAN);
	(void)DL_ISO8583_MSG_SetField_Str(37, glSendPack.szRRN, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(41, glSendPack.szTermID, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(42, glSendPack.szMerchantID, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(43, glSendPack.szMNL, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(49, glSendPack.szTranCurcyCode, &isoMsg);
	strcpy(field90, glSendPack.szMsgCode);
	strcat(field90, glSendPack.szSTAN);
	strcat(field90, glSendPack.szLocalDateTime);
	strcat(field90, "0000011112900000111129");
	(void)DL_ISO8583_MSG_SetField_Str(90, field90, &isoMsg);
	strcpy(field95, glSendPack.szTranAmt);
	strcat(field95, "000000000000");
	strcat(field95, "C00000000");
	strcat(field95, "C00000000");
	(void)DL_ISO8583_MSG_SetField_Str(95, field95, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(123, glSendPack.szPosDataCode, &isoMsg);
	(void) DL_ISO8583_MSG_SetField_Str(128, 0x0, &isoMsg);
		
	sha256_starts(&ctx);
	(void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, packBuf, &packedSize);
	HexEnCodeMethod((DL_UINT8*) packBuf, packedSize, hexData);
	ShowLogs(1, "Packed size %d", packedSize);

	if (packedSize >= 64) 
	{
		packBuf[packedSize - 64] = '\0';
		ShowLogs(1, "Packed ISO before hashing : %s", packBuf);
		memset(temp, '\0', strlen(temp));
		ReadAllData("isosesskey.txt", temp);
		ShowLogs(1, "Session key used for Hashing: %s", temp);
		memset(tempOut, 0x0, sizeof(tempOut));
		HexDecodeMethod((unsigned char*)temp, strlen(temp), (unsigned char*) tempOut);
		sha256_update(&ctx, (uint8_ts*) tempOut, 16);
		sha256_update(&ctx, (uint8_ts*) packBuf, (uint32_ts) strlen(packBuf));
		sha256_finish(&ctx, (uint8_ts*) boutHash);
		HexEnCodeMethod((unsigned char*) boutHash, 32, (unsigned char*) outHash);
		(void) DL_ISO8583_MSG_SetField_Str(128, outHash, &isoMsg);
		memset(packBuf, 0x0, sizeof(packBuf));
		(void) DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
		packBuf[0] = packedSize >> 8;
		packBuf[1] = packedSize;
		DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
		DL_ISO8583_MSG_Free(&isoMsg);
	}
	
	//For Gprs
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("cotype", temp);
	if(strstr(temp, "GPRS") != NULL)
 	{
 		glSysParam.stTxnCommCfg.ucCommType = 5;
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("coapn", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("cosubnet", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("copwd", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}
	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
 	}else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
 	ShowLogs(1, "Done With Nibss");
	ScrBackLight(1);
 	memset(hexData, '\0', strlen(hexData));
	HexEnCodeMethod(output, strlen(output) + 2, hexData);
	ShowLogs(1, "Received From Nibss: %s", hexData);
	
	unsigned char ucByte = 0;
	ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	(void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
	
	
	int i = 0;

	//memset(&glRecvPack, 0, sizeof(STISO8583));//This is the problem
	
	ShowLogs(1, "Commented out");
	for(i = 0; i < 129; i++)
	{
		if ( NULL != isoMsg.field[i].ptr ) 
		{
			memset(dataStore, '\0', strlen(dataStore));
			DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
			sprintf(dataStore, "%s", isoMsg.field[i].ptr);
			switch(i)
			{
				case 0:
					memset(glRecvPack.szMsgCode, '\0', strlen(glRecvPack.szMsgCode));
					sprintf((char *)glRecvPack.szMsgCode, "%.*s", LEN_MSG_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szMsgCode);
					continue;
				case 1:
					memset(glRecvPack.sBitMap, '\0', strlen(glRecvPack.sBitMap));
					sprintf((char *)glRecvPack.sBitMap, "%.*s", 2*LEN_BITMAP, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.sBitMap);
					continue;
				case 2:
					memset(glRecvPack.szPan, '\0', strlen(glRecvPack.szPan));
					sprintf((char *)glRecvPack.szPan, "%.*s", LEN_PAN, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPan);
					continue;
				case 3:
					memset(glRecvPack.szProcCode, '\0', strlen(glRecvPack.szProcCode));
					sprintf((char *)glRecvPack.szProcCode, "%.*s", LEN_PROC_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szProcCode);
					continue;
				case 4:
					memset(glRecvPack.szTranAmt, '\0', strlen(glRecvPack.szTranAmt));
					sprintf((char *)glRecvPack.szTranAmt, "%.*s", LEN_TRAN_AMT, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTranAmt);
					continue;
				case 7:
					memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
					sprintf((char *)glRecvPack.szFrnAmt, "%.*s", LEN_FRN_AMT, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szFrnAmt);
					continue;
				case 11:
					memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
					sprintf((char *)glRecvPack.szSTAN, "%.*s", LEN_STAN, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szSTAN);
					continue;
				case 12:
					memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
					sprintf((char *)glRecvPack.szLocalTime, "%.*s", LEN_LOCAL_TIME, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szLocalTime);
					continue;
				case 13:
					memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
					sprintf((char *)glRecvPack.szLocalDate, "%.*s", LEN_LOCAL_DATE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szLocalDate);
					continue;
				case 14:
					memset(glRecvPack.szExpDate, '\0', strlen(glRecvPack.szExpDate));
					sprintf((char *)glRecvPack.szExpDate, "%.*s", LEN_EXP_DATE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szExpDate);
					continue;
				case 15:
					memset(glRecvPack.szSetlDate, '\0', strlen(glRecvPack.szSetlDate));
					sprintf((char *)glRecvPack.szSetlDate, "%.*s", LEN_LOCAL_DATE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szSetlDate);
					continue;
				case 18:
					memset(glRecvPack.szMerchantType, '\0', strlen(glRecvPack.szMerchantType));
					sprintf((char *)glRecvPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szMerchantType);
					continue;
				case 22:
					memset(glRecvPack.szEntryMode, '\0', strlen(glRecvPack.szEntryMode));
					sprintf((char *)glRecvPack.szEntryMode, "%.*s", LEN_ENTRY_MODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szEntryMode);
					continue;
				case 23:
					memset(glRecvPack.szPanSeqNo, '\0', strlen(glRecvPack.szPanSeqNo));
					sprintf((char *)glRecvPack.szPanSeqNo, "%.*s", LEN_PAN_SEQ_NO, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPanSeqNo);
					continue;
				case 25:
					memset(glRecvPack.szCondCode, '\0', strlen(glRecvPack.szCondCode));
					sprintf((char *)glRecvPack.szCondCode, "%.*s", LEN_COND_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szCondCode);
					continue;
				case 28:
					memset(glRecvPack.szTransFee, '\0', strlen(glRecvPack.szTransFee));
					sprintf((char *)glRecvPack.szTransFee, "%.*s", LEN_TRANS_FEE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTransFee);
					continue;
				case 30:
					memset(glRecvPack.szTransFee, '\0', strlen(glRecvPack.szTransFee));
					sprintf((char *)glRecvPack.szTransFee, "%.*s", LEN_TRANS_FEE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTransFee);
					continue;
				case 32:
					memset(glRecvPack.szAqurId, '\0', strlen(glRecvPack.szAqurId));
					sprintf((char *)glRecvPack.szAqurId, "%.*s", LEN_AQUR_ID, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szAqurId);
					continue;
				case 33:
					memset(glRecvPack.szFwdInstId, '\0', strlen(glRecvPack.szFwdInstId));
					sprintf((char *)glRecvPack.szFwdInstId, "%.*s", LEN_AQUR_ID, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szFwdInstId);
					continue;
				case 35:
					memset(glRecvPack.szTrack2, '\0', strlen(glRecvPack.szTrack2));
					sprintf((char *)glRecvPack.szTrack2, "%.*s", LEN_TRACK2, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTrack2);
					continue;
				case 37:
					memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
					sprintf((char *)glRecvPack.szRRN, "%.*s", LEN_RRN, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szRRN);
					continue;
				case 38:
					memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
					sprintf((char *)glRecvPack.szAuthCode, "%.*s", LEN_AUTH_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szAuthCode);
					continue;
				case 39:
					memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
					sprintf((char *)glRecvPack.szRspCode, "%.*s", LEN_RSP_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szRspCode);
					continue;
				case 40:
					memset(glRecvPack.szServResCode, '\0', strlen(glRecvPack.szServResCode));
					sprintf((char *)glRecvPack.szServResCode, "%.*s", LEN_SRES_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szServResCode);
					continue;
				case 41:
					memset(glRecvPack.szTermID, '\0', strlen(glRecvPack.szTermID));
					sprintf((char *)glRecvPack.szTermID, "%.*s", LEN_TERM_ID, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTermID);
					continue;
				case 42:
					memset(glRecvPack.szMerchantID, '\0', strlen(glRecvPack.szMerchantID));
					sprintf((char *)glRecvPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szMerchantID);
					continue;
				case 43:
					memset(glRecvPack.szMNL, '\0', strlen(glRecvPack.szMNL));
					sprintf((char *)glRecvPack.szMNL, "%.*s", LEN_MNL, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szMNL);
					continue;
				case 49:
					memset(glRecvPack.szTranCurcyCode, '\0', strlen(glRecvPack.szTranCurcyCode));
					sprintf((char *)glRecvPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTranCurcyCode);
					continue;
				case 54:
					memset(glRecvPack.szAddtAmount, '\0', strlen(glRecvPack.szAddtAmount));
					sprintf((char *)glRecvPack.szAddtAmount, "%.*s", LEN_ADDT_AMT, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szAddtAmount);
					continue;
				case 55:
					memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
					sprintf((char *)glRecvPack.sICCData, "%.*s", LEN_ICC_DATA, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.sICCData);
					continue;
				case 59:
					memset(glRecvPack.szTEchoData, '\0', strlen(glRecvPack.szTEchoData));
					sprintf((char *)glRecvPack.szTEchoData, "%.*s", LEN_TRANSECHO_DATA, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTEchoData);
					continue;
				case 60:
					memset(glRecvPack.szPayMentInfo, '\0', strlen(glRecvPack.szPayMentInfo));
					sprintf((char *)glRecvPack.szPayMentInfo, "%.*s", LEN_PAYMENT_INFO, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPayMentInfo);
					continue;
				case 102:
					memset(glRecvPack.szActIdent1, '\0', strlen(glRecvPack.szActIdent1));
					sprintf((char *)glRecvPack.szActIdent1, "%.*s", LEN_ACT_IDTF, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szActIdent1);
					continue;
				case 103:
					memset(glRecvPack.szActIdent2, '\0', strlen(glRecvPack.szActIdent2));
					sprintf((char *)glRecvPack.szActIdent2, "%.*s", LEN_ACT_IDTF, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szActIdent2);
					continue;
				case 123:
					memset(glRecvPack.szPosDataCode, '\0', strlen(glRecvPack.szPosDataCode));
					sprintf((char *)glRecvPack.szPosDataCode, "%.*s", LEN_POS_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPosDataCode);
					continue;
				case 124:
					memset(glRecvPack.szPayMentInfo, '\0', strlen(glRecvPack.szPayMentInfo));
					sprintf((char *)glRecvPack.szPayMentInfo, "%.*s", LEN_PAYMENT_INFO, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPayMentInfo);
					continue;
				case 128:
					memset(glRecvPack.szNFC, '\0', strlen(glRecvPack.szNFC));
					sprintf((char *)glRecvPack.szNFC, "%.*s", LEN_NEARFIELD, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szNFC);
					continue;
				default:
					continue;
			}
		}
	}
	ShowLogs(1, "Reversal Response Code: %s", glRecvPack.szRspCode);
	if(strstr(glRecvPack.szRspCode, "00") != NULL)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "SUCCESSFUL", 3);
	}else if(strstr(glRecvPack.szRspCode, "25") != NULL)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "SUCCESSFUL", 3);
	}else
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "NOT SUCCESSFUL", 3);
	}
	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);
	return 0;
}

int SendManualReversal()
{
	char hexData[5 * 1024] = { 0 };
	char output[5 * 1024] = { 0 };
	DL_UINT8 	packBuf[5 * 1024] = { 0x0 };
	/* get ISO-8583 1987 handler */
	DL_ISO8583_DEFS_1987_GetHandler(&isoHandler);
	char timeGotten[15] = {0};
	char datetime[11] = {0};
	char dt[5] = {0};
	char tm[7] = {0};
	int iRet, iLen = 0;
	char temp[128] = {0};
	char keyStore[128] = {0};
	char keyFin[33] = {0};
	char tempStore[128] = {0};
	char resp[3] = {0};
	char SN[33] = {0};
	char theUHI[33] = {0};
	char theUHISend[33] = {0};
	context_sha256_t ctx;
	char tempOut[100] = { '\0' };
	char boutHash[100] = { 0x0 };
	char outHash[100] = { 0x0 };
	char dataStore[254] = {0};
	uchar	szLocalTime[14+1];
	uchar	szSTAN[LEN_STAN+2];
	char field90[100];
	char field95[100];

	memset(packBuf, 0x0, sizeof(packBuf));
	
	memset(field90, '\0', strlen(field90));
	memset(field95, '\0', strlen(field95));
	memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
	memset(glRecvPack.szLocalDateTime, '\0', strlen(glRecvPack.szLocalDateTime));
	memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
	memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
	memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
	memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
	memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
	memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
	memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
	memset(glRecvPack.szHolderCurcyCode, '\0', strlen(glRecvPack.szHolderCurcyCode));


	/* initialise ISO message */
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);

	/* set ISO message fields */
	(void)DL_ISO8583_MSG_SetField_Str(0, "0420", &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(2, glSendPack.szPan, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(3, glSendPack.szProcCode, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(4, glSendPack.szTranAmt, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(7, glSendPack.szLocalDateTime, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(11, glSendPack.szSTAN, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(12, glSendPack.szLocalTime, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(13, glSendPack.szLocalDate, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(14, glSendPack.szExpDate, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(18, glSendPack.szMerchantType, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(22, glSendPack.szEntryMode + 1, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(23, glSendPack.szPanSeqNo, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(25, glSendPack.szCondCode, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(26, glSendPack.szPoscCode, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(28, glSendPack.szTransFee, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(32, glSendPack.szAqurId, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(35, glSendPack.szTrack2, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(37, glSendPack.szRRN, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(41, glSendPack.szTermID, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(42, glSendPack.szMerchantID, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(43, glSendPack.szMNL, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(49, glSendPack.szTranCurcyCode, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(56, glSendPack.szReasonCode, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(90, glSendPack.szOrigDataElement, &isoMsg);
	(void)DL_ISO8583_MSG_SetField_Str(123, glSendPack.szPosDataCode, &isoMsg);
	(void) DL_ISO8583_MSG_SetField_Str(128, 0x0, &isoMsg);
		
	sha256_starts(&ctx);
	(void)DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, packBuf, &packedSize);
	HexEnCodeMethod((DL_UINT8*) packBuf, packedSize, hexData);
	ShowLogs(1, "Packed size %d", packedSize);

	if (packedSize >= 64) 
	{
		packBuf[packedSize - 64] = '\0';
		ShowLogs(1, "Packed ISO before hashing : %s", packBuf);
		memset(temp, '\0', strlen(temp));
		ReadAllData("isosesskey.txt", temp);
		ShowLogs(1, "Session key used for Hashing: %s", temp);
		memset(tempOut, 0x0, sizeof(tempOut));
		HexDecodeMethod((unsigned char*)temp, strlen(temp), (unsigned char*) tempOut);
		sha256_update(&ctx, (uint8_ts*) tempOut, 16);
		sha256_update(&ctx, (uint8_ts*) packBuf, (uint32_ts) strlen(packBuf));
		sha256_finish(&ctx, (uint8_ts*) boutHash);
		HexEnCodeMethod((unsigned char*) boutHash, 32, (unsigned char*) outHash);
		(void) DL_ISO8583_MSG_SetField_Str(128, outHash, &isoMsg);
		memset(packBuf, 0x0, sizeof(packBuf));
		(void) DL_ISO8583_MSG_Pack(&isoHandler, &isoMsg, &packBuf[2], &packedSize);
		packBuf[0] = packedSize >> 8;
		packBuf[1] = packedSize;
		DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
		DL_ISO8583_MSG_Free(&isoMsg);
	}
	
	//For Gprs
	memset(temp, '\0', strlen(temp)); 
	UtilGetEnv("cotype", temp);
	if(strstr(temp, "GPRS") != NULL)
 	{
 		glSysParam.stTxnCommCfg.ucCommType = 5;
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("coapn", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szAPN, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("cosubnet", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szUID, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("copwd", temp);
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.szPwd, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}
	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
 	}else
	{
		glSysParam.stTxnCommCfg.ucCommType = 6;
		CommSwitchType(CT_WIFI);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostip", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP, temp, strlen(temp));
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("uhostport", temp);
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort, temp, strlen(temp));
		memset(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, '\0', sizeof(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort));
		memcpy(glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort, temp, strlen(temp));

		ShowLogs(1, "Wifi Ip 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szIP);
		ShowLogs(1, "Wifi Ip 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szIP);
		ShowLogs(1, "Wifi Port 1: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost1.szPort);
		ShowLogs(1, "Wifi Port 2: %s", glSysParam.stTxnCommCfg.stWifiPara.stHost2.szPort);

		UtilGetEnvEx("uhostssl", temp);
		if(strstr(temp, "true") != NULL)
 		{
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);
	 		
	 		EmvSetSSLFlag();
			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("REVERSAL", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommsInitialization Successful");
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");

	 		iRet = CommDial(DM_DIAL);
	 		ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "CommDial Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = SxxSSLTxd(packBuf, packedSize + 2, 60);
	 		ShowLogs(1, "SxxSSLTxd Response: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "SxxSSLTxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLClose Successful");
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
	 		iRet = SxxSSLRxd(output, 4 * 1024, 60, &iLen);
			ShowLogs(1, "1. SxxSSLRxd Response Len: %d", iLen);
			ShowLogs(1, "2. SxxSSLRxd Response Ret: %d", iRet);
	 		if (iRet < 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "SxxSSLRxd failed.");
				SxxSSLClose();
				return -1;
			}else
			{
				ShowLogs(1, "SxxSSLRxd Successful");
			}
			SxxSSLClose();
 		}else
 		{	
 			//For non ssl
 			EmvUnsetSSLFlag();
 			ShowLogs(1, "Apn: %s", glSysParam.stTxnCommCfg.stWirlessPara.szAPN);
	 		ShowLogs(1, "Username: %s", glSysParam.stTxnCommCfg.stWirlessPara.szUID);
	 		ShowLogs(1, "Password: %s", glSysParam.stTxnCommCfg.stWirlessPara.szPwd);
	 		ShowLogs(1, "Ip 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szIP);
	 		ShowLogs(1, "Port 1: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost1.szPort);
	 		ShowLogs(1, "Ip 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szIP);
	 		ShowLogs(1, "Port 2: %s", glSysParam.stTxnCommCfg.stWirlessPara.stHost2.szPort);

 			DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING...", 0);
	 		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
	 		//ShowLogs(1, "CommsInitialization Response: %d", iRet);
			if (iRet != 0)
			{
				ShowLogs(1, "Comms Initialization failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}

			ShowLogs(1, "About Calling CommSetCfgParam");
			CommSetCfgParam(&glSysParam.stTxnCommCfg);
			ShowLogs(1, "Done Calling CommSetCfgParam");
	 		iRet = CommDial(DM_DIAL);
	 		//ShowLogs(1, "CommsDial Response: %d", iRet);
	 		if (iRet != 0)
			{
				ShowLogs(1, "Comms Dial failed.");
				DisplayInfoNone("UNIFIED PAYMENTS", "CONNECTING FAILED", 0);
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "DATA EXCHANGE ->", 0);
	 		iRet = CommTxd(packBuf, packedSize + 2, 60);
	 		//ShowLogs(1, "CommTxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING FAILED", 0);
				ShowLogs(1, "CommTxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			DisplayInfoNone("UNIFIED PAYMENTS", "<- DATA EXCHANGE", 0);
			iRet = CommRxd(output, 4 * 1024, 60, &iLen);
			//ShowLogs(1, "CommRxd Response: %d", iRet);
	 		if (iRet != 0)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "RECEIVING FAILED", 0);
				ShowLogs(1, "CommRxd failed.");
				CommOnHook(TRUE);
				return -1;
			}
			CommOnHook(TRUE);
 		}
	}
 	ShowLogs(1, "Done With Nibss");
	ScrBackLight(1);
 	memset(hexData, '\0', strlen(hexData));
	HexEnCodeMethod(output, strlen(output) + 2, hexData);
	ShowLogs(1, "Received From Nibss: %s", hexData);
	
	unsigned char ucByte = 0;
	ucByte = (unsigned char) strtoul(hexData, NULL, 16); 
	DL_ISO8583_MSG_Init(NULL,0,&isoMsg);
	(void)DL_ISO8583_MSG_Unpack(&isoHandler, &output[2], iLen - 2, &isoMsg);
	DL_ISO8583_MSG_Dump("", &isoHandler, &isoMsg);
	
	
	int i = 0;

	//memset(&glRecvPack, 0, sizeof(STISO8583));//This is the problem
	
	ShowLogs(1, "Commented out");
	for(i = 0; i < 129; i++)
	{
		if ( NULL != isoMsg.field[i].ptr ) 
		{
			memset(dataStore, '\0', strlen(dataStore));
			DL_ISO8583_FIELD_DEF *fieldDef = DL_ISO8583_GetFieldDef(i, &isoHandler);
			sprintf(dataStore, "%s", isoMsg.field[i].ptr);
			switch(i)
			{
				case 0:
					memset(glRecvPack.szMsgCode, '\0', strlen(glRecvPack.szMsgCode));
					sprintf((char *)glRecvPack.szMsgCode, "%.*s", LEN_MSG_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szMsgCode);
					continue;
				case 1:
					memset(glRecvPack.sBitMap, '\0', strlen(glRecvPack.sBitMap));
					sprintf((char *)glRecvPack.sBitMap, "%.*s", 2*LEN_BITMAP, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.sBitMap);
					continue;
				case 2:
					memset(glRecvPack.szPan, '\0', strlen(glRecvPack.szPan));
					sprintf((char *)glRecvPack.szPan, "%.*s", LEN_PAN, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPan);
					continue;
				case 3:
					memset(glRecvPack.szProcCode, '\0', strlen(glRecvPack.szProcCode));
					sprintf((char *)glRecvPack.szProcCode, "%.*s", LEN_PROC_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szProcCode);
					continue;
				case 4:
					memset(glRecvPack.szTranAmt, '\0', strlen(glRecvPack.szTranAmt));
					sprintf((char *)glRecvPack.szTranAmt, "%.*s", LEN_TRAN_AMT, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTranAmt);
					continue;
				case 7:
					memset(glRecvPack.szFrnAmt, '\0', strlen(glRecvPack.szFrnAmt));
					sprintf((char *)glRecvPack.szFrnAmt, "%.*s", LEN_FRN_AMT, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szFrnAmt);
					continue;
				case 11:
					memset(glRecvPack.szSTAN, '\0', strlen(glRecvPack.szSTAN));
					sprintf((char *)glRecvPack.szSTAN, "%.*s", LEN_STAN, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szSTAN);
					continue;
				case 12:
					memset(glRecvPack.szLocalTime, '\0', strlen(glRecvPack.szLocalTime));
					sprintf((char *)glRecvPack.szLocalTime, "%.*s", LEN_LOCAL_TIME, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szLocalTime);
					continue;
				case 13:
					memset(glRecvPack.szLocalDate, '\0', strlen(glRecvPack.szLocalDate));
					sprintf((char *)glRecvPack.szLocalDate, "%.*s", LEN_LOCAL_DATE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szLocalDate);
					continue;
				case 14:
					memset(glRecvPack.szExpDate, '\0', strlen(glRecvPack.szExpDate));
					sprintf((char *)glRecvPack.szExpDate, "%.*s", LEN_EXP_DATE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szExpDate);
					continue;//ok
				case 15:
					memset(glRecvPack.szSetlDate, '\0', strlen(glRecvPack.szSetlDate));
					sprintf((char *)glRecvPack.szSetlDate, "%.*s", LEN_LOCAL_DATE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szSetlDate);
					continue;
				case 18:
					memset(glRecvPack.szMerchantType, '\0', strlen(glRecvPack.szMerchantType));
					sprintf((char *)glRecvPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szMerchantType);
					continue;
				case 22:
					memset(glRecvPack.szEntryMode, '\0', strlen(glRecvPack.szEntryMode));
					sprintf((char *)glRecvPack.szEntryMode, "%.*s", LEN_ENTRY_MODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szEntryMode);
					continue;
				case 23:
					memset(glRecvPack.szPanSeqNo, '\0', strlen(glRecvPack.szPanSeqNo));
					sprintf((char *)glRecvPack.szPanSeqNo, "%.*s", LEN_PAN_SEQ_NO, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPanSeqNo);
					continue;
				case 25:
					memset(glRecvPack.szCondCode, '\0', strlen(glRecvPack.szCondCode));
					sprintf((char *)glRecvPack.szCondCode, "%.*s", LEN_COND_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szCondCode);
					continue;
				case 28:
					memset(glRecvPack.szTransFee, '\0', strlen(glRecvPack.szTransFee));
					sprintf((char *)glRecvPack.szTransFee, "%.*s", LEN_TRANS_FEE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTransFee);
					continue;
				case 30:
					memset(glRecvPack.szTransFee, '\0', strlen(glRecvPack.szTransFee));
					sprintf((char *)glRecvPack.szTransFee, "%.*s", LEN_TRANS_FEE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTransFee);
					continue;
				case 32:
					memset(glRecvPack.szAqurId, '\0', strlen(glRecvPack.szAqurId));
					sprintf((char *)glRecvPack.szAqurId, "%.*s", LEN_AQUR_ID, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szAqurId);
					continue;
				case 33:
					memset(glRecvPack.szFwdInstId, '\0', strlen(glRecvPack.szFwdInstId));
					sprintf((char *)glRecvPack.szFwdInstId, "%.*s", LEN_AQUR_ID, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szFwdInstId);
					continue;
				case 35:
					memset(glRecvPack.szTrack2, '\0', strlen(glRecvPack.szTrack2));
					sprintf((char *)glRecvPack.szTrack2, "%.*s", LEN_TRACK2, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTrack2);
					continue;
				case 37:
					memset(glRecvPack.szRRN, '\0', strlen(glRecvPack.szRRN));
					sprintf((char *)glRecvPack.szRRN, "%.*s", LEN_RRN, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szRRN);
					continue;
				case 38:
					memset(glRecvPack.szAuthCode, '\0', strlen(glRecvPack.szAuthCode));
					sprintf((char *)glRecvPack.szAuthCode, "%.*s", LEN_AUTH_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szAuthCode);
					continue;
				case 39:
					memset(glRecvPack.szRspCode, '\0', strlen(glRecvPack.szRspCode));
					sprintf((char *)glRecvPack.szRspCode, "%.*s", LEN_RSP_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szRspCode);
					continue;
				case 40:
					memset(glRecvPack.szServResCode, '\0', strlen(glRecvPack.szServResCode));
					sprintf((char *)glRecvPack.szServResCode, "%.*s", LEN_SRES_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szServResCode);
					continue;
				case 41:
					memset(glRecvPack.szTermID, '\0', strlen(glRecvPack.szTermID));
					sprintf((char *)glRecvPack.szTermID, "%.*s", LEN_TERM_ID, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTermID);
					continue;
				case 42:
					memset(glRecvPack.szMerchantID, '\0', strlen(glRecvPack.szMerchantID));
					sprintf((char *)glRecvPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szMerchantID);
					continue;
				case 43:
					memset(glRecvPack.szMNL, '\0', strlen(glRecvPack.szMNL));
					sprintf((char *)glRecvPack.szMNL, "%.*s", LEN_MNL, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szMNL);
					continue;
				case 49:
					memset(glRecvPack.szTranCurcyCode, '\0', strlen(glRecvPack.szTranCurcyCode));
					sprintf((char *)glRecvPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTranCurcyCode);
					continue;
				case 54:
					memset(glRecvPack.szAddtAmount, '\0', strlen(glRecvPack.szAddtAmount));
					sprintf((char *)glRecvPack.szAddtAmount, "%.*s", LEN_ADDT_AMT, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szAddtAmount);
					continue;
				case 55:
					memset(glRecvPack.sICCData, '\0', strlen(glRecvPack.sICCData));
					sprintf((char *)glRecvPack.sICCData, "%.*s", LEN_ICC_DATA, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.sICCData);
					continue;
				case 59:
					memset(glRecvPack.szTEchoData, '\0', strlen(glRecvPack.szTEchoData));
					sprintf((char *)glRecvPack.szTEchoData, "%.*s", LEN_TRANSECHO_DATA, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szTEchoData);
					continue;
				case 60:
					memset(glRecvPack.szPayMentInfo, '\0', strlen(glRecvPack.szPayMentInfo));
					sprintf((char *)glRecvPack.szPayMentInfo, "%.*s", LEN_PAYMENT_INFO, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPayMentInfo);
					continue;
				case 102:
					memset(glRecvPack.szActIdent1, '\0', strlen(glRecvPack.szActIdent1));
					sprintf((char *)glRecvPack.szActIdent1, "%.*s", LEN_ACT_IDTF, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szActIdent1);
					continue;
				case 103:
					memset(glRecvPack.szActIdent2, '\0', strlen(glRecvPack.szActIdent2));
					sprintf((char *)glRecvPack.szActIdent2, "%.*s", LEN_ACT_IDTF, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szActIdent2);
					continue;
				case 123:
					memset(glRecvPack.szPosDataCode, '\0', strlen(glRecvPack.szPosDataCode));
					sprintf((char *)glRecvPack.szPosDataCode, "%.*s", LEN_POS_CODE, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPosDataCode);
					continue;
				case 124:
					memset(glRecvPack.szPayMentInfo, '\0', strlen(glRecvPack.szPayMentInfo));
					sprintf((char *)glRecvPack.szPayMentInfo, "%.*s", LEN_PAYMENT_INFO, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szPayMentInfo);
					continue;
				case 128:
					memset(glRecvPack.szNFC, '\0', strlen(glRecvPack.szNFC));
					sprintf((char *)glRecvPack.szNFC, "%.*s", LEN_NEARFIELD, dataStore);
					ShowLogs(1, "Field %d: %s", i, glRecvPack.szNFC);
					continue;
				default:
					continue;
			}
		}
	}
	ShowLogs(1, "Reversal Response Code: %s", glRecvPack.szRspCode);
	if(strstr(glRecvPack.szRspCode, "00") != NULL)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "SUCCESSFUL", 3);
	}else if(strstr(glRecvPack.szRspCode, "25") != NULL)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "SUCCESSFUL", 3);
	}else
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "NOT SUCCESSFUL", 3);
	}
	if((txnType != 5) && (iLen != 36) && (strlen(glRecvPack.szRspCode) == 2))
    {
    	storeTxn();
		storeEod();
		//storeEodDuplicate();
    }


	sprintf((char *)glProcInfo.stTranLog.szRspCode, "%.2s", glRecvPack.szRspCode);
	UpdateLocalTime(NULL, glRecvPack.szLocalDate, glRecvPack.szLocalTime);
	GetDateTime(szLocalTime);
	sprintf((char *)glProcInfo.stTranLog.szDateTime, "%.14s", szLocalTime);
	sprintf((char *)glProcInfo.stTranLog.szAuthCode, "%.6s", glRecvPack.szAuthCode);
	sprintf((char *)glProcInfo.stTranLog.szRRN, "%.12s", glRecvPack.szRRN);
	sprintf((char *)glProcInfo.stTranLog.szCondCode,  "%.2s",  glSendPack.szCondCode);
	sprintf((char *)glProcInfo.stTranLog.szFrnAmount, "%.12s", glRecvPack.szFrnAmt);
	FindCurrency(glRecvPack.szHolderCurcyCode, &glProcInfo.stTranLog.stHolderCurrency);
	strcpy(glProcInfo.stTranLog.szPan, glSendPack.szPan);
	sprintf((char *)glProcInfo.stTranLog.szExpDate, "%.4s", glSendPack.szExpDate);
	strcpy(glProcInfo.stTranLog.szAmount, glSendPack.szTranAmt);
	

	/* free ISO message */
	DL_ISO8583_MSG_Free(&isoMsg);
	return 0;
}