#ifndef _RECEIPT_H
#define _RECEIPT_H


void PrintAllReceipt(uchar ucPrnFlag);
void reprintDataNormal();
void MaskAllPan(char *pan, char *mskPan);
int PrintValidation(uchar ucPrnFlag, char *name);
void storeprint();
extern int ext;
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _GLOBAL_H