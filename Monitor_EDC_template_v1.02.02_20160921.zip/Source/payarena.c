#include "global.h"

ISOTid	tidIso;

struct BREAKDOWN
{
  char step[128];
  char id[128];
  char text[128];
  char type[128];
  char backid[128];
  char backname[128];
};

void parseLineData(char *line, struct BREAKDOWN data[], int count)
{
    int iLen = 0;
	int i, j = 0, loop = 0;
	char name[128] = {0};
	iLen = strlen(line);
	memset(name, '\0', strlen(name));
	for(i = 0; i < iLen; i++)
    {
        if(loop == 0)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].step, '\0', strlen(data[count].step));
                        strncpy(data[count].step, name + 7, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 1)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].id, '\0', strlen(data[count].id));
                        strncpy(data[count].id, name + 5, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 2)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].text, '\0', strlen(data[count].text));
                        strncpy(data[count].text, name + 7, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 3)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].type, '\0', strlen(data[count].type));
                        strncpy(data[count].type, name + 7, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 4)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].backid, '\0', strlen(data[count].backid));
                        strncpy(data[count].backid, name + 9, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 5)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].backname, '\0', strlen(data[count].backname));
                        strncpy(data[count].backname, name + 11, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }
    }
}

static int jsoneqq(const char *json, jsmntok_t *tok, const char *s) {
	if (tok->type == JSMN_STRING && (int) strlen(s) == tok->end - tok->start &&
			strncmp(json + tok->start, s, tok->end - tok->start) == 0) {
		return 0;
	}
	return -1;
}

void PayArenaEngine()
{
	char menu[100 * 1024] = {0};
	int iRet, i, r;
	char line[1028] = {0};
    int count = 0;
    struct BREAKDOWN data[248];
    int j, k;
    int next, previous;
	jsmn_parser p;
	jsmntok_t t[300];
	char storeData[200 * 1024] = {0};
	char billers[200 * 1024] = {0};
	char flows[200 * 1024] = {0};
	char billsNames[1024] = {0};
	char startid[128] = {0};
    char startname[128] = {0};
    char backid[128] = {0};
    char backname[128] = {0};
    char type[128] = {0};
    char step[128] = {0};


    int iMenuNo, iRev = 0;
	ST_EVENT_MSG stEventMsg;
	uchar key = 0;
	int chk = 0;
	char pin[25] = {0};
	GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
	char txnName1[20][128];
	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	numLines = 6;


	memset(&glSendPack, 0, sizeof(STISO8583));//By wisdom
	memset(glProcInfo.stTranLog.szAmount, '\0', strlen(glProcInfo.stTranLog.szAmount));
	

	ReadAllData("bMenu.txt", menu);
	//ShowLogs(1, "%s", menu);
	jsmn_init(&p);
	r = jsmn_parse(&p, menu, strlen(menu), t, sizeof(t)/sizeof(t[0]));
	if (r < 0) 
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "PAYARENA ERROR 1", 4);
		//ShowLogs(1, "Failed to parse JSON: %d", r);
		return;
	}

	//ShowLogs(1, "menu Length Gotten: %d", strlen(menu));

	if (r < 1 || t[0].type != JSMN_OBJECT) 
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "PAYARENA ERROR 2", 4);
		ShowLogs(1, "Object expected.");
		return 1;
	}

	for (i = 1; i < r; i++) 
	{
		if (jsoneqq(menu, &t[i], "billsmenuname") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s", t[i+1].end-t[i+1].start, menu + t[i+1].start);
			strcpy(billsNames, storeData);
			i++;
		} else if (jsoneqq(menu, &t[i], "billers") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, menu + t[i+1].start);
			strcpy(billers, storeData);
			i++;
		} else if (jsoneqq(menu, &t[i], "flow") == 0) {
			memset(storeData, '\0', strlen(storeData));
			sprintf(storeData, "%.*s\n", t[i+1].end-t[i+1].start, menu + t[i+1].start);
			strcpy(flows, storeData);
			i++;
		}else
		{
			////ShowLogs(1, "Unexpected key: %.*s\n", t[i].end-t[i].start, menu + t[i].start);
		}
	}

	//ShowLogs(1, "Length of Flow: %d", strlen(flows));
	//ShowLogs(1, "Length of Billers: %d", strlen(billers));

	for(i = 0; i < strlen(flows); i++)
    {
        j = 0;
        k = 0;
        memset(line, '\0', strlen(line));
        for(j = 0; i < strlen(flows); j++, k++, i++)
        {
            if((flows[i] == ',') && (flows[i + 1] == 's'))
            {
                break;
            }else
            {
                line[k] = flows[i];
            }
        }
        parseLineData(line, data, count);
        count++;
    }

    next = 0;
    previous = 0;
    while(1)
    {
    	key = 0;
    	iMenuItemNum = 0;
    	for(i = 0; i < 20; i++)
    	{
    		memset(txnName1[i], '\0', sizeof(txnName1[i]));
    	}
	    memset(step, '\0', strlen(step));
	    strcpy(step, data[next].step);
	    memset(startid, '\0', strlen(startid));
	    strcpy(startid, data[next].id);
	    memset(startname, '\0', strlen(startname));
	    strcpy(startname, data[next].text);
	    memset(type, '\0', strlen(type));
	    strcpy(type, data[next].type);
	    memset(backid, '\0', strlen(backid));
	    strcpy(backid, data[next].backid);
	    memset(backname, '\0', strlen(backname));
	    strcpy(backname, data[next].backname);

	    ShowLogs(1, "Oga: %s.", data[next].text);

	    if(strstr(type, "default") != NULL)
	    {
	        ShowLogs(1, "Inside Default. BackId: %s", backid);
		    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", data[next].text);
		    stDefTranMenuItem1[key].nValue = key;
		    stDefTranMenuItem1[key].bVisible = TRUE;
		    strncpy(txnName1[key], data[next].text, strlen(data[next].text));
		    key++;
	    }else if(strstr(type, "biller") != NULL)
	    {
	    	ShowLogs(1, "Inside Biller. BackId: %s", backid);
	    	ShowLogs(1, "Inside Biller. Name: %s", backname);
	    	for(i = 0; i < count; i++)
	        {
	        	ShowLogs(1, "Backname: %s. BackId: %s", data[i].backname, data[i].backid);
	            if((strstr(backid, data[i].backid) != NULL)
	            	&& (strstr(backname, data[i].backname) != NULL))
	            {
	            	ShowLogs(1, "%s", data[i].text);
	                sprintf((char *)stDefTranMenuItem1[key].szText, "%s", data[i].text);
				    stDefTranMenuItem1[key].nValue = key;
				    stDefTranMenuItem1[key].bVisible = TRUE;
				    strncpy(txnName1[key], data[i].text, strlen(data[i].text));
				    key++;
	            }
	        }
	    }else
	    {
	    	ShowLogs(1, "Inside Category. BackId: %s", backid);
	    	ShowLogs(1, "Inside Category. Name: %s", startname);
	        for(i = 0; i < count; i++)
	        {
	            if(strstr(backid, data[i].backid) != NULL)
	            {
	                ShowLogs(1, "%s", data[i].text);
	                sprintf((char *)stDefTranMenuItem1[key].szText, "%s", data[i].text);
				    stDefTranMenuItem1[key].nValue = key;
				    stDefTranMenuItem1[key].bVisible = TRUE;
				    strncpy(txnName1[key], data[i].text, strlen(data[i].text));
				    key++;
	            }
	        }
	    }

	    //ShowLogs(1, "Keys Value: %d", key);
	    for(i = 0; i < key; ++i)
	    {
	        if(stDefTranMenuItem1[i].bVisible)
	        {
	        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
	            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
	            //ShowLogs(1, "1. Display Memory Leaks: %s.", stTranMenuItem[iMenuItemNum].szText);
	            ++iMenuItemNum;
	        }
	    }

	    stTranMenuItem[iMenuItemNum].szText[0] = 0;
	    //ShowLogs(1, "2. Display Memory Leaks: %s.", stTranMenuItem[iMenuItemNum].szText);

		Gui_BindMenu(billsNames, gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
		
		Gui_ClearScr();
		iMenuNo = 0;
		iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, 1000, &iMenuNo);
		if(GUI_OK == iRet)
		{
			checkBoard = 0;
			ShowLogs(1, "1. Menu Item clicked is: %s", txnName1[iMenuNo]);
			previous = next;
			//Check for biller here
			for(i = 0; i < count; i++)
		    {
		    	if(strstr(txnName1[iMenuNo], data[i].text) != NULL)
		    	{
		    		if(strstr(data[i].type, "biller") != NULL)
		    		{
		    			Beep();
		    			MainProcessBiller(txnName1[iMenuNo], billers);
		    			return;
		    		}
		    	}
		    }

			for(i = 0; i < count; i++)
		    {
		    	if(strstr(txnName1[iMenuNo], data[i].backname) != NULL)
		    	{
		    		next = i;
		    		ShowLogs(1, "Value of Next: %d. Backname: %s", next, data[i].backname);
		    		Gui_ClearScr();
		    		break;
		    	}
		    }
		}else if(GUI_ERR_TIMEOUT == iRet)
		{
			Gui_ClearScr();
			next = 0;
			previous = 0;
			break;
		}else if(GUI_ERR_USERCANCELLED == iRet)
		{
			ShowLogs(1, "Value of Next: %d. Previous: %d", next, previous);
			Gui_ClearScr();
			break;
			/*if(previous == 0)
			{
				Gui_ClearScr();
				break;
			}
			Gui_ClearScr();
			next = previous;
			continue;*/
		}else
		{
			Gui_ClearScr();
			break;
		}
	}
}