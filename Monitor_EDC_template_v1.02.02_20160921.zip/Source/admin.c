#include "global.h"

int adPinflag = 0;

int adminFunc()
{
	int iRet = 0, iMenuNo, iRev = 0;
	ST_EVENT_MSG stEventMsg;
	uchar key = 0;
	int chk = 0;
	char pin[25] = {0};
	GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
	char txnName1[20][128];
	int iTemp = 0;
	char temp[5] = {0};
	char tempp[128] = {0};
	char sStore[100] = {0};
	uchar k;

	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	int i;

	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 0;
	stInputAttr.nMinLen = 4;
	stInputAttr.nMaxLen = 20;
	stInputAttr.bSensitive = 1;

	if(adPinflag == 0)
	{
		memset(pin, '\0', strlen(pin));
		Gui_ClearScr();
		iRet = Gui_ShowInputBox("UNIFIED PAYMENTS", gl_stTitleAttr, _T("ADMIN PIN"), gl_stLeftAttr,
			pin, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
		if( iRet!=GUI_OK ){
			return 0;
		}
		memset(sStore, '\0', strlen(sStore));
		UtilGetEnv("adminpin", sStore);

		ShowLogs(1, "pin: %s", pin);
		ShowLogs(1, "store pin: %s", sStore);

		if(strncmp(pin, sStore, strlen(sStore)) != 0)
		{
			DisplayInfoNone("UNIFIED PAYMENTS", "WRONG PIN", 2);
			return 0;
		}
	}

	adPinflag = 1;
	numLines = 6;

	ShowLogs(1, "1. Enable Tid Change: %s", tidIso.enabletid);
	if(strstr(tidIso.enabletid, "true") != NULL)
	{
		sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "SET TERMINAL ID");
	    stDefTranMenuItem1[key].nValue = key;
	    stDefTranMenuItem1[key].bVisible = TRUE;
	    strncpy(txnName1[key], "SET TERMINAL ID", strlen("SET TERMINAL ID"));
	    key++;
	}

    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "DOWNLOAD KEYS");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "DOWNLOAD KEYS", strlen("DOWNLOAD KEYS"));
    key++;
    
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "DOWNLOAD PROFILE");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "DOWNLOAD PROFILE", strlen("DOWNLOAD PROFILE"));
    key++;
    
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "WIFI SETTINGS");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "WIFI SETTINGS", strlen("WIFI SETTINGS"));
    key++;

    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "MANAGE BARCODE");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "MANAGE BARCODE", strlen("MANAGE BARCODE"));
    key++;
    
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "SHOW LOGS");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "SHOW LOGS", strlen("SHOW LOGS"));
    key++;
    
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "PRINT DETAILS");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "PRINT DETAILS", strlen("PRINT DETAILS"));
    key++;

    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "UPDATE KEYS");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "UPDATE KEYS", strlen("UPDATE KEYS"));
    key++;

    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "DWN RPT LOGO");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "DWN RPT LOGO", strlen("DWN RPT LOGO"));
    key++;

    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "DWN BKG LOGO");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "DWN BKG LOGO", strlen("DWN BKG LOGO"));
    key++;

    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "GET UPDATES");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "GET UPDATES", strlen("GET UPDATES"));
    key++;

	for(i = 0; i <= key; ++i)
    {
        if(stDefTranMenuItem1[i].bVisible)
        {
        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
            ++iMenuItemNum;
        }
    }

    stTranMenuItem[iMenuItemNum].szText[0] = 0;

	Gui_BindMenu("UNIFIED PAYMENTS", gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
	
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
	if(GUI_OK == iRet)
	{
		checkBoard = 0;
		if(strncmp(txnName1[iMenuNo], "SET TERMINAL ID", 15) == 0)
		{
			changeProfileID();
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "DOWNLOAD KEYS", 13) == 0)
		{
			downloadKeys();
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "DOWNLOAD PROFILE", 16) == 0)
		{
			downProfile();
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "WIFI SETTINGS", 13) == 0)
		{
			wifiSetup();
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "MANAGE BARCODE", 14) == 0)
		{
			memset(sStore, '\0', strlen(sStore));
			UtilGetEnv("rptsbarcode", sStore);
			if(strstr(sStore, "true") != NULL)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "TURN OFF BARCODE?", 1);
			}else
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "TURN ON BARCODE?", 1);
			}
			kbflush();
			while(1)
			{
				if( 0==kbhit() )
				{
					Beep();
					k = getkey();
					if(KEYCANCEL == k)
					{
						break;
					}else if(KEYENTER == k)
					{
						if(strstr(sStore, "true") != NULL)
							UtilPutEnv("rptsbarcode", "false");
						else
							UtilPutEnv("rptsbarcode", "true");
					}
					break;
				}
				DelayMs(200);
			}
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "SHOW LOGS", 9) == 0)
		{
			if(DisplayLogsCheck)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "TURN OFF LOGS?", 1);
			}else
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "TURN ON LOGS?", 1);
			}
			kbflush();
			while(1)
			{
				if( 0==kbhit() )
				{
					Beep();
					k = getkey();
					if(KEYCANCEL == k)
					{
						break;
					}else if(KEYENTER == k)
					{
						if(DisplayLogsCheck)
							DisplayLogsCheck = 0;
						else
							DisplayLogsCheck = 1;
					}
					break;
				}
				DelayMs(200);
			}
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "PRINT DETAILS", 13) == 0)
		{
			printDetails();
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "UPDATE KEYS", 11) == 0)
		{
			schemeKeysDownload();
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "DWN RPT LOGO", 12) == 0)
		{
			logoDownload(1);
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "DWN BKG LOGO", 12) == 0)
		{
			logoDownload(0);
			adminFunc();
		}else if(strncmp(txnName1[iMenuNo], "GET UPDATES", 11) == 0)
		{
			checkForNewApp();
			adminFunc();
		}

		Gui_ClearScr();
		return iRet;
	}
	adPinflag = 0;
	return 0;
}