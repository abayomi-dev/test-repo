
#ifndef _BILLERS_H
#define _BILLERS_H



#ifdef __cplusplus
extern "C" {
#endif 

void MainProcessBiller(char *biller, char *billers);

struct BILLERS
{
  char billername[128];
  char printall[128];
  char vendorid[128];
  char istoken[128];
  char conveniencefee[128];
  char printvalidation[128];
};

struct LABELS
{
  char labelname[128];
  char value[28];
  char inputtype[128];
  char lengthrule[128];
  char revalidate[128];
  char capturetoken[128];
  char printvalue[128];
};

struct PRODUCTS
{
  char productname[128];
  char value[128];
};

struct GOTDATA
{
	char labelname[128];
	char value[28];
	char inputtype[128];
	char lengthrule[128];
	char revalidate[128];
	char capturetoken[128];
	char printvalue[128];
};

int getMin(char *rule);
int getMax(char *rule);
int getLabelInputtype(char *type, char *input);
void getConvenienceFee(char *confee, char *fee);
extern int dispVal;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
