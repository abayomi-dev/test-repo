
#ifndef _MANENTRY_H
#define _MANENTRY_H


#ifdef __cplusplus
extern "C" {
#endif 

int manualEntry();
extern int manflag;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
