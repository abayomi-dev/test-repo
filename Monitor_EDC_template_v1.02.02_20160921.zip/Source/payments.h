
#ifndef _PAYMENTS_H
#define _PAYMENTS_H


#ifdef __cplusplus
extern "C" {
#endif 

void PaymentsEngine();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
