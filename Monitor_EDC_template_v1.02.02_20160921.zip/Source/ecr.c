#include "global.h"

char ucRet2 = 0x03;
int cecr = 0;
int checkEcr = 0;

#define TIMER_TEMPORARYECR		4
#define TIMERCNT_MAXECR		48000

uchar ChkIdleTimerEcr(int iSeconds)
{
	int	iCnt = TIMERCNT_MAXECR-TimerCheck(TIMER_TEMPORARYECR);
	return (iCnt >= iSeconds*10);
}

void SetIdleTimerEcr(void)
{
	TimerSet(TIMER_TEMPORARYECR, TIMERCNT_MAXECR);
}

void OpenPort() 
{
	if (ucRet2 != 0x00) 
	{
		ucRet2 = PortOpen(0, (unsigned char *)"115200,8,n,1");
	}
}

int OpenRxd(uchar *psRxdData, ushort uiExpLen, ushort *puiOutLen)
{
	uchar   ucRet;
	ushort	uiReadCnt, uiTemp;
	uchar	szEngTime[16+1];
	uiReadCnt = uiTemp = 0;
	char store_env[120] = {0};
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;

	kbflush();

	while( uiReadCnt<uiExpLen )
	{
		ucRet = PortRecv(0, psRxdData, uiTemp);
		if( ucRet==0x00 )
		{	
			uiTemp = 80;
			psRxdData++;
			uiReadCnt++;
		}
		else if( ucRet==0xFF )
		{
			if( uiReadCnt>0 )
			{
				break;
			}
		}
		else
		{	
			break;
		}

		GetEngTime(szEngTime);
		Gui_DrawText(szEngTime, stTextAttr, 12, 75);
		DelayMs(10);

		memset(store_env, '\0', strlen(store_env));
        UtilGetEnv("chinterval", store_env);
        if (ChkIdleTimerEcr(atoi(store_env)))
        {
        	DisplayInfoNone("UNIFIED PAYMENTS", "PERFORMING CALLHOME", 2);
			PackCallHomeData();
        	Gui_ClearScr();
        	TransOther();
        }

        if (kbhit()==0) 
		{ 
			if(getkey()==KEYCANCEL)
			{
				cecr = 1;
				Beep();
				return 1;
			}
		}
	}

	if( puiOutLen!=NULL )
	{
		*puiOutLen = uiReadCnt;
	}
	return 0;
}

int parseEcrData(char* data)
{
	int iRet, i, loop = 0, j = 0, iLen;
	char temp[128] = {0};
	char len[5] = {0};
	char len2[5] = {0};
	int iLen2;

	memset(len2, '\0', strlen(len2));
	strncpy(len2, data, 4);
	iLen2 = atoi(len2);

	for(i = 0; i < iLen2; i++)
	{
		if(loop == 0)
		{
			if(data[i] == '|' || data[i] == 28)
			{
				loop++;
				j = 0;
				strncpy(ecrModeData.sMsgLen, temp, 4);
				strncpy(ecrModeData.sMsgType, temp+4, 1);
				memset(temp, '\0', strlen(temp));
			}else
			{
				temp[j] = data[i];
				j++;
			}
		}else if(loop == 1)
		{
			if(data[i] == '|' || data[i] == 28)
			{
				loop++;
				j = 0;
				memset(len, '\0', strlen(len));
				strncpy(len, temp, 2);
				iLen = atoi(len);
				strncpy(ecrModeData.sAudNum, temp+2, iLen);
				memset(temp, '\0', strlen(temp));
			}else
			{
				temp[j] = data[i];
				j++;
			}
		}else if(loop == 2)
		{
			if(data[i] == '|' || data[i] == 28)
			{
				loop++;
				j = 0;
				memset(len, '\0', strlen(len));
				strncpy(len, temp, 2);
				iLen = atoi(len);
				strncpy(ecrModeData.sEcrId, temp+2, iLen);
				memset(temp, '\0', strlen(temp));
			}else
			{
				temp[j] = data[i];
				j++;
			}
		}else if(loop == 3)
		{
			if(data[i] == '|' || data[i] == 28)
			{
				loop++;
				j = 0;
				memset(len, '\0', strlen(len));
				strncpy(len, temp, 2);
				iLen = atoi(len);
				strncpy(ecrModeData.sdatetime, temp+2, iLen);
				memset(temp, '\0', strlen(temp));
			}else
			{
				temp[j] = data[i];
				j++;
			}
		}else if(loop == 4)
		{
			if(data[i] == '|' || data[i] == 28)
			{
				loop++;
				j = 0;
				memset(len, '\0', strlen(len));
				strncpy(len, temp, 2);
				iLen = atoi(len);
				strncpy(ecrModeData.sAmount, temp+2, iLen);
				memset(temp, '\0', strlen(temp));
			}else
			{
				temp[j] = data[i];
				j++;
			}
		}else if(loop == 5)
		{
			if(data[i] == '|' || data[i] == 28)
			{
				loop++;
				j = 0;
				memset(len, '\0', strlen(len));
				strncpy(len, temp, 2);
				iLen = atoi(len);
				strncpy(ecrModeData.sCurr, temp+2, iLen);
				memset(temp, '\0', strlen(temp));
			}else
			{
				temp[j] = data[i];
				j++;
			}
		}else if(loop == 6)
		{
			if(data[i] == '|' || data[i] == 28)
			{
				loop++;
				j = 0;
				memset(len, '\0', strlen(len));
				strncpy(len, temp, 2);
				iLen = atoi(len);
				strncpy(ecrModeData.sTxt, temp+2, iLen);
				memset(temp, '\0', strlen(temp));
			}else
			{
				temp[j] = data[i];
				j++;
			}
		}
	}
	return atoi(ecrModeData.sMsgType);
}

int ecrPurchase()
{
	int iRet = 0, iMenuNo, iRev = 0;
	ST_EVENT_MSG stEventMsg;
	uchar key = 0;
	int chk = 0;
	char pin[25] = {0};
	GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
	char txnName1[20][128];
	int iTemp = 0;
	char temp[5] = {0};
	char sStore[100] = {0};
	uchar k;

	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	int i;

	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	
	numLines = 6;

	sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "CARD");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "CARD", strlen("CARD"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "PAYATTITUDE");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "PAYATTITUDE", strlen("PAYATTITUDE"));

	for(i = 0; i < 2; ++i)
    {
        if(stDefTranMenuItem1[i].bVisible)
        {
        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
            ++iMenuItemNum;
        }
    }

    stTranMenuItem[iMenuItemNum].szText[0] = 0;

	Gui_BindMenu("UNIFIED PAYMENTS", gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
	
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
	if(GUI_OK == iRet)
	{
		checkBoard = 0;
		if(strncmp(txnName1[iMenuNo], "CARD", 4) == 0)
		{
			setHostDetails("PAY ALL CARDS");
			TransPurchase();
		}else if(strncmp(txnName1[iMenuNo], "PAYATTITUDE", 11) == 0)
		{
			setHostDetails("PAYATTITUDE");
			payAttitude();
		}
		Gui_ClearScr();
		return iRet;
	}else if(GUI_ERR_USERCANCELLED == iRet || GUI_ERR_TIMEOUT == iRet)
		return 1;
	return 0;
}

void ecrEntrance()
{
	int iRet = 0, iLen;
	ST_EVENT_MSG stEventMsg;
	uchar key;
	int chk = 0;
	char ecr[256] = {0};
	char send[1024] = {0};
	char sendFin[1024] = {0};
	char temp[128] = {0};
	char sBuf[128] = {0};
	//char try[] = "02501|040000|35Approved or completed successfully|09001473012|08ILTILL12|082UP13777|0239|1420171130133812|12Contact chip|06Online|00|16539983******4354|12000000000101|16Debit MasterCard|06400535|17BOLAJI/OLUWATOSIN|00|042005|12000000398360|12000000000000";

	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	//glProcInfo.stTranLog.ucTranType = SALE;

	DisplayInfoNone("UNIFIED PAYMENTS", "ECR MODE", 0);
	memset(&ecrModeData, 0, sizeof(ECRISO));
	checkEcr = 0;

	DisplayLogsCheck = 0; //Turn off logs
	txnType = 13;
	restart:
	OpenPort();
	SetIdleTimerEcr();//For timer
	memset(ecr, '\0', strlen(ecr));
	iRet = OpenRxd(ecr, 100, &iLen);
	if(cecr)
	{
		ucRet2 = 0x03;
		//DelayMs(50);
		PortClose(0);
	}else
	{
		//Beep();
		ucRet2 = 0x03;
		PortClose(0);
		if(ecr[4] == '7')
		{
			OpenPort();
			PortSends(0, (unsigned char *)ecr, strlen(ecr));
			ucRet2 = 0x03;
			//DelayMs(50);
			PortClose(0);
			goto restart;			
		}else
		{
			ScrBackLight(1);
			//iRet = parseEcrData(ecr);//Commented out by Wisdom
			/*DisplayInfoNone("UNIFIED PAYMENTS", ecrModeData.sAudNum, 5);
			DisplayInfoNone("UNIFIED PAYMENTS", ecrModeData.sEcrId, 5);
			DisplayInfoNone("UNIFIED PAYMENTS", ecrModeData.sdatetime, 5);
			DisplayInfoNone("UNIFIED PAYMENTS", ecrModeData.sAmount, 5);

			/*
			//Start Delete - working
			DisplayInfoNone("UNIFIED PAYMENTS", "SENDING BACK RESPONSE", 0);
			Beep();
			OpenPort();
			PortSends(0, (unsigned char *)try, strlen(try));
			ucRet2 = 0x03;
			PortClose(0);
			ecrEntrance();
			//End Delete - working
			*/


			iRet = parseEcrData(ecr);
			if(iRet == 1)
			{
				//For Purchase
				checkEcr = 1;
				memset(send, '\0', strlen(send));
				memset(sendFin, '\0', strlen(sendFin));
				memset(temp, '\0', strlen(temp));
				DisplayInfoNone("UNIFIED PAYMENTS", "PROCESSING REQUEST", 0);
				if(ecrPurchase() == 1)
				{
					//User canceled
					strcpy(send, "1|");
					memset(temp, '\0', strlen(temp));
					strcat(send, "040099|");
					strcat(send, "13USER CANCELED|");
					memset(temp, '\0', strlen(temp));
					sprintf(temp, "%.2d%s|", strlen(ecrModeData.sAudNum), ecrModeData.sAudNum);
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					sprintf(temp, "%.2d%s|", strlen(ecrModeData.sEcrId), ecrModeData.sEcrId);
					strcat(send, temp);
					memset(sBuf, '\0', strlen(sBuf));
					memset(temp, '\0', strlen(temp));
					UtilGetEnvEx("tid", sBuf);
					sprintf(temp, "%.2d%s|", strlen(sBuf), sBuf);
					strcat(send, temp);
					memset(sBuf, '\0', strlen(sBuf));
					memset(temp, '\0', strlen(temp));
					ReadAllData("count.txt", sBuf);
					sprintf(temp, "%.2d%s|", strlen(sBuf), sBuf);
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					sprintf(temp, "%.2d%s|", strlen(ecrModeData.sdatetime), ecrModeData.sdatetime);
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "12Contact Chip|");
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "07Offline|00|00|");//Pan is the last
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "00|");//Rrn
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "00|");//App Label
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "00|");//Auth Code
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "00|");//Card Holder Name
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "00|");
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "00|");//Expiry Date
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					sprintf(temp, "%.2d%s|", strlen(ecrModeData.sAmount), ecrModeData.sAmount);
					strcat(send, temp);
					memset(temp, '\0', strlen(temp));
					strcpy(temp, "12000000000000");
					strcat(send, temp);
				}else
				{
					if(revFlag)
					{
						//failed due to key exchange
						strcpy(send, "1|");
						memset(temp, '\0', strlen(temp));
						strcat(send, "040099");
						strcat(send, "20PLEASE ATTEMPT AGAIN");
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(ecrModeData.sAudNum), ecrModeData.sAudNum);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(ecrModeData.sEcrId), ecrModeData.sEcrId);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glSendPack.szTermID), glSendPack.szTermID);
						strcat(send, temp);
						memset(sBuf, '\0', strlen(sBuf));
						memset(temp, '\0', strlen(temp));
						ReadAllData("count.txt", sBuf);
						sprintf(temp, "%.2d%s|", strlen(sBuf), sBuf);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(ecrModeData.sdatetime), ecrModeData.sdatetime);
						strcat(send, temp);
						if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
						{
							memset(temp, '\0', strlen(temp));
							strcpy(temp, "12Contact Chip|");
							strcat(send, temp);
						}else
						{
							memset(temp, '\0', strlen(temp));
							strcpy(temp, "12Manual Input|");
							strcat(send, temp);
						}
						memset(temp, '\0', strlen(temp));
						strcpy(temp, "06Online|00|");
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						memset(sBuf, '\0', strlen(sBuf));
						MaskAllPan(glSendPack.szPan, sBuf);
						sprintf(temp, "%.2d%s|", strlen(sBuf), sBuf);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glRecvPack.szRRN), glRecvPack.szRRN);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glProcInfo.stTranLog.szAppLabel), glProcInfo.stTranLog.szAppLabel);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glProcInfo.stTranLog.szAuthCode), glProcInfo.stTranLog.szAuthCode);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glProcInfo.stTranLog.szHolderName), glProcInfo.stTranLog.szHolderName);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						strcpy(temp, "00|");
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glSendPack.szExpDate), glSendPack.szExpDate);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glSendPack.szTranAmt), glSendPack.szTranAmt);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						strcpy(temp, "12000000000000");
						strcat(send, temp);
					}else
					{
						//Normal Transaction
						strcpy(send, "1|");
						if(strlen(glRecvPack.szRspCode))
						{
							memset(temp, '\0', strlen(temp));
							sprintf(temp, "%.2d00%s|", strlen(glRecvPack.szRspCode), glRecvPack.szRspCode);
							strcat(send, temp);
							memset(temp, '\0', strlen(temp));
							memset(sBuf, '\0', strlen(sBuf));
							getResponse(glRecvPack.szRspCode, sBuf);
							sprintf(temp, "%.2d%s|", strlen(sBuf), sBuf);
							strcat(send, temp);
						}else
						{
							memset(temp, '\0', strlen(temp));
							strcpy(temp, "040099|");
							strcat(send, temp);
							strcat(send, "20PLEASE ATTEMPT AGAIN|");
						}
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(ecrModeData.sAudNum), ecrModeData.sAudNum);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(ecrModeData.sEcrId), ecrModeData.sEcrId);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glSendPack.szTermID), glSendPack.szTermID);
						strcat(send, temp);
						memset(sBuf, '\0', strlen(sBuf));
						memset(temp, '\0', strlen(temp));
						ReadAllData("count.txt", sBuf);
						sprintf(temp, "%.2d%s|", strlen(sBuf), sBuf);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(ecrModeData.sdatetime), ecrModeData.sdatetime);
						strcat(send, temp);
						if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
						{
							memset(temp, '\0', strlen(temp));
							strcpy(temp, "12Contact Chip|");
							strcat(send, temp);
						}else
						{
							memset(temp, '\0', strlen(temp));
							strcpy(temp, "14Pay With Phone|");
							strcat(send, temp);
						}
						memset(temp, '\0', strlen(temp));
						strcpy(temp, "06Online|00|");
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						memset(sBuf, '\0', strlen(sBuf));
						MaskAllPan(glSendPack.szPan, sBuf);
						sprintf(temp, "%.2d%s|", strlen(sBuf), sBuf);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glRecvPack.szRRN), glRecvPack.szRRN);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glProcInfo.stTranLog.szAppLabel), glProcInfo.stTranLog.szAppLabel);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glProcInfo.stTranLog.szAuthCode), glProcInfo.stTranLog.szAuthCode);
						strcat(send, temp);
						if(strlen(glSendPack.szFwdInstId))
						{
							memset(temp, '\0', strlen(temp));
							sprintf(temp, "%.2d%s|", strlen(glSendPack.szFwdInstId), glSendPack.szFwdInstId);
							strcat(send, temp);
						}else
						{
							memset(temp, '\0', strlen(temp));
							sprintf(temp, "%.2d%s|", strlen(glProcInfo.stTranLog.szHolderName), glProcInfo.stTranLog.szHolderName);
							strcat(send, temp);
						}
						memset(temp, '\0', strlen(temp));
						strcpy(temp, "00|");
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glSendPack.szExpDate), glSendPack.szExpDate);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						sprintf(temp, "%.2d%s|", strlen(glSendPack.szTranAmt), glSendPack.szTranAmt);
						strcat(send, temp);
						memset(temp, '\0', strlen(temp));
						strcpy(temp, "12000000000000");
						strcat(send, temp);
					}
				}

				//memset(temp, '\0', strlen(temp));
				//sprintf(temp, "Length: %.4d", strlen(send) + 4);
				//DisplayInfoNone("UNIFIED PAYMENTS", temp, 5);


				sprintf(sendFin, "%.4d%s|", strlen(send), send);
				DisplayInfoNone("UNIFIED PAYMENTS", "SENDING BACK RESPONSE", 1);
				Beep();
				OpenPort();
				PortSends(0, (unsigned char *)sendFin, strlen(sendFin));
				ucRet2 = 0x03;
				//DelayMs(50);
				PortClose(0);
				ecrEntrance();
			}
		}
	}	
}