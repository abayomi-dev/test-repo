#ifndef _ISOKEYEXCHANGE_H
#define _ISOKEYEXCHANGE_H


int GetMasterKey();
int GetSessionKey();
int GetPinKey();
int GetParaMeters();
int GetParaMetersTest(char *resCode);
int parseParameters(char *data);
int parseParametersOld(char *data);
int SendEmvData(char *icc, int *reversal);
int SendReversal();
int SendManualReversal();
extern int revSend;
extern int switchHostManual;
//Monitor
extern DL_ISO8583_HANDLER isoHandler;
extern DL_ISO8583_MSG     isoMsg;
//extern DL_UINT8           packBuf[5 * 1024];
extern DL_UINT16          packedSize;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _GLOBAL_H