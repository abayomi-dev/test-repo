
#ifndef _PAYARENA_H
#define _PAYARENA_H

typedef struct _tagTid
{
	uchar enabletid[128];
	uchar tidpin[128];
}ISOTid;


#ifdef __cplusplus
extern "C" {
#endif 

void PayArenaEngine();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
