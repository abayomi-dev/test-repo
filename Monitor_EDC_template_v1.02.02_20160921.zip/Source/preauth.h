
#ifndef _PREAUTH_H
#define _PREAUTH_H


#ifdef __cplusplus
extern "C" {
#endif 

int preAuth();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
