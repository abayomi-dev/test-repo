#ifndef _EMVKEYS_H
#define _EMVKEYS_H

void AddAllKeys(void);
void AddAllApps(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _GLOBAL_H