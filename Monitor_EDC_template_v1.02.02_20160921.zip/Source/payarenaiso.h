
#ifndef _PAYARENAISO_H
#define _PAYARENAISO_H


#ifdef __cplusplus
extern "C" {
#endif 

int performPurchase(int txn);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

// end of file
