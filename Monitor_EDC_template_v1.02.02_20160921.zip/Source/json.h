#ifndef _JSON_H
#define _JSON_H


int parseProfile(char *data);
int parseProfileOld(char *data);

extern int chkBiller;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _GLOBAL_H