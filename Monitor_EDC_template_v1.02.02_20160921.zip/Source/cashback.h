
#ifndef _CASHBACK_H
#define _CASHBACK_H


#ifdef __cplusplus
extern "C" {
#endif 

int cashBack();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
