#include "global.h"

ISOTid	tidIso;

struct BREAKDOWNPAY
{
	char name[128];
	char value[128];
	char inputtype[128];
	char lengthrule[128];
	char revalidate[128];
	char capturetoken[128];
	char printvalue[128];
};


int parseLineDataPay(char *line, struct BREAKDOWNPAY data[], int count)
{
    int iLen = 0;
	int i, j = 0, loop = 0, iRet;
	char name[128] = {0};
	char input[128] = {0};
	char temp[128] = {0};
	char tempName[128] = {0};
	char error[128] = {0};
	char valinput[128] = {0};
	int min, max, reval = 0;
	iLen = strlen(line);
	memset(name, '\0', strlen(name));
	for(i = 0; i < iLen; i++)
    {
        if(loop == 0)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].name, '\0', strlen(data[count].name));
                        strncpy(data[count].name, name + 7, strlen(name));
                        ShowLogs(1, "name: %s", data[count].name);
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 1)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].value, '\0', strlen(data[count].value));
                        strncpy(data[count].value, name + 8, strlen(name));
                        ShowLogs(1, "value: %s", data[count].value);
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 2)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].inputtype, '\0', strlen(data[count].inputtype));
                        strncpy(data[count].inputtype, name + 12, strlen(name));
                        ShowLogs(1, "inputtype: %s", data[count].inputtype);
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 3)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].lengthrule, '\0', strlen(data[count].lengthrule));
                        strncpy(data[count].lengthrule, name + 13, strlen(name));
                        ShowLogs(1, "lengthrule: %s", data[count].lengthrule);
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 4)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].revalidate, '\0', strlen(data[count].revalidate));
                        strncpy(data[count].revalidate, name + 13, strlen(name));
                        ShowLogs(1, "revalidate: %s", data[count].revalidate);
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 5)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].capturetoken, '\0', strlen(data[count].capturetoken));
                        strncpy(data[count].capturetoken, name + 15, strlen(name));
                        ShowLogs(1, "capturetoken: %s", data[count].capturetoken);
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }
    }
    
    LABEL:
    min = getMin(data[count].lengthrule);
	max = getMax(data[count].lengthrule);
	ShowLogs(1, "Min Length: %d", min);
	ShowLogs(1, "Max Length: %d", max);

	memset(temp, '\0', strlen(temp));
	if(reval == 1)
	{
		memset(tempName, '\0', strlen(tempName));
		strcpy(tempName, data[count].name);
		strcat(tempName, " REPEAT");
		iRet = DisplayMsg("UNIFIED PAYMENTS", tempName, data[count].value, temp, min, max);
	}else
		iRet = DisplayMsg("UNIFIED PAYMENTS", data[count].name, data[count].value, temp, min, max);
	ShowLogs(1, "Data entered for %s: %s", data[count].name, temp);
	if(strlen(temp) < 1 || iRet == GUI_ERR_USERCANCELLED || iRet == GUI_ERR_TIMEOUT)
	{
		return 1;
	}else
	{
		memset(input, '\0', strlen(input));
		parseParameter(temp, input);
		ShowLogs(1, "Input Type: %s", data[count].inputtype);
		if(getLabelInputtype(data[count].inputtype, input))
		{
			memset(error, '\0', strlen(error));
			Beep();
			strcpy(error, data[count].name);
			strcat(error, " WRONG\nINPUT TYPE");
			DisplayInfoNone("UNIFIED PAYMENTS", error, 4);
			return 1;
		}
		ShowLogs(1, "1. Revalidate: %s", data[count].revalidate);
		ShowLogs(1, "1. Revalidate Count: %d", reval);
		if(strstr(data[count].revalidate, "true") != NULL)
		{
			if(reval == 0)
			{
				memset(valinput, '\0', strlen(valinput));
				strcpy(valinput, input);
				reval++;
				goto LABEL;
			}else if(strlen(valinput))
				reval = 0;
		}
		ShowLogs(1, "1. Revalidate: %s", data[count].revalidate);
		ShowLogs(1, "1. Revalidate Count: %d", reval);
		if(strlen(valinput))
		{
			if(strstr(valinput, input) != NULL)
			{
				ShowLogs(1, "valinput: %s, %d::input: %s, %d.", valinput, strlen(valinput),
					input, strlen(input));
			}else
			{
				memset(error, '\0', strlen(error));
				Beep();
				strcpy(error, data[count].name);
				strcat(error, " ");
				strcat(error, "Mismatch.");
				DisplayInfoNone("UNIFIED PAYMENTS", error, 4);
				return 1;
			}
		}
	}
	if(printVas.count < 19)
    {
        sprintf((char *)printVas.name[count], "%s", data[count].name);
        sprintf((char *)printVas.value[count], "%s", input);
        printVas.count = count + 1;
    }
    return 0;
}

void PaymentsEngine()
{
	char menu[100 * 1024] = {0};
	int iRet, i, r;
	char line[1028] = {0};
    int count = 0;
    struct BREAKDOWNPAY data[248];
    int j, k, nt;
    char confee[13] = {0};
    char confeeS[13] = {0};
    char confee2[13] = {0};
    uchar szTotalAmt[12+1];
    char vendorid[13] = {0};
    char temp[248] = {0};
    uchar	szBuff[50];
    char disp[128] = {0};
    char SN[33] = {0};
	char theUHI[33] = {0};
	char theUHISend[33] = {0};
	char billerinfo[999] = {0};
	char billerinfosend[999] = {0};

    ST_EVENT_MSG stEventMsg;
	uchar key;
	int chk = 0;
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;

	memset(&glSendPack, 0, sizeof(STISO8583));//By wisdom
	memset(glProcInfo.stTranLog.szAmount, '\0', strlen(glProcInfo.stTranLog.szAmount));
	
	ReadAllData("payment.txt", menu);
	//ShowLogs(1, "%s", menu);

	memset(&printVas, 0, sizeof(PRINTVAS));

	for(i = 0; i < strlen(menu); i++)
    {
        j = 0;
        k = 0;
        memset(line, '\0', strlen(line));
        for(j = 0; i < strlen(menu); j++, k++, i++)
        {
            if((menu[i] == ',') && (menu[i + 1] == 'n'))
            {
                break;
            }else
            {
                line[k] = menu[i];
            }
        }
        if(parseLineDataPay(line, data, count))
        	return 0;
        count++;
    }

    memset(vendorid, '\0', strlen(vendorid));
    ReadAllData("pvenid.txt", vendorid);
    ShowLogs(1, "VendorId: %s.", vendorid);

	memset(confee, '\0', strlen(confee));
    ReadAllData("pconfee.txt", confee);
	ShowLogs(1, "ConvenienceFee: %s.", confee);

    ShowLogs(1, "PAYMENT GET AMOUNT");
    glProcInfo.stTranLog.ucTranType = SALE;
    ShowLogs(1, "PAYMENT GET AMOUNT A");
	//displayName("PAYMENTS");
	ShowLogs(1, "PAYMENT GET AMOUNT B");
	SetCurrTitle(_T("PAYMENTS"));
	ShowLogs(1, "PAYMENT GET AMOUNT 2");

	iRet = GetAmount();
	ShowLogs(1, "PAYMENT GET AMOUNT 3");
	if( iRet!=0 )
	{
		return ERR_USERCANCEL;
	}
	ShowLogs(1, "Amount: %s", glProcInfo.stTranLog.szAmount);

	memset(SN, '\0', strlen(SN)); 
	ReadSN(SN);
	if ('\0' == SN[0]) {
		strcpy(theUHI, "000000009");
	}
	strcpy(theUHI, SN);
	sprintf(theUHISend, "01%03d%s", strlen(theUHI), theUHI);
	ShowLogs(1, "Serial: %s", theUHISend);

	memset(billerinfo, '\0', strlen(billerinfo));
	strcpy(billerinfo, "Meter Number=12.");
	if(strlen(vendorid) > 0)
	{
		strcat(billerinfo, vendorid);
		strcat(billerinfo, ".");
	}

	//Here
	for(j = 0; j < printVas.count; j++)
	{
		if(j == 0)
		{
			strcpy(glSendPack.tempBillers, printVas.value[j]);
		}else
		{
			strcat(glSendPack.tempBillers, ".");
			strcat(glSendPack.tempBillers, printVas.value[j]);
		}
		memset(temp, 0, sizeof(temp));
		strcpy(temp, printVas.name[j]);
		strcat(temp, ":  ");
		strcat(temp, printVas.value[j]);
		ShowLogs(1, "%s", temp);
	}
	strcat(billerinfo, glSendPack.tempBillers);
	sprintf(billerinfosend, "%s48%03d%s", theUHISend, strlen(billerinfo), billerinfo);
	ShowLogs(1, "FIELD 62: %s", billerinfosend);
	strcpy(glSendPack.szBillers, billerinfosend);
    strcpy(glSendPack.tempBillers2, billerinfosend);
	ShowLogs(1, "Field 62 Again: %s", glSendPack.szBillers);
    ShowLogs(1, "Field 62 Temp: %s", glSendPack.tempBillers2);

	memset(confeeS, '\0', strlen(confeeS));
	getConvenienceFee(confeeS, confee);
    memset(confee2, '\0', strlen(confee2));
    getConvenienceFeeSpecial(confee2, confee);
	ShowLogs(1, "ConvenienceFee Used: %s", confee2);
    sprintf((char *)glSendPack.szTransFee, "%s", confee2);
    //sprintf((char *)glSendPack.szTranAmt, "%s", glProcInfo.stTranLog.szAmount);//New
	memset(szTotalAmt, '\0', strlen(szTotalAmt));
	PubAscAdd(glProcInfo.stTranLog.szAmount, confeeS, 12, szTotalAmt);
	ShowLogs(1, "Total: %s", szTotalAmt);
    sprintf((char *)glSendPack.szTranAmt, "%s", szTotalAmt);//Before
	memset(szBuff, '\0', strlen(szBuff));
	App_ConvAmountTran(szTotalAmt, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
	ShowLogs(1, "Converted Total: %s", szBuff);
	memset(disp, '\0', strlen(disp));
	strcpy(disp, "PLEASE CONFIRM AMOUNT");
	//strcat(disp, szBuff);

    //Testing Wisdom
    Gui_ClearScr(); 
    Gui_DrawText(disp, stTextAttr, 0, 15);
    Gui_DrawText(szBuff, stTextAttr, 0, 35);
    Gui_DrawText("NO                YES", stTextAttr, 0, 75);
    kbflush();
    nt = 0;
    while(1) 
    { 
        if(kbhit()==0)
        {
            switch(getkey())
            {
                case KEYCANCEL:
                    return 1;
                    //return ERR_USERCANCEL;
                case KEYENTER:
                    nt = 1;
                    break;
                default:
                    Beep();
            }
        }
        if(nt)
            break;
    }

    //For the vas field

    //Form Iso Here
    memset(glSendPack.szBillers, '\0', strlen(glSendPack.szBillers));
    strcpy(glSendPack.szBillers, glSendPack.tempBillers2);
    performPurchase(14);
    return 0;
	//MainProcessBillerPay(billers);
}