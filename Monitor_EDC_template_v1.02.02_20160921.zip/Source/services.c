#include "global.h"

int endofdayMenu()
{
    int iRet = 0, iMenuNo, iRev = 0;
    ST_EVENT_MSG stEventMsg;
    uchar key = 0;
    int chk = 0;
    char pin[25] = {0};
    GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
    char txnName1[20][128];
    int iTemp = 0;
    char temp[5] = {0};
    char sStore[100] = {0};
    uchar k;

    GUI_MENU stTranMenu;
    GUI_MENUITEM stTranMenuItem[20];
    int iMenuItemNum = 0;
    int i;

    GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
    stTextAttr.eFontSize = GUI_FONT_SMALL;
    
    numLines = 6;
    
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "TODAY");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "TODAY", strlen("TODAY"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "ALL");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "ALL", strlen("ALL"));

    for(i = 0; i < 2; ++i)
    {
        if(stDefTranMenuItem1[i].bVisible)
        {
            memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
            ++iMenuItemNum;
        }
    }

    stTranMenuItem[iMenuItemNum].szText[0] = 0;

    Gui_BindMenu("SERVICES", gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
    
    Gui_ClearScr();
    iMenuNo = 0;
    iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
    if(GUI_OK == iRet)
    {
        checkBoard = 0;
        if(strncmp(txnName1[iMenuNo], "TODAY", 5) == 0)
        {
            endofday();
        }else if(strncmp(txnName1[iMenuNo], "ALL", 3) == 0)
        {
            eodCollection();
        }
        Gui_ClearScr();
        return iRet;
    }
    return 0;
}

int serviceFunc()
{
	int iRet = 0, iMenuNo, iRev = 0;
	ST_EVENT_MSG stEventMsg;
	uchar key = 0;
	int chk = 0;
	char pin[25] = {0};
	GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
	char txnName1[20][128];
	int iTemp = 0;
	char temp[5] = {0};
	char sStore[100] = {0};
	uchar k;

	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	int i;

	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	numLines = 6;
	
	sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "CHECK CONNECTION");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "CHECK CONNECTION", strlen("CHECK CONNECTION"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "COMMS SETTINGS");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "COMMS SETTINGS", strlen("COMMS SETTINGS"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "MERCHANT PIN");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "MERCHANT PIN", strlen("MERCHANT PIN"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "CALL HOME");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "CALL HOME", strlen("CALL HOME"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "END OF DAY");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "END OF DAY", strlen("END OF DAY"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "LAST RECEIPT");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "LAST RECEIPT", strlen("LAST RECEIPT"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "REPRINT");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "REPRINT", strlen("REPRINT"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "CLEAR MEMORY");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "CLEAR MEMORY", strlen("CLEAR MEMORY"));    

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "DATA COLLECTION");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "DATA COLLECTION", strlen("DATA COLLECTION"));

	for(i = 0; i < 9; ++i)
    {
        if(stDefTranMenuItem1[i].bVisible)
        {
        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
            ++iMenuItemNum;
        }
    }

    stTranMenuItem[iMenuItemNum].szText[0] = 0;

	Gui_BindMenu("SERVICES", gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
	
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
	if(GUI_OK == iRet)
	{
        checkBoard = 0;
		if(strncmp(txnName1[iMenuNo], "CHECK CONNECTION", 16) == 0)
		{
            char lasthost[128] = {0};
            memset(lasthost, '\0', strlen(lasthost));
            UtilGetEnvEx("lhost", lasthost);
            ShowLogs(1, "1. Lasthost: %s", lasthost);
            if(strstr(lasthost, "host2") != NULL)
            {
                Beep();
                memset(temp, '\0', strlen(temp));
                txnType = 0;
                GetParaMetersTestB(temp);
                if(strstr(temp, "00") != NULL)
                    printTestConnection("SUCCESSFUL", temp);
                else
                    printTestConnection("UNSUCCESSFUL", temp);
            }else
            {
                Beep();
                memset(temp, '\0', strlen(temp));
                txnType = 0;
                GetParaMetersTest(temp);
                if(strstr(temp, "00") != NULL)
                    printTestConnection("SUCCESSFUL", temp);
                else
                    printTestConnection("UNSUCCESSFUL", temp);
            }

			serviceFunc();
		}else if(strncmp(txnName1[iMenuNo], "COMMS SETTINGS", 16) == 0)
        {
            commsSettings();
            serviceFunc();
        }else if(strncmp(txnName1[iMenuNo], "MERCHANT PIN", 12) == 0)
        {   
            setMerchantPin();
            serviceFunc();
        }else if(strncmp(txnName1[iMenuNo], "CALL HOME", 9) == 0)
        {   
            callHomeSettings();
            serviceFunc();
        }else if(strncmp(txnName1[iMenuNo], "LAST RECEIPT", 12) == 0)
        {   
            if(merchantPin() == 1)
            {
                reprintLast();
                serviceFunc();
            }else
                serviceFunc();
        }else if(strncmp(txnName1[iMenuNo], "REPRINT", 7) == 0)
        {   
            if(merchantPin() == 1)
            {
                reprintAnyReceipt();
                serviceFunc();
            }else
                serviceFunc();
        }else if(strncmp(txnName1[iMenuNo], "END OF DAY", 10) == 0)
        {   
            if(merchantPin() == 1)
            {
                endofdayMenu();
                serviceFunc();
            }else
                serviceFunc();
        }else if(strncmp(txnName1[iMenuNo], "DATA COLLECTION", 15) == 0)
        {   
            if(merchantPin() == 1)
            {
                dataCollection();
                serviceFunc();
            }else
                serviceFunc();
        }else if(strncmp(txnName1[iMenuNo], "CLEAR MEMORY", 12) == 0)
        {   
            uchar k;
            if(merchantPin() == 1)
            {
                DisplayInfoNone("UNIFIED PAYMENTS", "CLEAR MEMORY?", 0);
                kbflush();
                while(1)
                {
                    if( 0==kbhit() )
                    {
                        Beep();
                        k = getkey();
                        if(KEYCANCEL == k)
                        {
                            break;
                        }else if(KEYENTER == k)
                        {
                            DisplayInfoNone("UNIFIED PAYMENTS", "PERFORMING CALLHOME", 2);
                            PackCallHomeData();
                            dataCollection();
                            CreateWrite("receipt.txt", "0");
                            CreateWrite("reprint.txt", "0");
                            CreateWrite("tlog.txt", "0");
                            CreateWrite("eod.txt", "0");
                            CreateWrite("count.txt", "0");
                            CreateWrite("TRANLOG.DAT", "");
                            DisplayInfoNone("UNIFIED PAYMENTS", "MEMORY CLEARED...", 2);
                        }
                        break;
                    }
                    DelayMs(200);
                } 
                serviceFunc();
            }else
                serviceFunc();
        }


		Gui_ClearScr();
		return iRet;
	}
	return 0;
}