#ifndef _ISOKEYEXCHANGEB_H
#define _ISOKEYEXCHANGEB_H


int GetMasterKeyB();
int GetSessionKeyB();
int GetPinKeyB();
int GetParaMetersB();
int GetParaMetersTestB(char *resCode);
int parseParametersB(char *data);
int parseParametersOldB(char *data);
int SendEmvDataB(char *icc, int *reversal);
int SendReversalB();
int SendManualReversalB();


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _GLOBAL_H