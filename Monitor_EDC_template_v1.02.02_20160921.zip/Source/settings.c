#include "global.h"

int adminTid = 0;

int checkTidPin()
{
	int iRet;
	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	char pin[25] = {0};
	char mpin[25] = {0};
	int i;

	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 0;
	stInputAttr.nMinLen = 4;
	stInputAttr.nMaxLen = 20;
	stInputAttr.bSensitive = 1;

	memset(pin, '\0', strlen(pin));
	Gui_ClearScr();
	iRet = Gui_ShowInputBox("UNIFIED PAYMENTS", gl_stTitleAttr, _T("TID PIN"), gl_stLeftAttr,
		pin, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
	if( iRet!=GUI_OK )
	{
		return 0;
	}

	memset(mpin, '\0', strlen(mpin));
	ShowLogs(1, "Tid Pin: %s", tidIso.tidpin);
	strcpy(mpin, tidIso.tidpin);
	ShowLogs(1, "Tid Pin - %s: Length: %d..... Entered Pin - %s: Length: %d", mpin, strlen(mpin), pin, strlen(pin));
	if(strncmp(pin, mpin, strlen(pin)) != 0)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "WRONG TID PIN", 2);
		return 0;
	}else
	{
		return 1;
	}
}

void changeProfileID()
{
	char serverIp[20] = {0};
	char serverPort[20] = {0};
	char serverIpStore[20] = {0};
	char serverPortStore[20] = {0};
	char tid[20] = {0};
	char tidst[20] = {0};
	char term[100] = {0};
	int iRet;

	if(checkTidPin() == 0)
	{
		ShowLogs(1, "Wrong tid pin typed");
		return;
	}

	memset(tid, '\0', strlen(tid));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("tid", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "TERMINAL ID", term, tid, 8, 8);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}

	memset(serverIpStore, '\0', strlen(serverIpStore));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("tcmIP", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "SERVER IP", term, serverIpStore, 7, 29);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}

	memset(serverPortStore, '\0', strlen(serverPortStore));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("tcmPort", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "SERVER PORT", term, serverPortStore, 4, 6);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	memset(serverIp, '\0', strlen(serverIp));
	parseParameter(serverIpStore, serverIp);
	ShowLogs(1, "Parsed Ip: %s", serverIp);
	memset(serverPort, '\0', strlen(serverPort));
	parseParameter(serverPortStore, serverPort);
	ShowLogs(1, "Parsed Port: %s", serverPort);
	memset(tidst, '\0', strlen(tidst));
	parseParameter(tid, tidst);
	ShowLogs(1, "Parsed Tid: %s", tidst);
	
	UtilPutEnv("tIPaddr", serverIp);
	UtilPutEnv("tPort", serverPort);
	UtilPutEnv("tTermi", tidst);
	//Ok
	adminTid = 1;
	OldProfile();
}

void downProfile()
{
	ShowLogs(1, "Inside Download Profile 2");
	OldProfile();
}

void downloadKeys()
{
	uchar outputData[10240] = {0};
	int iRet;
	char lasthost[128] = {0};
	char temp[128] = {0};
	memset(lasthost, '\0', strlen(lasthost));
	UtilGetEnvEx("lhost", lasthost);
	ShowLogs(1, "1. Lasthost: %s", lasthost);
	ScrBackLight(1);
	Beep();
	if(strstr(lasthost, "host2") != NULL)
	{
		if(GetMasterKeyB())
		{
			DisplayInfoNone("UNIFIED PAYMENTS", "MASTER KEY LOADED", 2);
			if(GetSessionKeyB())
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SESSION KEY LOADED", 2);
				if(GetPinKeyB())
				{
					DisplayInfoNone("UNIFIED PAYMENTS", "PIN KEY LOADED", 2);
					if(GetParaMetersB())
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM LOADED", 2);
					}else
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM FAILED", 2);
						memset(outputData, '\0', strlen(outputData));
						iRet = ReadAllData("paramb.txt", outputData);
						if(iRet == 0)
						{
							if(parseParametersOldB(outputData))
							{
								ShowLogs(1, "Parameters Parse successful");
							}
						}
					}
				}else
					DisplayInfoNone("UNIFIED PAYMENTS", "PINKEY FAILED", 2);
			}else
				DisplayInfoNone("UNIFIED PAYMENTS", "SESSIONKEY FAILED", 2);
		}else
			DisplayInfoNone("UNIFIED PAYMENTS", "MASTERKEY FAILED", 2);

		memset(temp, '\0', strlen(temp));
		UtilGetEnv("hostname", temp);
		UtilPutEnv("uhostname", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("hostip", temp);
		UtilPutEnv("uhostip", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("hostport", temp);
		UtilPutEnv("uhostport", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("hostssl", temp);
		UtilPutEnv("uhostssl", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("hostfname", temp);
		UtilPutEnv("uhostfname", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("hostmestype", temp);
		ShowLogs(1, "Message type: %s", temp);
		UtilPutEnv("uhostmestype", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("hostremarks", temp);
		UtilPutEnv("uhostremarks", temp);
		UtilPutEnv("lhost", "host1");

		ShowLogs(1, "Resetting to Host priority host");
		memset(temp, '\0', strlen(temp));
		ReadAllData("hosa.txt", temp);
		ShowLogs(1, "Setting CTMK TO PRIORITY: %s", temp);
		UtilPutEnv("proCtmk", temp);

		if(GetMasterKey())
		{
			if(GetSessionKey())
			{
				if(GetPinKey())
				{
					if(GetParaMeters())
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM LOADED", 2);
					}else
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM FAILED", 2);
						memset(outputData, '\0', strlen(outputData));
						iRet = ReadAllData("param.txt", outputData);
						if(iRet == 0)
						{
							if(parseParametersOld(outputData))
							{
								ShowLogs(1, "Parameters Parse successful");
							}
						}
					}
				}else
					DisplayInfoNone("UNIFIED PAYMENTS", "PINKEY FAILED", 2);
			}else
				DisplayInfoNone("UNIFIED PAYMENTS", "SESSIONKEY FAILED", 2);
		}else
			DisplayInfoNone("UNIFIED PAYMENTS", "MASTERKEY FAILED", 2);
	}else
	{
		if(GetMasterKey())
		{
			if(GetSessionKey())
			{
				if(GetPinKey())
				{
					if(GetParaMeters())
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM LOADED", 2);
					}else
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM FAILED", 2);
						memset(outputData, '\0', strlen(outputData));
						iRet = ReadAllData("param.txt", outputData);
						if(iRet == 0)
						{
							if(parseParametersOld(outputData))
							{
								ShowLogs(1, "Parameters Parse successful");
							}
						}
					}
				}else
					DisplayInfoNone("UNIFIED PAYMENTS", "PINKEY FAILED", 2);
			}else
				DisplayInfoNone("UNIFIED PAYMENTS", "SESSIONKEY FAILED", 2);
		}else
			DisplayInfoNone("UNIFIED PAYMENTS", "MASTERKEY FAILED", 2);


		ShowLogs(1, "Resetting Host");
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("host2name", temp);
		UtilPutEnv("uhostname", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("host2ip", temp);
		UtilPutEnv("uhostip", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("host2port", temp);
		UtilPutEnv("uhostport", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("host2ssl", temp);
		UtilPutEnv("uhostssl", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("host2fname", temp);
		UtilPutEnv("uhostfname", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("host2mestype", temp);
		ShowLogs(1, "Message type: %s", temp);
		UtilPutEnv("uhostmestype", temp);
		memset(temp, '\0', strlen(temp));
		UtilGetEnv("host2remarks", temp);
		UtilPutEnv("uhostremarks", temp);
		UtilPutEnv("lhost", "host2");
		memset(temp, '\0', strlen(temp));
		ReadAllData("hosb.txt", temp);
		ShowLogs(1, "Setting CTMK TO HOST 2: %s", temp);
		UtilPutEnv("proCtmk", temp);
		if(GetMasterKeyB())
		{
			DisplayInfoNone("UNIFIED PAYMENTS", "MASTER KEY LOADED", 2);
			if(GetSessionKeyB())
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "SESSION KEY LOADED", 2);
				if(GetPinKeyB())
				{
					DisplayInfoNone("UNIFIED PAYMENTS", "PIN KEY LOADED", 2);
					if(GetParaMetersB())
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM LOADED", 2);
					}else
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "PARAM FAILED", 2);
						memset(outputData, '\0', strlen(outputData));
						iRet = ReadAllData("paramb.txt", outputData);
						if(iRet == 0)
						{
							if(parseParametersOldB(outputData))
							{
								ShowLogs(1, "Parameters Parse successful");
							}
						}
					}
				}else
					DisplayInfoNone("UNIFIED PAYMENTS", "PINKEY FAILED", 2);
			}else
				DisplayInfoNone("UNIFIED PAYMENTS", "SESSIONKEY FAILED", 2);
		}else
			DisplayInfoNone("UNIFIED PAYMENTS", "MASTERKEY FAILED", 2);
	}


	ShowLogs(1, "Resetting to Host priority host");
	memset(temp, '\0', strlen(temp));
	ReadAllData("hosa.txt", temp);
	ShowLogs(1, "Setting CTMK TO PRIORITY: %s", temp);
	UtilPutEnv("proCtmk", temp);

	memset(temp, '\0', strlen(temp));
	UtilGetEnv("hostname", temp);
	UtilPutEnv("uhostname", temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("hostip", temp);
	UtilPutEnv("uhostip", temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("hostport", temp);
	UtilPutEnv("uhostport", temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("hostssl", temp);
	UtilPutEnv("uhostssl", temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("hostfname", temp);
	UtilPutEnv("uhostfname", temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("hostmestype", temp);
	ShowLogs(1, "Message type: %s", temp);
	UtilPutEnv("uhostmestype", temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("hostremarks", temp);
	UtilPutEnv("uhostremarks", temp);
	UtilPutEnv("lhost", "host1");

}

void callHomeSettings()
{
	char callhome[20] = {0};
	char term[100] = {0};
	int iRet;
	memset(callhome, '\0', strlen(callhome));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("chinterval", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "CALL HOME INTERVAL", term, callhome, 2, 6);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	UtilPutEnv("chinterval", callhome);

	memset(callhome, '\0', strlen(callhome));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("chremarks", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "TRANSACTIONS \nBEFORE CALLHOME", term, callhome, 1, 6);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	UtilPutEnv("chremarks", callhome);
	DisplayInfoNone("UNIFIED PAYMENTS", "CALLHOME SETTINGS \nSAVED", 2);
}

void networkSettings()
{
	char apn[40] = {0};
	char username[40] = {0};
	char password[40] = {0};
	char apnStore[40] = {0};
	char usernameStore[40] = {0};
	char passwordStore[40] = {0};
	char term[100] = {0};
	int iRet;

	memset(apn, '\0', strlen(apn));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("coapn", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "APN", term, apn, 0, 39);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}

	memset(username, '\0', strlen(username));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("cosubnet", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "USERNAME", term, username, 0, 39);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}

	memset(password, '\0', strlen(password));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("copwd", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "SERVER PORT", term, password, 0, 39);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	memset(apnStore, '\0', strlen(apnStore));
	parseParameter(apn, apnStore);
	memset(usernameStore, '\0', strlen(usernameStore));
	parseParameter(username, usernameStore);
	memset(passwordStore, '\0', strlen(passwordStore));
	parseParameter(password, passwordStore);
	UtilPutEnv("coapn", apnStore);
	UtilPutEnv("cosubnet", usernameStore);
	UtilPutEnv("copwd", passwordStore);
	DisplayInfoNone("UNIFIED PAYMENTS", "GPRS SETTINGS SAVED", 2);
}

void hostSettings()
{
	char ip[40] = {0};
	char hostname[100] = {0};
	char port[40] = {0};
	char ipStore[40] = {0};
	char portStore[40] = {0};
	char hostnameStore[100] = {0};
	char term[100] = {0};
	int iRet;

	memset(hostname, '\0', strlen(hostname));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("hostfname", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "HOST NAME", term, hostname, 6, 90);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	UtilPutEnv("hostfname", hostname);

	memset(ip, '\0', strlen(ip));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("hostip", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "IP", term, ip, 6, 39);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	UtilPutEnv("hostip", ip);

	memset(port, '\0', strlen(port));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("hostport", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "USERNAME", term, port, 1, 6);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	UtilPutEnv("hostport", port);
	DisplayInfoNone("UNIFIED PAYMENTS", "HOST SETTINGS SAVED", 2);
}

void reprintAnyReceipt()
{
	char number[4] = {0};
	int iRet;
	memset(number, '\0', strlen(number));
	iRet = DisplayMsg("UNIFIED PAYMENTS", "RECEIPT NUMBER", "1", number, 1, 3);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	ShowLogs(1, "Number: %s", number);
	reprintAny(number);
}

void tcmSettings()
{
	char ip[100] = {0};
	char port[40] = {0};
	char term[100] = {0};
	int iRet;

	memset(ip, '\0', strlen(ip));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("tcmIP", term);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "HOST IP", term, ip, 6, 90);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	UtilPutEnv("tcmIP", ip);

	memset(port, '\0', strlen(port));
	memset(term, '\0', strlen(term));
	UtilGetEnvEx("tcmPort", port);
	iRet = DisplayMsg("UNIFIED PAYMENTS", "HOST PORT", term, port, 4, 6);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return;
	}
	UtilPutEnv("tcmPort", port);
	DisplayInfoNone("UNIFIED PAYMENTS", "HOST SETTINGS SAVED", 2);
}

void commsType()
{
	int iRet = 0, iMenuNo, iRev = 0;
	ST_EVENT_MSG stEventMsg;
	uchar key = 0;
	GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
	char txnName1[20][128];
	int iTemp = 0;
	char temp[5] = {0};
	char sStore[20] = {0};

	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	int i;
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;

	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "GPRS");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "GPRS", strlen("GPRS"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "WIFI");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "WIFI", strlen("WIFI"));

	for(i = 0; i < 2; ++i)
    {
        if(stDefTranMenuItem1[i].bVisible)
        {
        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
            ++iMenuItemNum;
        }
    }

    stTranMenuItem[iMenuItemNum].szText[0] = 0;
	Gui_BindMenu("COMMS TYPE", gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
	if(GUI_OK == iRet)
	{
		checkBoard = 0;
		if(strncmp(txnName1[iMenuNo], "GPRS", 4) == 0)
		{
			UtilPutEnv("cotype", "GPRS\n");
			networkSettings();
			commsType();
		}else if(strncmp(txnName1[iMenuNo], "WIFI", 4) == 0)
		{
			UtilPutEnv("cotype", "WIFI\n");
			wifiSetup();
			commsType();
		}
		Gui_ClearScr();
		return;
	}
}

void commsSettings()
{
	int iRet = 0, iMenuNo, iRev = 0;
	ST_EVENT_MSG stEventMsg;
	uchar key = 0;
	uchar k;
	GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
	char txnName1[20][128];
	int iTemp = 0;
	char temp[5] = {0};
	char sStore[20] = {0};

	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	int i;
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;

	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "HOST");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "HOST", strlen("HOST"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "SSL");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "SSL", strlen("SSL"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "COMMS TYPE");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "COMMS TYPE", strlen("COMMS TYPE"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "CALL HOME HOST");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "CALL HOME HOST", strlen("CALL HOME HOST"));


	for(i = 0; i < 4; ++i)
    {
        if(stDefTranMenuItem1[i].bVisible)
        {
        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
            ++iMenuItemNum;
        }
    }

    stTranMenuItem[iMenuItemNum].szText[0] = 0;
	Gui_BindMenu("COMMS SETTINGS", gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
	if(GUI_OK == iRet)
	{
		checkBoard = 0;
		if(strncmp(txnName1[iMenuNo], "HOST", 4) == 0)
		{
			hostSettings();
			commsSettings();
		}else if(strncmp(txnName1[iMenuNo], "SSL", 3) == 0)
		{
			memset(sStore, '\0', strlen(sStore));
			UtilGetEnv("hostssl", sStore);
			if(strstr(sStore, "true") != NULL)
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "TURN OFF SSL?", 1);
			}else
			{
				DisplayInfoNone("UNIFIED PAYMENTS", "TURN ON SSL?", 1);
			}
			kbflush();
			while(1)
			{
				if( 0==kbhit() )
				{
					Beep();
					k = getkey();
					if(KEYCANCEL == k)
					{
						break;
					}else if(KEYENTER == k)
					{
						if(strstr(sStore, "true") != NULL)
							UtilPutEnv("hostssl", "false");
						else
							UtilPutEnv("hostssl", "true");
					}
					break;
				}
				DelayMs(200);
			}
			commsSettings();
		}else if(strncmp(txnName1[iMenuNo], "COMMS TYPE", 10) == 0)
		{
			commsType();
			commsSettings();
		}else if(strncmp(txnName1[iMenuNo], "CALL HOME HOST", 14) == 0)
		{
			tcmSettings();
			commsSettings();
		}
		Gui_ClearScr();
		return;
	}
}