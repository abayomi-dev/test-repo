
#ifndef _RETAILMAN_H
#define _RETAILMAN_H


#ifdef __cplusplus
extern "C" {
#endif 

void retailmanEntrance();
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
