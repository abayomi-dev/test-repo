#include "global.h"

void logoDownload(int isReceipt)
{
	char version[128] = {0};
	char bankcode[128] = {0};
	
	if(isReceipt)
	{
		memset(version, '\0', strlen(version));
		UtilGetEnv("logoversion", version);
		ShowLogs(1, "logoversion: %s", version);

		memset(bankcode, '\0', strlen(bankcode));
		UtilGetEnv("logobankcode", bankcode);
		ShowLogs(1, "logobankcode: %s", bankcode);

		DisplayInfoNone("UNIFIED PAYMENTS", "DOWNLOADING \nRECEIPT LOGO", 5);
	}else
	{
		memset(version, '\0', strlen(version));
		UtilGetEnv("logobversion", version);
		ShowLogs(1, "logobversion: %s", version);

		memset(bankcode, '\0', strlen(bankcode));
		UtilGetEnv("logobbankcode", bankcode);
		ShowLogs(1, "logobbankcode: %s", bankcode);

		DisplayInfoNone("UNIFIED PAYMENTS", "DOWNLOADING \nBACKGROUND LOGO", 5);
	}
}