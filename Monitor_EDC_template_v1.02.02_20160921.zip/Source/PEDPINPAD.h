#ifndef _PED_PINPAD_H
#define _PED_PINPAD_H

// nothing

#endif

// end of file
