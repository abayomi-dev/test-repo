
#ifndef _HOST_H
#define _HOST_H


#ifdef __cplusplus
extern "C" {
#endif 

void switchAutomaticHost();
void checkifAutoHost();
extern int checkAutoHost;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

// end of file
