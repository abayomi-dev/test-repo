#include "global.h"
int manflag = 0;

void manPurchase(char *pan, char *expdate)
{
	int iRet;
	uchar	szTotalAmt[12+1];
	char name[50] = {0};
	char temp[200] = {0};

	glProcInfo.stTranLog.ucTranType = SALE;
	displayName(name);
	SetCurrTitle(_T(name));

	ShowLogs(1, "The Pan is: %s", pan);
	ShowLogs(1, "The Expiry Date is: %s", expdate);
	
	amtCount = 0;
	iRet = GetAmount();
	if( iRet!=0 )
	{
		return ERR_USERCANCEL;
	}
	ShowLogs(1, "2. Amount: %s", glProcInfo.stTranLog.szAmount);
	sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, glProcInfo.stTranLog.szAmount);
	
	DisplayInfoNone("UNIFIED PAYMENTS", "PROCESSING...", 1);
	sprintf((char *)glSendPack.szMsgCode, "%s", "0200");
	sprintf((char *)glSendPack.szAqurId, "%.*s", LEN_AQUR_ID, "111129");
	strcpy(glSendPack.szPan, pan);
	strcpy(glSendPack.szProcCode, "000000");
	glSendPack.szExpDate[0] = expdate[2];
	glSendPack.szExpDate[1] = expdate[3];
	glSendPack.szExpDate[2] = expdate[0];
	glSendPack.szExpDate[3] = expdate[1];
	strcpy(glSendPack.szCondCode, "00");
	strcpy(glSendPack.szTransFee, "C00000000");
	strcpy(glSendPack.szEntryMode, "0011");
	strcpy(glSendPack.szTrack2, pan);
	strcat(glSendPack.szTrack2, "D");
	strcat(glSendPack.szTrack2, glSendPack.szExpDate);
	glSysCtrl.ulSTAN = useStan;
	sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN); 
	glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;
	sprintf((char *)glSendPack.szRRN, "000000%s", glSendPack.szSTAN);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMCC", temp);
	sprintf((char *)glSendPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("tid", temp);
	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMid", temp);
	sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("curcode", temp);
	sprintf((char *)glSendPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMNL", temp);
	sprintf((char *)glSendPack.szMNL, "%.*s", LEN_MNL, temp);
	sprintf((char *)glSendPack.szPosDataCode, "%.*s", LEN_POS_CODE, "510100101344101");
	manflag = 1;
}

void manPreAuth(char *pan, char *expdate)
{
	int iRet;
	uchar	szTotalAmt[12+1];
	char name[50] = {0};
	char temp[200] = {0};

	glProcInfo.stTranLog.ucTranType = SALE;
	displayName(name);
	SetCurrTitle(_T(name));
	ShowLogs(1, "The Pan is: %s", pan);
	ShowLogs(1, "The Expiry Date is: %s", expdate);
	
	amtCount = 0;
	iRet = GetAmount();
	if( iRet!=0 )
	{
		return ERR_USERCANCEL;
	}
	ShowLogs(1, "2. Amount: %s", glProcInfo.stTranLog.szAmount);
	sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, glProcInfo.stTranLog.szAmount);

	DisplayInfoNone("UNIFIED PAYMENTS", "PROCESSING...", 1);
	sprintf((char *)glSendPack.szMsgCode, "%s", "0100");
	sprintf((char *)glSendPack.szAqurId, "%.*s", LEN_AQUR_ID, "111129");
	strcpy(glSendPack.szPan, pan);
	strcpy(glSendPack.szProcCode, "600000");
	glSendPack.szExpDate[0] = expdate[2];
	glSendPack.szExpDate[1] = expdate[3];
	glSendPack.szExpDate[2] = expdate[0];
	glSendPack.szExpDate[3] = expdate[1];
	strcpy(glSendPack.szCondCode, "00");
	strcpy(glSendPack.szTransFee, "C00000000");
	strcpy(glSendPack.szEntryMode, "0011");
	strcpy(glSendPack.szTrack2, pan);
	strcat(glSendPack.szTrack2, "D");
	strcat(glSendPack.szTrack2, glSendPack.szExpDate);
	glSysCtrl.ulSTAN = useStan;
	sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN); 
	glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;
	sprintf((char *)glSendPack.szRRN, "000000%s", glSendPack.szSTAN);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMCC", temp);
	sprintf((char *)glSendPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("tid", temp);
	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMid", temp);
	sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("curcode", temp);
	sprintf((char *)glSendPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMNL", temp);
	sprintf((char *)glSendPack.szMNL, "%.*s", LEN_MNL, temp);
	sprintf((char *)glSendPack.szPosDataCode, "%.*s", LEN_POS_CODE, "510100101344101");
	manflag = 2;
}

void manCompletion(char *pan, char *expdate)
{
	int iRet;
	uchar	szTotalAmt[12+1];
	char name[50] = {0};
	char temp[200] = {0};
	
	ST_EVENT_MSG stEventMsg;
	uchar key;
	int chk = 0;
	char rrn[13] = {0};
	char auth[7] = {0};
	char txn[100 * 1024] = {0};
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;

	glProcInfo.stTranLog.ucTranType = SALE;
	displayName(name);
	SetCurrTitle(_T(name));
	ShowLogs(1, "The Pan is: %s", pan);
	ShowLogs(1, "The Expiry Date is: %s", expdate);


	iRet = ReadAllData("eod.txt", txn);
	if(strlen(txn) < 10)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "NO TRANSACTIONS", 2);
		return 0;
	}
	
	DisplayMsg("SALES COMPLETION", "RRN", "0", rrn, 12, 12);
	ShowLogs(1, "Rrn: %s", rrn);
	if(strlen(rrn) < 12)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "RRN TOO SHORT", 2);
		return 0;
	}

	DisplayMsg("UNIFIED PAYMENTS", "AUTH CODE", "0", auth, 6, 6);
	ShowLogs(1, "Auth Code: %s", auth);
	if(strlen(auth) < 6)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "AUTH CODE TOO SHORT", 2);
		return 0;
	}

	memset(&glSendPack, 0, sizeof(STISO8583));
	strcpy(glSendPack.szRRN, rrn);
	strcpy(glSendPack.szAuthCode, auth);
	strcpy(glSendPack.szReasonCode, "2300");

	amtCount = 0;
	iRet = GetAmount();
	if( iRet!=0 )
	{
		return ERR_USERCANCEL;
	}
	ShowLogs(1, "2. Amount: %s", glProcInfo.stTranLog.szAmount);
	sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, glProcInfo.stTranLog.szAmount);

	DisplayInfoNone("UNIFIED PAYMENTS", "PROCESSING....", 1);
	sprintf((char *)glSendPack.szMsgCode, "%s", "0220");
	sprintf((char *)glSendPack.szAqurId, "%.*s", LEN_AQUR_ID, "111129");
	strcpy(glSendPack.szPan, pan);
	strcpy(glSendPack.szProcCode, "610000");
	glSendPack.szExpDate[0] = expdate[2];
	glSendPack.szExpDate[1] = expdate[3];
	glSendPack.szExpDate[2] = expdate[0];
	glSendPack.szExpDate[3] = expdate[1];
	strcpy(glSendPack.szCondCode, "00");
	strcpy(glSendPack.szTransFee, "C00000000");
	strcpy(glSendPack.szEntryMode, "0011");
	strcpy(glSendPack.szTrack2, pan);
	strcat(glSendPack.szTrack2, "D");
	strcat(glSendPack.szTrack2, glSendPack.szExpDate);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMCC", temp);
	sprintf((char *)glSendPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("tid", temp);
	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMid", temp);
	sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("curcode", temp);
	sprintf((char *)glSendPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMNL", temp);
	sprintf((char *)glSendPack.szMNL, "%.*s", LEN_MNL, temp);
	sprintf((char *)glSendPack.szPosDataCode, "%.*s", LEN_POS_CODE, "510100101344101");
	manflag = 5;
}

void manRefund(char *pan, char *expdate)
{
	int iRet;
	uchar	szTotalAmt[12+1];
	char name[50] = {0};
	char temp[200] = {0};

	glProcInfo.stTranLog.ucTranType = SALE;
	displayName(name);
	SetCurrTitle(_T(name));
	ShowLogs(1, "The Pan is: %s", pan);
	ShowLogs(1, "The Expiry Date is: %s", expdate);

	amtCount = 0;
	iRet = GetAmount();
	if( iRet!=0 )
	{
		return ERR_USERCANCEL;
	}
	ShowLogs(1, "2. Amount: %s", glProcInfo.stTranLog.szAmount);
	sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, glProcInfo.stTranLog.szAmount);


	DisplayInfoNone("UNIFIED PAYMENTS", "PROCESSING....", 1);
	sprintf((char *)glSendPack.szMsgCode, "%s", "0200");
	sprintf((char *)glSendPack.szAqurId, "%.*s", LEN_AQUR_ID, "111129");
	strcpy(glSendPack.szPan, pan);
	strcpy(glSendPack.szProcCode, "200000");
	glSendPack.szExpDate[0] = expdate[2];
	glSendPack.szExpDate[1] = expdate[3];
	glSendPack.szExpDate[2] = expdate[0];
	glSendPack.szExpDate[3] = expdate[1];
	strcpy(glSendPack.szCondCode, "00");
	strcpy(glSendPack.szTransFee, "C00000000");
	strcpy(glSendPack.szEntryMode, "0011");
	strcpy(glSendPack.szTrack2, pan);
	strcat(glSendPack.szTrack2, "D");
	strcat(glSendPack.szTrack2, glSendPack.szExpDate);
	glSysCtrl.ulSTAN = useStan;
	sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN); 
	glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;
	sprintf((char *)glSendPack.szRRN, "000000%s", glSendPack.szSTAN);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMCC", temp);
	sprintf((char *)glSendPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("tid", temp);
	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMid", temp);
	sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("curcode", temp);
	sprintf((char *)glSendPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMNL", temp);
	sprintf((char *)glSendPack.szMNL, "%.*s", LEN_MNL, temp);
	sprintf((char *)glSendPack.szPosDataCode, "%.*s", LEN_POS_CODE, "510100101344101");
	manflag = 3;
}

void manCashback(char *pan, char *expdate)
{
	int iRet;
	uchar	szTotalAmt[12+1];
	char name[50] = {0};
	char temp[200] = {0};
	manflag = 4;

	glProcInfo.stTranLog.ucTranType = SALE;
	displayName(name);
	SetCurrTitle(_T(name));

	ShowLogs(1, "The Pan is: %s", pan);
	ShowLogs(1, "The Expiry Date is: %s", expdate);

	amtCount = 0;
	iRet = GetAmount();
	if( iRet!=0 )
	{
		return ERR_USERCANCEL;
	}
	PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
	sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, szTotalAmt);

	DisplayInfoNone("UNIFIED PAYMENTS", "PROCESSING....", 1);
	sprintf((char *)glSendPack.szMsgCode, "%s", "0200");
	sprintf((char *)glSendPack.szAqurId, "%.*s", LEN_AQUR_ID, "111129");
	strcpy(glSendPack.szPan, pan);
	strcpy(glSendPack.szProcCode, "090000");
	glSendPack.szExpDate[0] = expdate[2];
	glSendPack.szExpDate[1] = expdate[3];
	glSendPack.szExpDate[2] = expdate[0];
	glSendPack.szExpDate[3] = expdate[1];
	strcpy(glSendPack.szCondCode, "00");
	strcpy(glSendPack.szTransFee, "C00000000");
	strcpy(glSendPack.szEntryMode, "0011");
	strcpy(glSendPack.szTrack2, pan);
	strcat(glSendPack.szTrack2, "D");
	strcat(glSendPack.szTrack2, glSendPack.szExpDate);
	glSysCtrl.ulSTAN = useStan;
	sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN); 
	glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;
	sprintf((char *)glSendPack.szRRN, "000000%s", glSendPack.szSTAN);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMCC", temp);
	sprintf((char *)glSendPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("tid", temp);
	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMid", temp);
	sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnv("curcode", temp);
	sprintf((char *)glSendPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, temp);
	memset(temp, '\0', strlen(temp));
	UtilGetEnvEx("txnMNL", temp);
	sprintf((char *)glSendPack.szMNL, "%.*s", LEN_MNL, temp);
	sprintf((char *)glSendPack.szPosDataCode, "%.*s", LEN_POS_CODE, "510100101344101");
}

int manualEntry()
{
	int iRet = 0, iMenuNo, iRev = 0;
	ST_EVENT_MSG stEventMsg;
	uchar key = 0;
	int chk = 0;
	char pan[25] = {0};
	char expdate[5] = {0};
	char txnName1[20][128];
	int iTemp = 0;
	char temp[5] = {0};
	GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
	char lasthost[128] = {0};
	char verve[128] = {0};

	GUI_MENU stTranMenu;
	GUI_MENUITEM stTranMenuItem[20];
	int iMenuItemNum = 0;
	int i;
	
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
	
	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 0;
	stInputAttr.nMinLen = 4;
	stInputAttr.nMaxLen = 20;
	stInputAttr.bSensitive = 1;


	numLines = 4;
	iRet = DisplayMsg("UNIFIED PAYMENTS", "CARD NUMBER", "0", pan, 10, 21);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return 0;
	}
	ShowLogs(1, "Pan: %s", pan);
	if(strlen(pan) < 10)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "CARD NUMBER TOO SHORT", 2);
		return 0;
	}
	
	iRet = DisplayMsg("UNIFIED PAYMENTS", "Expiry Date (mmyy)", "0", expdate, 4, 4);
	ShowLogs(1, "Expiry Date: %s", expdate);
	if(iRet == GUI_ERR_USERCANCELLED)
	{
		Beep();
		DisplayInfoNone("UNIFIED PAYMENTS", "USER CANCELED", 2);
		return 0;
	}
	if(strlen(expdate) < 4)
	{
		DisplayInfoNone("UNIFIED PAYMENTS", "EXPIRY DATE TOO SHORT", 2);
		return 0;
	}

	sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "PURCHASE");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "PURCHASE", strlen("PURCHASE"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "PRE AUTH");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "PRE AUTH", strlen("PRE AUTH"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "SALES COMPLETION");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "SALES COMPLETION", strlen("SALES COMPLETION"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "REFUND");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "REFUND", strlen("REFUND"));

    key++;
    sprintf((char *)stDefTranMenuItem1[key].szText, "%s", "CASHBACK");
    stDefTranMenuItem1[key].nValue = key;
    stDefTranMenuItem1[key].bVisible = TRUE;
    strncpy(txnName1[key], "CASHBACK", strlen("CASHBACK"));


	for(i = 0; i < 5; ++i)
    {
        if(stDefTranMenuItem1[i].bVisible)
        {
        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
            ++iMenuItemNum;
        }
    }

    stTranMenuItem[iMenuItemNum].szText[0] = 0;

	Gui_BindMenu("UNIFIED PAYMENTS", gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
	
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
	txnType = 9;
	memset(&glSendPack, 0, sizeof(STISO8583));
	if(GUI_OK == iRet)
	{
		checkBoard = 0;
		if(strncmp(txnName1[iMenuNo], "PURCHASE", 8) == 0)
		{
			manPurchase(pan, expdate);
		}else if(strncmp(txnName1[iMenuNo], "PRE AUTH", 8) == 0)
		{
			manPreAuth(pan, expdate);
		}else if(strncmp(txnName1[iMenuNo], "SALES COMPLETION", 16) == 0)
		{
			manCompletion(pan, expdate);
		}else if(strncmp(txnName1[iMenuNo], "REFUND", 6) == 0)
		{
			manRefund(pan, expdate);
		}else if(strncmp(txnName1[iMenuNo], "CASHBACK", 8) == 0)
		{
			manCashback(pan, expdate);
		}
		
		if(manflag != 0)
		{
			memset(lasthost, '\0', strlen(lasthost));
			UtilGetEnvEx("lhost", lasthost);
			ShowLogs(1, "1. Lasthost: %s", lasthost);
			if(strstr(lasthost, "host2") != NULL)
			{
				if(glSendPack.szPan[0] == '5' && glSendPack.szPan[1] == '0' && glSendPack.szPan[2] == '6')
				{
					memset(verve, '\0', strlen(verve));
					strcpy(verve, profileTag.vervehost);
					ShowLogs(1, "Verve Host: %s", verve);
					if(strstr(verve, "host1") != NULL)
					{
						setVerveHost("host1");
						iRet = SendEmvData(NULL, &iRev);
					}else
					{
						setVerveHost("host2");
						iRet = SendEmvDataB(NULL, &iRev);
					}
				}else
				{
					iRet = SendEmvDataB(NULL, &iRev);
				}
			}else
			{
				if(glSendPack.szPan[0] == '5' && glSendPack.szPan[1] == '0' && glSendPack.szPan[2] == '6')
				{
					memset(verve, '\0', strlen(verve));
					strcpy(verve, profileTag.vervehost);
					ShowLogs(1, "Verve Host: %s", verve);
					if(strstr(verve, "host1") != NULL)
					{
						setVerveHost("host1");
						iRet = SendEmvData(NULL, &iRev);
					}else
					{
						setVerveHost("host2");
						iRet = SendEmvDataB(NULL, &iRev);
					}
				}else
				{
					iRet = SendEmvData(NULL, &iRev);
				}
			}
			
			if(iRet != 0)
			{
				ShowLogs(1, "Failed. SendEmvData Returned: %d", iRet);
				DisplayInfoNone("UNIFIED PAYMENTS", "NOT SUCCESSFUL", 3);
				PrintAllReceipt(PRN_NORMAL);//Monitor
			}else
			{
				ShowLogs(1, "Response came from host");
				if(revFlag == 0)
				{
					if( memcmp(glRecvPack.szRspCode, "00", LEN_RSP_CODE)!=0 )
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "DECLINED", 1);
					}else
					{
						DisplayInfoNone("UNIFIED PAYMENTS", "APPROVED", 1);
					}
					PrintAllReceipt(PRN_NORMAL);
				}	
				else
				{
					DisplayInfoNone("UNIFIED PAYMENTS", "NOT SUCCESSFUL", 3);
				}
				revFlag = 0;
			} 
			if(iRev == 1)
			{
				ShowLogs(1, "Sending Reversal. Value: %d", iRev);
				DisplayInfoNone("UNIFIED PAYMENTS", "NO RESPONSE", 3);
				if(strstr(lasthost, "host2") != NULL)
				{
					iRet = SendReversalB();
				}else
				{
					iRet = SendReversal();
				}
				if( iRet!=0 )
				{
					DisplayInfoNone("UNIFIED PAYMENTS", "NOT SUCCESSFUL", 2);
				}else
				{
					DisplayInfoNone("UNIFIED PAYMENTS", "SUCCESSFUL", 2);
				}
			}

			GetTxnCount();
			memset(temp, '\0', strlen(temp));
			UtilGetEnvEx("chremarks", temp);
			iTemp = atol(temp);
			ShowLogs(1, "Check Value: %d. Current Count: %d.", iTemp, txnCount);
			if(txnCount >= iTemp)
			{
				PackCallHomeData();
			}

			manflag = 0;
		}
		Gui_ClearScr();
		return iRet;
	}
	
	return 0;
}