
#ifndef _CASHADVANCE_H
#define _CASHADVANCE_H


#ifdef __cplusplus
extern "C" {
#endif 

int cashAdvance();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
