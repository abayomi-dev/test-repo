
#ifndef _REVERSAL_H
#define _REVERSAL_H


#ifdef __cplusplus
extern "C" {
#endif 

int reversalTxn();
extern int revFlag;
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
