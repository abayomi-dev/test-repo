
#ifndef _PAYATTITUDE_H
#define _PAYATTITUDE_H


#ifdef __cplusplus
extern "C" {
#endif 

int payAttitude();
extern int payAtt;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
