#include "global.h"



void parseBillerData(char *line, struct BILLERS *data)
{
    int iLen = 0;
	int i, j = 0, loop = 0;
	char name[128] = {0};
	iLen = strlen(line);
	memset(name, '\0', strlen(name));
	for(i = 0; i < iLen; i++)
    {
        if(loop == 0)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data->billername, '\0', strlen(data->billername));
                        strncpy(data->billername, name + 13, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 1)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data->printall, '\0', strlen(data->printall));
                        strncpy(data->printall, name + 11, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 2)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data->vendorid, '\0', strlen(data->vendorid));
                        strncpy(data->vendorid, name + 11, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 3)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data->istoken, '\0', strlen(data->istoken));
                        strncpy(data->istoken, name + 10, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 4)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data->conveniencefee, '\0', strlen(data->conveniencefee));
                        strncpy(data->conveniencefee, name + 17, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 5)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data->printvalidation, '\0', strlen(data->printvalidation));
                        strncpy(data->printvalidation, name + 18, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }
    }
}

void getBiller(char* key, char *biller, char *allbiller)
{
    int i,iLen, j = 0;
    char check[124] = {0};
    strcpy(check, "billername - ");
    strcat(check, key);
    strcat(check, "###");
    iLen = strlen(allbiller);
    for(i = 0; i < iLen; i++)
    {
        if(allbiller[i] == ',')
        {
            if(allbiller[i + 1] == 'b')
            {
                if(allbiller[i + 2] == 'i')
                {
                    if(allbiller[i + 3] == 'l')
                    {
                        if(allbiller[i + 4] == 'l')
                        {
                            if(allbiller[i + 5] == 'e')
                            {
                                if(allbiller[i + 6] == 'r')
                                {
                                    if(allbiller[i + 7] == 'n')
                                    {
                                        if(allbiller[i + 8] == 'a')
                                        {
                                            if(allbiller[i + 9] == 'm')
                                            {
                                                if(allbiller[i + 10] == 'e')
                                                {
                                                    if(strstr(biller, check) != NULL)
                                                    {
                                                        return;
                                                    }else
                                                    {
                                                        j = 0;
                                                        memset(biller, '\0', strlen(biller));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }else
            {
                biller[j] = allbiller[i];
                j++;
            }
        }else
        {
            biller[j] = allbiller[i];
            j++;
        }
    }

    if(strstr(biller, check) != NULL)
    {
        return;
    }else
    {
        j = 0;
        memset(biller, '\0', strlen(biller));
        return;
    }
}

void parseLabelData(char *line, struct LABELS data[], int count)
{
    int iLen = 0;
	int i, j = 0, loop = 0, k = 0;
	char name[128] = {0};
	iLen = strlen(line);
	memset(name, '\0', strlen(name));
	for(i = 0; i < iLen; i++)
    {
        if(loop == 0)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].labelname, '\0', strlen(data[count].labelname));
                        if(strstr(name, "labels - ") != NULL)
                            strncpy(data[count].labelname, name + 21, strlen(name));
                        else
                            strncpy(data[count].labelname, name + 12, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 1)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].value, '\0', strlen(data[count].value));
                        strncpy(data[count].value, name + 8, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 2)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].inputtype, '\0', strlen(data[count].inputtype));
                        strncpy(data[count].inputtype, name + 12, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 3)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].lengthrule, '\0', strlen(data[count].lengthrule));
                        strncpy(data[count].lengthrule, name + 13, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 4)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].revalidate, '\0', strlen(data[count].revalidate));
                        strncpy(data[count].revalidate, name + 13, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 5)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].capturetoken, '\0', strlen(data[count].capturetoken));
                        strncpy(data[count].capturetoken, name + 15, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 6)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].printvalue, '\0', strlen(data[count].printvalue));
                        strncpy(data[count].printvalue, name + 13, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }
    }
    if(strlen(data[count].printvalue) < 1)
    {
        memset(data[count].printvalue, '\0', strlen(data[count].printvalue));
        strncpy(data[count].printvalue, name + 13, strlen(name));
    }
}

void parseProductData(char *line, struct PRODUCTS data[], int count)
{
    int iLen = 0;
	int i, j = 0, loop = 0, k = 0;
	char name[128] = {0};
	iLen = strlen(line);
	memset(name, '\0', strlen(name));
	for(i = 0; i < iLen; i++)
    {
        if(loop == 0)
        {
            if(line[i] == '#')
            {
                if(line[i + 1] == '#')
                {
                    if(line[i + 2] == '#')
                    {
                        loop++;
                        j = 0;
                        memset(data[count].productname, '\0', strlen(data[count].productname));
                        if(strstr(name, "products - ") != NULL)
                            strncpy(data[count].productname, name + 25, strlen(name));
                        else
                            strncpy(data[count].productname, name + 14, strlen(name));
                        memset(name, '\0', strlen(name));
                        i = i + 2;
                    }
                }
            }else
            {
                name[j] = line[i];
                j++;
            }
        }else if(loop == 1)
        {
            name[k] = line[i];
            k++;
        }
    }
    memset(data[count].value, '\0', strlen(data[count].value));
    strncpy(data[count].value, name + 8, strlen(name));
}

int getMax(char *rule)
{
    char c;
    char da[5] = {0};
    int max;
    int am = 0;
    c = rule[0];
    strcpy(da, rule + 1);
    am = atoi(da);
    switch(c)
    {
        case '=':
            max = am;
            break;
        case '<':
            max = am;
            break;
        case '>':
            max = 5 * am;
            break;
        default:
            max = 40;
    }
    return max;
}

int getMin(char *rule)
{
    char c;
    char da[5] = {0};
    int min;
    int am = 0;
    c = rule[0];
    strcpy(da, rule + 1);
    am = atoi(da);
    switch(c)
    {
        case '=':
            min = am;
            break;
        case '<':
            min = 1;
            break;
        case '>':
            min = am;
            break;
        default:
            min = 1;
    }
    return min;
}

int getLabelInputtype(char *type, char *input)
{
    int i = 0;
    if(strstr(type, "numeric") != NULL)
    {
        for(i = 0; i < strlen(input); i++)
        {
            if(input[i] >= '0' && input[i] <= '9')
            {

            }else
            {
                return 1;
            }
        }
    }else if(strstr(type, "alphabet") != NULL)
    {
        for(i = 0; i < strlen(input); i++)
        {
            if(input[i] >= '0' && input[i] <= '9')
            {
                return 1;
            }else
            {

            }
        }
    }
    return 0;
}

void getConvenienceFee(char *confee, char *fee)
{
	double amt;
	long i;
	char str[13] = {0};
	i = atof(fee) * 100;
	memset(str, '\0', strlen(str));
	sprintf(str, "%lu", i);
	ShowLogs(1, "String: %s", str);
	switch(strlen(str))
	{
		case 0:
			strcpy(confee, "000000000000");
			break;
		case 1:
			strcpy(confee, "00000000000");
			strcat(confee, str);
			break;
		case 2:
			strcpy(confee, "0000000000");
			strcat(confee, str);
			break;
		case 3:
			strcpy(confee, "000000000");
			strcat(confee, str);
			break;
		case 4:
			strcpy(confee, "00000000");
			strcat(confee, str);
			break;
		case 5:
			strcpy(confee, "0000000");
			strcat(confee, str);
			break;
		case 6:
			strcpy(confee, "000000");
			strcat(confee, str);
			break;
		case 7:
			strcpy(confee, "00000");
			strcat(confee, str);
			break;
		case 8:
			strcpy(confee, "0000");
			strcat(confee, str);
			break;
		case 9:
			strcpy(confee, "000");
			strcat(confee, str);
			break;
		case 10:
			strcpy(confee, "00");
			strcat(confee, str);
			break;
		case 11:
			strcpy(confee, "0");
			strcat(confee, str);
			break;
		case 12:
			strcpy(confee, str);
			break;
		default:
			strcpy(confee, "000000000000");
			break;
	}
}

void getConvenienceFeeSpecial(char *confee, char *fee)
{
    double amt;
    long i;
    char str[13] = {0};
    i = atof(fee) * 100;
    memset(str, '\0', strlen(str));
    sprintf(str, "%lu", i);
    ShowLogs(1, "String: %s", str);
    switch(strlen(str))
    {
        case 0:
            strcpy(confee, "D00000000");
            break;
        case 1:
            strcpy(confee, "D0000000");
            strcat(confee, str);
            break;
        case 2:
            strcpy(confee, "D000000");
            strcat(confee, str);
            break;
        case 3:
            strcpy(confee, "D00000");
            strcat(confee, str);
            break;
        case 4:
            strcpy(confee, "D0000");
            strcat(confee, str);
            break;
        case 5:
            strcpy(confee, "D000");
            strcat(confee, str);
            break;
        case 6:
            strcpy(confee, "D00");
            strcat(confee, str);
            break;
        case 7:
            strcpy(confee, "D0");
            strcat(confee, str);
            break;
        case 8:
            strcpy(confee, "D");
            strcat(confee, str);
            break;
        case 9:
            strcpy(confee, str);
            break;
        default:
            strcpy(confee, "D00000000");
            break;
    }
}
int dispVal = 0;

void parsehValues(char *field, char *ha, char *hb)
{
    int i = 0, j = 0, k = 0, s = 0;
    for(i = 0; i < strlen(field); i++)
    {
        if(j == 0)
        {
            if(field[i] == '=')
            {
                k = 1;
                continue;
            }
            
            if(field[i] == '^')
            {
                j++;
                k = 0;
                s = 0;
                continue;
            }

            if(k == 1)
            {
                ha[s] = field[i];
                s++;
            }
        }else if(j == 1)
        {
            if(field[i] == '=')
            {
                k = 1;
                continue;
            }
            
            if(field[i] == '^')
            {
                j++;
                k = 0;
                s = 0;
                continue;
            }

            if(k == 1)
            {
                hb[s] = field[i];
                s++;
            }
        }
    }
}

int GetAmountDisplay(char *name, struct LABELS data[], struct PRODUCTS prod[], struct GOTDATA gDa[],
	struct BILLERS *bill, int pro, int count, int proused)
{
	int iRet, i, iLen, iRev, nt;
	char disp[128] = {0};
	char confee[13] = {0};
    char confee2[13] = {0};
    char uTemp[256] = {0};
    char uTemp2[256] = {0};
    char uTemp3[256] = {0};
	uchar szTotalAmt[12+1];
	uchar	szBuff[50];
	char temp[128] = {0};
	char proc[7] = {0};
	char SN[33] = {0};
	char theUHI[33] = {0};
	char theUHISend[33] = {0};
    char ha[128] = {0};
    char hb[128] = {0};
	char billerinfo[999] = {0};
	char billerinfosend[999] = {0};
	char field[1000] = {0};
	char selectedBiller[128] = {0};
	char billerid[128] = {0};
	char subInfo[128] = {0};
	char subInfoValue[128] = {0};
	char productCode[128] = {0};
	char paymentdetails[999] = {0};
    char lasthost[128] = {0};
    GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
    stTextAttr.eFontSize = GUI_FONT_SMALL;

	//memset(&glSendPack, 0, sizeof(STISO8583));
	glProcInfo.stTranLog.ucTranType = SALE;
	displayName(name);
	SetCurrTitle(_T(name));

	ShowLogs(1, "Billername: %s.", bill->billername);
	ShowLogs(1, "PrintAll: %s.", bill->printall);
	ShowLogs(1, "VendorId: %s.", bill->vendorid);
	ShowLogs(1, "isToken: %s.", bill->istoken);
	ShowLogs(1, "ConvenienceFee: %s.", bill->conveniencefee);
	ShowLogs(1, "PrintValidation: %s.", bill->printvalidation);

	//Check if amount should be gotten from host based on vendor id (AMT)
	if(strstr(bill->vendorid, "AMT") != NULL)
	{
        ShowLogs(1, "INSIDE GetAmountDisplay 1");
		sprintf((char *)glSendPack.szMsgCode, "%s", "0100");
		memset(proc, '\0', strlen(proc));
		strcat(proc, "310000");
        strcpy(glSendPack.szProcCode, proc);
		glSysCtrl.ulSTAN = useStan;
		sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN); 
		glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;
		sprintf((char *)glSendPack.szRRN, "000000%s", glSendPack.szSTAN);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("tid", temp);
		sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);

		memset(SN, '\0', strlen(SN)); 
		ReadSN(SN);
		if ('\0' == SN[0]) {
			strcpy(theUHI, "000000009");
		}
		strcpy(theUHI, SN);
		sprintf(theUHISend, "01%03d%s", strlen(theUHI), theUHI);
		ShowLogs(1, "Serial: %s", theUHISend);

        if(strstr(bill->vendorid, "NPA") != NULL)
		{
			strcpy(selectedBiller, bill->vendorid + 3);
			strcpy(billerid, "");
			strcpy(subInfo, "Meter Number");
			strcpy(subInfoValue, "12");
			strcpy(productCode, "5677890877");
		}else
		{
			if(strstr(bill->istoken, "true") != NULL)
			{
				strcpy(selectedBiller, bill->vendorid);
				strcpy(billerid, "");
				strcpy(subInfo, "Meter Number");
				strcpy(subInfoValue, "12");
				strcpy(productCode, "5677890877");
			}else
			{
				strcpy(selectedBiller, bill->vendorid);
				strcpy(billerid, "");
				strcpy(subInfo, "Phone Number");
				strcpy(subInfoValue, "12");
				strcpy(productCode, "5677808766");
			}
		}
		strcpy(paymentdetails, "");
		for(i = 0; i < count; i++)
	    {
	    	strcat(paymentdetails, ".");
	    	strcat(paymentdetails, gDa[i].value);
	    }

	    strcpy(billerinfo, subInfo);
	    strcat(billerinfo, "=");
	    strcat(billerinfo, subInfoValue);
	    strcat(billerinfo, ".");
	    strcat(billerinfo, selectedBiller);
        ShowLogs(1, "1. BillerInfo: %s", billerinfo);
        ShowLogs(1, "1. TempBillers: %s", glSendPack.tempBillers);
        memset(uTemp, '\0', strlen(uTemp));
        strcpy(uTemp, billerinfo);
        strcat(uTemp, glSendPack.tempBillers);
	    strcat(billerinfo, paymentdetails);
        memset(uTemp2, '\0', strlen(uTemp2));
        sprintf(uTemp2, "48%03d%s", strlen(uTemp), uTemp);

	    sprintf(billerinfosend, "48%03d%s", strlen(billerinfo), billerinfo);
	    ShowLogs(1, "Biller Info: %s", billerinfosend);
        memset(uTemp3, '\0', strlen(uTemp3));
	    strcpy(field, theUHISend);
		strcat(field, billerinfosend);
        strcpy(uTemp3, theUHISend);
        strcat(uTemp3, uTemp2);
        ShowLogs(1, "Field: %s", field);
		strcpy(glSendPack.szBillers, field);
        strcpy(glSendPack.tempBillers2, uTemp3);
		ShowLogs(1, "Field 62: %s", glSendPack.szBillers);
        ShowLogs(1, "Field 62 Temp: %s", glSendPack.tempBillers2);


        sprintf((char *)glSendPack.szPosDataCode, "%.*s", LEN_POS_CODE, "510101210244101");
        memset(temp, '\0', strlen(temp));
        UtilGetEnv("curcode", temp);
        sprintf((char *)glSendPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, temp);
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("txnMNL", temp);
        sprintf((char *)glSendPack.szMNL, "%.*s", LEN_MNL, temp);
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("tid", temp);
        sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("txnMid", temp);
        ShowLogs(1, "Mid: %s", temp);
        sprintf((char *)glSendPack.szMerchantID, "%s", temp);
        sprintf((char *)glSendPack.szPoscCode, "%.*s", LEN_POSC_CODE, "06");
        sprintf((char *)glSendPack.szTransFee, "%.*s", LEN_TRANS_FEE, "D00000000");
        sprintf((char *)glSendPack.szAqurId, "%.*s", LEN_AQUR_ID, "111129");
        sprintf((char *)glSendPack.szCondCode, "%s", "00");
        strcpy(glSendPack.szEntryMode, "0051");
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("txnMCC", temp);
        sprintf((char *)glSendPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, temp);

        dispVal = 1;
        memset(lasthost, '\0', strlen(lasthost));
        UtilGetEnvEx("lhost", lasthost);
        ShowLogs(1, "1. Lasthost: %s", lasthost);
        if(strstr(lasthost, "host2") != NULL)
        {
           iRet = SendEmvDataB(NULL, &iRev);
        }else
        {
            iRet = SendEmvData(NULL, &iRev);
        }
        dispVal = 0;
		if(strstr(glRecvPack.szRspCode, "00") != NULL)
        {
            ShowLogs(1, "Validation was successful");
            if(strstr(bill->printvalidation, "true") != NULL)
                PrintValidation(PRN_NORMAL, bill->billername);
        }else
        {
            ShowLogs(1, "Validation was not successful");
            PrintValidation(PRN_NORMAL, bill->billername);
            return 1;
        }

		memset(confee, '\0', strlen(confee));
		getConvenienceFee(confee, bill->conveniencefee);
        memset(confee2, '\0', strlen(confee2));
        getConvenienceFeeSpecial(confee2, bill->conveniencefee);
        ShowLogs(1, "ConvenienceFee Used: %s", confee2);
        sprintf((char *)glSendPack.szTransFee, "%s", confee2);
		ShowLogs(1, "ConvenienceFee: %s", confee);
        //sprintf((char *)glSendPack.szTransFee, "%s", confee);
		memset(szTotalAmt, '\0', strlen(szTotalAmt));
		PubAscAdd(glProcInfo.stTranLog.szAmount, confee, 12, szTotalAmt);
		ShowLogs(1, "Total: %s", szTotalAmt);
		memset(szBuff, '\0', strlen(szBuff));
		App_ConvAmountTran(szTotalAmt, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
		ShowLogs(1, "Converted Total: %s", szBuff);
		memset(disp, '\0', strlen(disp));
		strcpy(disp, "PLEASE CONFIRM AMOUNT");
		//strcat(disp, szBuff);

        Gui_ClearScr(); 
        Gui_DrawText(disp, stTextAttr, 0, 15);
        Gui_DrawText(szBuff, stTextAttr, 0, 35);
        Gui_DrawText("NO                YES", stTextAttr, 0, 75);
        kbflush();
        nt = 0;
        while(1) 
        { 
            if(kbhit()==0)
            {
                switch(getkey())
                {
                    case KEYCANCEL:
                        return 1;
                        //return ERR_USERCANCEL;
                    case KEYENTER:
                        nt = 1;
                        break;
                    default:
                        Beep();
                }
            }
            if(nt)
                break;
        }

		//iRet = DisplayInfoYN(bill->billername, disp, 60);
		//if(iRet == ERR_USERCANCEL || iRet == GUI_ERR_TIMEOUT)
		//	return 1;
	}else
	{
        ShowLogs(1, "GetAmountDisplay 2");
		if(proused == -1)
		{
            ShowLogs(1, "GetAmountDisplay 2A");
			iRet = GetAmount();
			if( iRet!=0 )
			{
				return ERR_USERCANCEL;
			}
			ShowLogs(1, "1. Amount: %s", glProcInfo.stTranLog.szAmount);
		}else if(prod[proused].value[0] == '0')
		{
            ShowLogs(1, "GetAmountDisplay 2B");
			iRet = GetAmount();
			if( iRet!=0 )
			{
				return ERR_USERCANCEL;
			}
			ShowLogs(1, "1. Amount: %s", glProcInfo.stTranLog.szAmount);
		}else
		{
            ShowLogs(1, "GetAmountDisplay 2C");
			getConvenienceFee(glProcInfo.stTranLog.szAmount, prod[proused].value);
			ShowLogs(1, "2. Amount: %s", glProcInfo.stTranLog.szAmount);
		}
        ShowLogs(1, "GetAmountDisplay 2D");
		memset(confee, '\0', strlen(confee));
		getConvenienceFee(confee, bill->conveniencefee);
        memset(confee2, '\0', strlen(confee2));
        getConvenienceFeeSpecial(confee2, bill->conveniencefee);
		ShowLogs(1, "ConvenienceFee Used: %s", confee2);
        sprintf((char *)glSendPack.szTransFee, "%s", confee2);
        //sprintf((char *)glSendPack.szTranAmt, "%s", glProcInfo.stTranLog.szAmount);//New
		memset(szTotalAmt, '\0', strlen(szTotalAmt));
		PubAscAdd(glProcInfo.stTranLog.szAmount, confee, 12, szTotalAmt);
		ShowLogs(1, "Total: %s", szTotalAmt);
        sprintf((char *)glSendPack.szTranAmt, "%s", szTotalAmt);//Before
		memset(szBuff, '\0', strlen(szBuff));
		App_ConvAmountTran(szTotalAmt, szBuff, GetTranAmountInfo(&glProcInfo.stTranLog));
		ShowLogs(1, "Converted Total: %s", szBuff);
		memset(disp, '\0', strlen(disp));
		strcpy(disp, "Please Confirm Amount");
		//strcat(disp, szBuff);

        //Testing Wisdom
        Gui_ClearScr(); 
        Gui_DrawText(disp, stTextAttr, 0, 15);
        Gui_DrawText(szBuff, stTextAttr, 0, 35);
        Gui_DrawText("No                Yes", stTextAttr, 0, 75);
        kbflush();
        nt = 0;
        while(1) 
        { 
            if(kbhit()==0)
            {
                switch(getkey())
                {
                    case KEYCANCEL:
                        return 1;
                        //return ERR_USERCANCEL;
                    case KEYENTER:
                        nt = 1;
                        break;
                    default:
                        Beep();
                }
            }
            if(nt)
                break;
        }

		/*iRet = DisplayInfoYN(bill->billername, disp, 60);
		if(iRet == ERR_USERCANCEL || iRet == GUI_ERR_TIMEOUT)
        {
            //Testing something here
            TransOther();
			//return 1;
        }*/
		
		sprintf((char *)glSendPack.szMsgCode, "%s", "0100");
		memset(proc, '\0', strlen(proc));
        strcat(proc, "310000");
        strcpy(glSendPack.szProcCode, proc);
		glSysCtrl.ulSTAN = useStan;
		sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN); 
		glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;
		sprintf((char *)glSendPack.szRRN, "000000%s", glSendPack.szSTAN);
		memset(temp, '\0', strlen(temp));
		UtilGetEnvEx("tid", temp);
		sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);

		memset(SN, '\0', strlen(SN)); 
		ReadSN(SN);
		if ('\0' == SN[0]) {
			strcpy(theUHI, "000000009");
		}
		strcpy(theUHI, SN);
		sprintf(theUHISend, "01%03d%s", strlen(theUHI), theUHI);
		ShowLogs(1, "Serial: %s", theUHISend);
		if(strstr(bill->vendorid, "NPA") != NULL)
		{
			strcpy(selectedBiller, bill->vendorid + 3);
			strcpy(billerid, "");
			strcpy(subInfo, "Meter Number");
			strcpy(subInfoValue, "12");
			strcpy(productCode, "5677890877");
		}else
		{
			if(strstr(bill->istoken, "true") != NULL)
			{
				strcpy(selectedBiller, bill->vendorid);
				strcpy(billerid, "");
				strcpy(subInfo, "Meter Number");
				strcpy(subInfoValue, "12");
				strcpy(productCode, "5677890877");
			}else
			{
				strcpy(selectedBiller, bill->vendorid);
				strcpy(billerid, "");
				strcpy(subInfo, "Phone Number");
				strcpy(subInfoValue, "12");
				strcpy(productCode, "5677808766");
			}
		}
		
		for(i = 0; i < count; i++)
	    {
	    	strcat(paymentdetails, ".");
	    	strcat(paymentdetails, gDa[i].value);
	    }

	    strcpy(billerinfo, subInfo);
	    strcat(billerinfo, "=");
	    strcat(billerinfo, subInfoValue);
	    strcat(billerinfo, ".");
	    strcat(billerinfo, selectedBiller);
        ShowLogs(1, "2. BillerInfo: %s", billerinfo);
        ShowLogs(1, "2. TempBillers: %s", glSendPack.tempBillers);
        memset(uTemp, '\0', strlen(uTemp));
        strcpy(uTemp, billerinfo);
        strcat(uTemp, glSendPack.tempBillers);
	    strcat(billerinfo, paymentdetails);
        memset(uTemp2, '\0', strlen(uTemp2));
        sprintf(uTemp2, "48%03d%s", strlen(uTemp), uTemp);
	    sprintf(billerinfosend, "48%03d%s", strlen(billerinfo), billerinfo);
	    ShowLogs(1, "Biller Info: %s", billerinfosend);
	    strcpy(field, theUHISend);
		strcat(field, billerinfosend);
        memset(uTemp3, '\0', strlen(uTemp3));
        strcpy(uTemp3, theUHISend);
        strcat(uTemp3, uTemp2);
        ShowLogs(1, "Field: %s", field);
		strcpy(glSendPack.szBillers, field);
        strcpy(glSendPack.tempBillers2, uTemp3);
        ShowLogs(1, "Field 62: %s", glSendPack.szBillers);
        ShowLogs(1, "Field 62 Temp: %s", glSendPack.tempBillers2);

        sprintf((char *)glSendPack.szPosDataCode, "%.*s", LEN_POS_CODE, "510101210244101");
        memset(temp, '\0', strlen(temp));
        UtilGetEnv("curcode", temp);
        sprintf((char *)glSendPack.szTranCurcyCode, "%.*s", LEN_CURCY_CODE, temp);
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("txnMNL", temp);
        sprintf((char *)glSendPack.szMNL, "%.*s", LEN_MNL, temp);
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("tid", temp);
        sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, temp);
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("txnMid", temp);
        ShowLogs(1, "1. Mid: %s", temp);
        sprintf((char *)glSendPack.szMerchantID, "%s", temp);
        sprintf((char *)glSendPack.szPoscCode, "%.*s", LEN_POSC_CODE, "06");
        //sprintf((char *)glSendPack.szTransFee, "%.*s", LEN_TRANS_FEE, "D00000000");
        sprintf((char *)glSendPack.szAqurId, "%.*s", LEN_AQUR_ID, "111129");
        sprintf((char *)glSendPack.szCondCode, "%s", "00");
        strcpy(glSendPack.szEntryMode, "0051");
        memset(temp, '\0', strlen(temp));
        UtilGetEnvEx("txnMCC", temp);
        sprintf((char *)glSendPack.szMerchantType, "%.*s", LEN_MERCHANT_TYPE, temp);

        dispVal = 1;
        memset(lasthost, '\0', strlen(lasthost));
        UtilGetEnvEx("lhost", lasthost);
        ShowLogs(1, "1. Lasthost: %s", lasthost);
        if(strstr(lasthost, "host2") != NULL)
        {
           iRet = SendEmvDataB(NULL, &iRev);
        }else
        {
            iRet = SendEmvData(NULL, &iRev);
        }
        dispVal = 0;

        if(strstr(glRecvPack.szRspCode, "00") != NULL)
        {
            ShowLogs(1, "Validation was successful");
            DisplayInfoNone("UNIFIED PAYMENTS", "VALIDATION SUCCESSFUL", 2);
            if(strstr(bill->printvalidation, "true") != NULL)
                PrintValidation(PRN_NORMAL, bill->billername);
        }else
        {
            ShowLogs(1, "Validation was not successful");
            DisplayInfoNone("UNIFIED PAYMENTS", "VALIDATION SUCCESSFUL", 2);
            PrintValidation(PRN_NORMAL, bill->billername);
            return 1;
        }
	}
	ShowLogs(1, "Field 62: %s", glRecvPack.szBillers);
	//print validation here if set to true
    memset(ha, '\0', strlen(ha));
    memset(hb, '\0', strlen(hb));
    parsehValues(glRecvPack.szBillers, ha, hb);
    ShowLogs(1, "HA - %s", ha);
    ShowLogs(1, "HB - %s", hb);

	//Display validation response
	Gui_ClearScr(); 
    Gui_DrawText(ha, stTextAttr, 0, 15);
    Gui_DrawText(hb, stTextAttr, 0, 35);
    Gui_DrawText("No                Yes", stTextAttr, 0, 75);
	kbflush();
	while(1) 
	{ 
		if(kbhit()==0)
		{
			switch(getkey())
			{
				case KEYCANCEL:
					return 1;
				case KEYENTER:
					return 0;
				default:
					Beep();
			}
		}
	}
	return 0;
}

void parseP(char *orig, char* format)
{
	int i = 0, j = 0;
	for(i = 0; i < strlen(orig); i++)
	{
		if(orig[i] == '\n')
		{

		}else
		{
			format[j] = orig[i];
			j++;
		}
	} 
}

int ProcessBiller(struct LABELS data[], struct PRODUCTS prod[], struct GOTDATA gDa[],
	struct BILLERS *bill, int pro, int count, int proused)
{
	int iRet, i;
	char temp[128] = {0};
    char tempName[128] = {0};
	char input[128] = {0};
	char valinput[128] = {0};
	int min, max, reval = 0;
	char error[128] = {0};
    
    memset(&printVas, 0, sizeof(PRINTVAS));

	for(i = 0; i < count; i++)
    {
    	LABEL:
    	min = getMin(data[i].lengthrule);
    	max = getMax(data[i].lengthrule);
    	ShowLogs(1, "Min Length: %d", min);
    	ShowLogs(1, "Max Length: %d", max);
    	memset(temp, '\0', strlen(temp));
        if(reval == 1)
        {
            memset(tempName, '\0', strlen(tempName));
            strcpy(tempName, data[count].labelname);
            strcat(tempName, " REPEAT");
            iRet = DisplayMsg(bill->billername, tempName, data[count].value, temp, min, max);
        }else
            iRet = DisplayMsg(bill->billername, data[count].labelname, data[count].value, temp, min, max);
		//iRet = DisplayMsg(bill->billername, data[i].labelname, data[i].value, temp, min, max);
		ShowLogs(1, "Data entered for %s: %s", data[i].labelname, temp);
        if(i == 0)
        {
            strcpy(glSendPack.tempBillers, ".");
            strcat(glSendPack.tempBillers, data[i].labelname);
            strcat(glSendPack.tempBillers, "=");
            strcat(glSendPack.tempBillers, temp);
        }else
        {
            strcat(glSendPack.tempBillers, ".");
            strcat(glSendPack.tempBillers, data[i].labelname);
            strcat(glSendPack.tempBillers, "=");
            strcat(glSendPack.tempBillers, temp);
        }
        ShowLogs(1, "TempBuffer: %s", glSendPack.tempBillers);
		if(strlen(temp) < 1 || iRet == GUI_ERR_USERCANCELLED)
		{
			return 1;
		}else
		{
			memset(input, '\0', strlen(input));
			parseParameter(temp, input);
			ShowLogs(1, "Input Type: %s", data[i].inputtype);
			if(getLabelInputtype(data[i].inputtype, input))
			{
				memset(error, '\0', strlen(error));
				Beep();
				strcpy(error, data[i].labelname);
				strcat(error, " WRONG\nINPUT TYPE");
				DisplayInfoNone("UNIFIED PAYMENTS", error, 4);
				return 1;
			}
			ShowLogs(1, "1. Revalidate: %s", data[i].revalidate);
			ShowLogs(1, "1. Revalidate Count: %d", reval);
			if(strstr(data[i].revalidate, "true") != NULL)
			{
				if(reval == 0)
				{
					memset(valinput, '\0', strlen(valinput));
					strcpy(valinput, input);
					reval++;
					goto LABEL;
				}else if(strlen(valinput))
					reval = 0;
			}
			ShowLogs(1, "1. Revalidate: %s", data[i].revalidate);
			ShowLogs(1, "1. Revalidate Count: %d", reval);
			if(strlen(valinput))
			{
				if(strstr(valinput, input) != NULL)
				{
					ShowLogs(1, "valinput: %s, %d::input: %s, %d.", valinput, strlen(valinput),
						input, strlen(input));
				}else
				{
					memset(error, '\0', strlen(error));
					Beep();
					strcpy(error, data[i].labelname);
					strcat(error, " ");
					strcat(error, "Mismatch.");
					DisplayInfoNone("UNIFIED PAYMENTS", error, 4);
					return 1;
				}
			}
			strcpy(gDa[i].labelname, data[i].labelname);
			memset(valinput, '\0', strlen(valinput));
			strcpy(gDa[i].value, input);
			strcpy(gDa[i].inputtype, data[i].inputtype);
			strcpy(gDa[i].lengthrule, data[i].lengthrule);
			strcpy(gDa[i].revalidate, data[i].revalidate);
			strcpy(gDa[i].capturetoken, data[i].capturetoken);
			strcpy(gDa[i].printvalue, data[i].printvalue);

            if(strncmp(gDa[i].printvalue, "true", 4) == 0)
            {
                if(printVas.count < 19)
                {
                    sprintf((char *)printVas.name[i], "%s", gDa[i].labelname);
                    sprintf((char *)printVas.value[i], "%s", gDa[i].value);
                    printVas.count = i + 1;
                }
            }
		}
    }
    
    if(pro > 1)
    {
    	int iRet = 0, iMenuNo, iRev = 0, amt = 0;
		ST_EVENT_MSG stEventMsg;
		uchar key = 0;
		int chk = 0;
		char pin[25] = {0};
		GUI_MENUITEM stDefTranMenuItem1[20] = {{0}};
		char txnName1[20][128];
		int iTemp = 0;
		char temp[5] = {0};
		char sStore[100] = {0};
		char format[128] = {0};
		int proused = 0;
		uchar k;
		GUI_MENU stTranMenu;
		GUI_MENUITEM stTranMenuItem[20];
		int iMenuItemNum = 0;
		int i;
		GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
		stTextAttr.eFontSize = GUI_FONT_SMALL;
		numLines = 6;

	    for(i = 0; i < 20; i++)
    	{
    		memset(txnName1[i], '\0', sizeof(txnName1[i]));
    	}

		for(i = 0; i < pro; i++)
	    {
	        sprintf((char *)stDefTranMenuItem1[key].szText, "%s", prod[i].productname);
		    stDefTranMenuItem1[key].nValue = key;
		    stDefTranMenuItem1[key].bVisible = TRUE;
		    strncpy(txnName1[key], prod[i].productname, strlen(prod[i].productname));
		    key++;
	    }

	    for(i = 0; i < key; ++i)
	    {
	        if(stDefTranMenuItem1[i].bVisible)
	        {
	        	memcpy(&stTranMenuItem[iMenuItemNum], &stDefTranMenuItem1[i], sizeof(GUI_MENUITEM));
	            sprintf(stTranMenuItem[iMenuItemNum].szText, "%s", stDefTranMenuItem1[i].szText);
	            //ShowLogs(1, "1. Display Memory Leaks: %s.", stTranMenuItem[iMenuItemNum].szText);
	            ++iMenuItemNum;
	        }
	    }
	    stTranMenuItem[iMenuItemNum].szText[0] = 0;
	    Gui_BindMenu(bill->billername, gl_stCenterAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);
		Gui_ClearScr();
		iMenuNo = 0;
		iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_DIRECT_RETURN, 1000, &iMenuNo);
		if(GUI_OK == iRet)
		{
            checkBoard = 0;
			for(i = 0; i < pro; i++)
		    {
		    	memset(format, '\0', strlen(format));
		    	parseP(txnName1[iMenuNo], format);
		    	if(strstr(prod[i].productname, format) != NULL)
		    	{
		    		amt = atoi(prod[i].value);
		    		if(amt < 1)
		    		{
                        ShowLogs(1, "INSIDE GetAmountDisplay 1");
		    			if(GetAmountDisplay(bill->billername, data, prod, gDa, bill, pro, count, -1))
		    				return 1;
		    		}else
		    		{
                        ShowLogs(1, "INSIDE GetAmountDisplay 2");
		    			proused = i;
		    			if(GetAmountDisplay(bill->billername, data, prod, gDa, bill, pro, count, proused))
		    				return 1;
		    		}
                    ShowLogs(1, "INSIDE GetAmountDisplay 2A");
                    //Copy temp field 62 here
                    memset(glSendPack.szBillers, '\0', strlen(glSendPack.szBillers));
                    strcpy(glSendPack.szBillers, glSendPack.tempBillers2);
                    performPurchase(15);
		    		return 0;
		    	}
		    }
		}else if(GUI_ERR_TIMEOUT == iRet)
		{
			Gui_ClearScr();
			return 1;
		}else if(GUI_ERR_USERCANCELLED == iRet)
		{
			Gui_ClearScr();
			return 1;
		}else
		{
			Gui_ClearScr();
			return 1;
		}
    }else
    {
        ShowLogs(1, "INSIDE GetAmountDisplay 3");
    	if(GetAmountDisplay(bill->billername, data, prod, gDa, bill, pro, count, -1))
    		return 1;
        ShowLogs(1, "INSIDE GetAmountDisplay 3A");
        //Copy temp field 62 here
        memset(glSendPack.szBillers, '\0', strlen(glSendPack.szBillers));
        strcpy(glSendPack.szBillers, glSendPack.tempBillers2);
        performPurchase(15);
    }
	return 0;
}

void analyseHere(struct LABELS data[], struct PRODUCTS prod[], struct GOTDATA gDa[],
	struct BILLERS *bill, int pro, int count, int proused)
{
	if(ProcessBiller(data, prod, gDa, bill, pro, count, proused))
        return;
}

void MainProcessBiller(char *name, char *allbillers)
{
	char biller[200 * 1024] = {0};
    struct LABELS data[248];
    struct PRODUCTS prod[248];
    struct GOTDATA gDa[248];
    char line[1028] = {0};
    char dataP[1028] = {0};
    int len = 0, i = 0;
    int count = 0;
    int pro = 0;
    char *labStar;
    char *proStar;
    struct BILLERS bill;

    memset(&glSendPack, 0, sizeof(STISO8583));

    getBiller(name, biller, allbillers);
    if(strlen(biller))
    {
        parseBillerData(biller, &bill);
        labStar = strstr(biller, "labels - ");
        proStar = strstr(biller, "products - ");
        memset(dataP, '\0', strlen(dataP));
        strcpy(dataP, proStar);
        if(strlen(dataP) > 11)
        {
            int i,j, k;
            for(i = 0; i < strlen(dataP); i++)
            {
                j = 0;
                k = 0;
                memset(line, '\0', strlen(line));
                for(j = 0; i < strlen(dataP); j++, k++, i++)
                {
                    if((dataP[i] == ',') && (dataP[i + 1] == 'p'))
                    {
                        break;
                    }else
                    {
                        line[k] = dataP[i];
                    }
                }
                parseProductData(line, prod, pro);
                pro++;
            }
        }else
        {
            ShowLogs(1, "Biller does not have products");
        }
        len = strlen(labStar) - strlen(proStar);
        memset(dataP, '\0', strlen(dataP));
        strncpy(dataP, biller + (strlen(biller) - strlen(labStar)), len);
        if(strlen(dataP) > 10)
        {
            int i,j, k;
            for(i = 0; i < strlen(dataP); i++)
            {
                j = 0;
                k = 0;
                memset(line, '\0', strlen(line));
                for(j = 0; i < strlen(dataP); j++, k++, i++)
                {
                    if((dataP[i] == ',') && (dataP[i + 1] == 'l'))
                    {
                        break;
                    }else
                    {
                        line[k] = dataP[i];
                    }
                }
                parseLabelData(line, data, count);
                count++;
            }
        }else
        {
            ShowLogs(1, "Biller does not have Label");
        }
    }else
    {
        ShowLogs(1, "Biller Does Not Exist");
        return;
    }
    analyseHere(data, prod, gDa, &bill, pro, count, -1);
}