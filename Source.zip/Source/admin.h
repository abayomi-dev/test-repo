
#ifndef _ADMIN_H
#define _ADMIN_H


#ifdef __cplusplus
extern "C" {
#endif 

int adminFunc();
int Reports();
int blockedTerminal();
int checkifCashier();
int cashierLogin();
int cashierLogout();


extern int adPinflag;

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
