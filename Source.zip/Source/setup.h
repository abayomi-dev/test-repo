
/****************************************************************************
NAME
    setup.h - �����ն˲������á���ѯģ��

DESCRIPTION

REFERENCE

MODIFICATION SHEET:
    MODIFIED   (YYYY.MM.DD)
    shengjx     2006.09.12      - created
****************************************************************************/

#ifndef _SETUP_H
#define _SETUP_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int GetIpLocalSettings(void *pstParam);
int GetRemoteIp(const uchar *pszHalfText, uchar bAllowHostName, uchar bAllowNull, void *pstIPAddr);
int ChkIfValidIp(const uchar *pszIP);
int ChkIfValidPort(const uchar *pszPort);

int  SetTcpIpParam(void *pstParam);
void SyncTcpIpParam(void *pstDst, const void *pstSrc);

int  SetWirelessParam(WIRELESS_PARAM *pstParam);
void SyncWirelessParam(WIRELESS_PARAM *pstDst, const WIRELESS_PARAM *pstSrc);

void GetAllSupportFunc(char *pszBuff);
void FunctionExe(uchar bUseInitMenu, int iFuncNo);
void FunctionMenu(void);
void FunctionInit(void);
void SetSystemParamAll(void);
void SetSysLang(uchar ucSelectMode);
void SetEdcLangExt(const char *pszDispName);

int SetRs232Param(RS232_PARA *rs232);

int wifiSetup();
extern int useExisting;
extern int firstWifi;
int  SetTcpIpSharedPara(COMM_CONFIG *pstCommCfg);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _SETUP_H

// end of file
