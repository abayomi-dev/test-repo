
#ifndef _MERCHANT_H
#define _MERCHANT_H


#ifdef __cplusplus
extern "C" {
#endif 

int merchantPin();
void setMerchantPin();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
