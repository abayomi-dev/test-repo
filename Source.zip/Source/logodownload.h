
#ifndef _LOGODOWNLOAD_H
#define _LOGODOWNLOAD_H


#ifdef __cplusplus
extern "C" {
#endif 

void logoDownload(int isReceipt);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

// end of file
