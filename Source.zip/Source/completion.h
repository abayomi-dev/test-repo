
#ifndef _COMPLETION_H
#define _COMPLETION_H


#ifdef __cplusplus
extern "C" {
#endif 

int salesCompletion();

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
