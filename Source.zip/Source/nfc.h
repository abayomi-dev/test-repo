
#ifndef _NFC_H
#define _NFC_H


#ifdef __cplusplus
extern "C" {
#endif 

//Function

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _MLOGO_H

// end of file
